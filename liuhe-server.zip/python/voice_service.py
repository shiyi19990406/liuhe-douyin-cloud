#!/usr/bin/env python3
"""独立 OpenVoice HTTP 服务：只负责参考音频 + 文本 -> WAV。

主 API 通过 VOICE_SERVICE_URL 调用它，避免在 2GB 主容器加载 PyTorch。
鉴权：x-voice-key 必须等于 VOICE_SERVICE_KEY（未配置时只允许本机调试）。
"""
import cgi
import json
import os
import shutil
import sys
import tempfile
import threading
import time
import uuid

os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from openvoice_daemon import load_engine, process

ROOT = os.environ.get("OPENVOICE_DIR") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "voices", "openvoice")
KEY = os.environ.get("VOICE_SERVICE_KEY", "")
PORT = int(os.environ.get("PORT", "8080"))
MAX_TEXT = 1200
MAX_AUDIO_BYTES = 20 * 1024 * 1024
LOCK = threading.Lock()
RESULTS = {}
RESULTS_TTL = 30 * 60


def cleanup_results():
    cutoff = time.time() - RESULTS_TTL
    for key in list(RESULTS.keys()):
        if RESULTS[key].get("at", 0) < cutoff:
            RESULTS.pop(key, None)


def run_job(job_id, text, speed_value, reference):
    try:
        with tempfile.TemporaryDirectory(prefix="liuhe-voice-") as work:
            output = os.path.join(work, "output.wav")
            with LOCK:
                process(str(uuid.uuid4()), {
                    "text": text,
                    "speed": speed_value,
                    "reference": reference,
                    "output": output,
                    "modelDir": ROOT
                })
            if not os.path.exists(output) or os.path.getsize(output) == 0:
                raise RuntimeError("语音生成为空")
            with open(output, "rb") as audio:
                body = audio.read()
        RESULTS[job_id] = {"status": "done", "body": body, "at": time.time()}
    except Exception as exc:
        RESULTS[job_id] = {"status": "failed", "error": str(exc) or "语音合成失败", "at": time.time()}
    finally:
        shutil.rmtree(os.path.dirname(reference), ignore_errors=True)


def authorized(headers):
    if not KEY:
        return headers.get("x-forwarded-for", "") in ("", "127.0.0.1", "::1") or os.environ.get("NODE_ENV") != "production"
    return headers.get("x-voice-key", "") == KEY


class Handler(BaseHTTPRequestHandler):
    server_version = "liuhe-voice/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("[voice] " + (fmt % args) + "\n")

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/result/"):
            job_id = self.path.split("/result/", 1)[1].split("?", 1)[0]
            item = RESULTS.get(job_id)
            if not item:
                self.send_json(404, {"ok": False, "error": {"code": "RESULT_NOT_FOUND", "message": "结果不存在或已过期"}})
                return
            if item.get("status") == "processing":
                self.send_json(202, {"ok": True, "data": {"id": job_id, "status": "processing"}})
                return
            if item.get("status") == "failed":
                self.send_json(500, {"ok": False, "error": {"code": "VOICE_SYNTH_FAILED", "message": item.get("error")}})
                return
            body = item.get("body") or b""
            self.send_response(200)
            self.send_header("content-type", "audio/wav")
            self.send_header("content-length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path != "/health":
            self.send_json(404, {"ok": False, "error": {"code": "NOT_FOUND", "message": "接口不存在"}})
            return
        self.send_json(200, {
            "ok": True,
            "data": {
                "service": "liuhe-voice",
                "engine": "OpenVoice V2 + MeloTTS",
                "modelDir": ROOT,
                "modelReady": os.path.exists(os.path.join(ROOT, "checkpoints_v2", "converter", "checkpoint.pth")),
                "auth": bool(KEY)
            }
        })

    def do_POST(self):
        if self.path != "/synthesize":
            self.send_json(404, {"ok": False, "error": {"code": "NOT_FOUND", "message": "接口不存在"}})
            return
        if not authorized(self.headers):
            self.send_json(401, {"ok": False, "error": {"code": "VOICE_SERVICE_UNAUTHORIZED", "message": "声音服务鉴权失败"}})
            return
        content_type = self.headers.get("content-type", "")
        if "multipart/form-data" not in content_type:
            self.send_json(400, {"ok": False, "error": {"code": "BAD_CONTENT_TYPE", "message": "请使用 multipart/form-data"}})
            return
        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": content_type}
        )
        text = str(form.getvalue("text") or "").strip()
        speed = str(form.getvalue("speed") or "1")
        upload = form["file"] if "file" in form else None
        if not text or len(text) > MAX_TEXT:
            self.send_json(400, {"ok": False, "error": {"code": "BAD_TEXT", "message": "文字为空或超过 1200 字"}})
            return
        if upload is None or not getattr(upload, "file", None):
            self.send_json(400, {"ok": False, "error": {"code": "NO_REFERENCE", "message": "请上传参考音频"}})
            return
        try:
            speed_value = max(0.75, min(1.3, float(speed)))
        except Exception:
            speed_value = 1.0
        work = tempfile.mkdtemp(prefix="liuhe-voice-ref-")
        ext = os.path.splitext(upload.filename or "")[1] or ".mp3"
        reference = os.path.join(work, "reference" + ext)
        size = 0
        try:
            with open(reference, "wb") as out:
                while True:
                    chunk = upload.file.read(1024 * 256)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > MAX_AUDIO_BYTES:
                        shutil.rmtree(work, ignore_errors=True)
                        self.send_json(413, {"ok": False, "error": {"code": "REFERENCE_TOO_LARGE", "message": "参考音频不能超过 20MB"}})
                        return
                    out.write(chunk)
        except Exception:
            shutil.rmtree(work, ignore_errors=True)
            self.send_json(500, {"ok": False, "error": {"code": "REFERENCE_SAVE_FAILED", "message": "参考音频保存失败"}})
            return
        cleanup_results()
        job_id = uuid.uuid4().hex
        RESULTS[job_id] = {"status": "processing", "at": time.time()}
        threading.Thread(target=run_job, args=(job_id, text, speed_value, reference), daemon=True).start()
        self.send_json(202, {"ok": True, "data": {"id": job_id, "status": "processing"}})

if __name__ == "__main__":
    os.makedirs(ROOT, exist_ok=True)
    print("[voice] model:", ROOT, flush=True)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
