#!/usr/bin/env python3
"""Track a selected moving watermark and inpaint it frame by frame.

This is a best-effort, fully local/open-source post-processing routine:
- user selects the watermark rectangle on a preview frame
- template matching tracks the rectangle
- OpenCV Telea inpainting reconstructs the covered pixels
- audio is muxed back by Node/ffmpeg afterwards
"""
import argparse
import json
import os
import sys

import cv2
import numpy as np


def emit(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def clamp(value, low, high):
    return max(low, min(high, value))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--template', required=True)
    parser.add_argument('--x', type=int, required=True)
    parser.add_argument('--y', type=int, required=True)
    parser.add_argument('--w', type=int, required=True)
    parser.add_argument('--h', type=int, required=True)
    parser.add_argument('--threshold', type=float, default=0.32)
    parser.add_argument('--fixed', action='store_true')
    args = parser.parse_args()

    cap = cv2.VideoCapture(args.input)
    if not cap.isOpened():
        emit({'type': 'error', 'message': '无法打开视频文件'})
        return 1

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0

    x = clamp(args.x, 0, max(0, width - 2))
    y = clamp(args.y, 0, max(0, height - 2))
    w = clamp(args.w, 2, width - x)
    h = clamp(args.h, 2, height - y)

    template_frame = cv2.imread(args.template)
    if template_frame is None:
        emit({'type': 'error', 'message': '无法读取水印模板帧'})
        return 1
    if template_frame.shape[1] != width or template_frame.shape[0] != height:
        template_frame = cv2.resize(template_frame, (width, height))
    template = template_frame[y:y + h, x:x + w].copy()
    if template.size == 0:
        emit({'type': 'error', 'message': '水印区域超出画面'})
        return 1

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    writer = cv2.VideoWriter(args.output, fourcc, fps, (width, height))
    if not writer.isOpened():
        emit({'type': 'error', 'message': '无法创建输出视频'})
        return 1

    last_cx = x + w / 2
    last_cy = y + h / 2
    vx = 0.0
    vy = 0.0
    misses = 0
    frame_index = 0
    last_report = -1

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if args.fixed:
                found_x = x
                found_y = y
                predicted_cx = last_cx
                predicted_cy = last_cy
            else:
                predicted_cx = last_cx + vx
                predicted_cy = last_cy + vy

            pad = max(64, int(max(w, h) * 2.2))
            sx0 = clamp(int(predicted_cx - w / 2 - pad), 0, width - 1)
            sy0 = clamp(int(predicted_cy - h / 2 - pad), 0, height - 1)
            sx1 = clamp(int(predicted_cx + w / 2 + pad), sx0 + w, width)
            sy1 = clamp(int(predicted_cy + h / 2 + pad), sy0 + h, height)
            search = frame[sy0:sy1, sx0:sx1]

            score = -1.0
            found_x = int(predicted_cx - w / 2)
            found_y = int(predicted_cy - h / 2)
            if not args.fixed and search.shape[0] >= h and search.shape[1] >= w:
                result = cv2.matchTemplate(search, template, cv2.TM_CCOEFF_NORMED)
                _, max_val, _, max_loc = cv2.minMaxLoc(result)
                score = float(max_val)
                if score >= args.threshold:
                    found_x = sx0 + int(max_loc[0])
                    found_y = sy0 + int(max_loc[1])
                    new_cx = found_x + w / 2
                    new_cy = found_y + h / 2
                    # Estimate velocity from the observed position, then smooth it.
                    vx = vx * 0.68 + (new_cx - last_cx) * 0.32
                    vy = vy * 0.68 + (new_cy - last_cy) * 0.32
                    last_cx = new_cx
                    last_cy = new_cy
                    found_x = int(last_cx - w / 2)
                    found_y = int(last_cy - h / 2)
                    misses = 0
                else:
                    # Keep following the predicted trajectory when correlation drops.
                    last_cx = predicted_cx
                    last_cy = predicted_cy
                    vx *= 0.97
                    vy *= 0.97
                    misses += 1
            else:
                last_cx = predicted_cx
                last_cy = predicted_cy
                misses += 1

            found_x = clamp(found_x, 1, max(1, width - w - 1))
            found_y = clamp(found_y, 1, max(1, height - h - 1))
            mask = np.zeros((height, width), dtype=np.uint8)
            margin = 2
            cv2.rectangle(
                mask,
                (max(0, found_x - margin), max(0, found_y - margin)),
                (min(width - 1, found_x + w + margin), min(height - 1, found_y + h + margin)),
                255,
                -1,
            )
            cleaned = cv2.inpaint(frame, mask, 3, cv2.INPAINT_TELEA)
            writer.write(cleaned)

            # Slight template refresh helps with moving, semi-transparent marks.
            if score > 0.45 and frame_index % 6 == 0:
                current = frame[found_y:found_y + h, found_x:found_x + w]
                if current.shape[:2] == template.shape[:2]:
                    template = cv2.addWeighted(template, 0.86, current, 0.14, 0)

            frame_index += 1
            if total:
                pct = int(frame_index / total * 100)
                if pct >= last_report + 2:
                    last_report = pct
                    emit({'type': 'progress', 'value': pct, 'score': round(score, 3), 'misses': misses})
    finally:
        cap.release()
        writer.release()

    emit({'type': 'done', 'frames': frame_index, 'width': width, 'height': height, 'fps': fps})
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
