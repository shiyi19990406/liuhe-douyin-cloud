#!/usr/bin/env python3
"""六和 · 内置免版权音乐生成器。

所有曲目都由代码程序化合成，不包含第三方采样，授权为 CC0-1.0，
可随小程序一起免费商用。输出 44.1kHz 立体声 MP3。
"""

import argparse
import json
import os
import subprocess
import sys
import wave

import numpy as np

SR = 44100
TRACKS = {
    "morning-haze": {
        "title": "静谧晨光", "mood": "治愈", "bpm": 72, "duration": 45, "key": "C 大调",
        "progression": [[48, 52, 55, 59], [45, 48, 52, 55], [41, 45, 48, 52], [43, 47, 50, 55]],
        "pad": 0.9, "pluck": 0.35, "bass": 0.5, "percussion": 0.0, "texture": "air",
        "description": "轻柔的钢琴质感铺底，适合清晨、旅行和温柔回忆。"
    },
    "film-overture": {
        "title": "电影序章", "mood": "电影", "bpm": 60, "duration": 48, "key": "A 小调",
        "progression": [[45, 48, 52, 57], [41, 45, 48, 53], [48, 52, 55, 60], [43, 47, 50, 55]],
        "pad": 1.0, "pluck": 0.18, "bass": 0.7, "percussion": 0.1, "texture": "drone",
        "description": "低频弦乐与缓慢推进的和声，适合预告片和人物旁白。"
    },
    "heartbeat": {
        "title": "心动节拍", "mood": "轻快", "bpm": 96, "duration": 40, "key": "F 大调",
        "progression": [[41, 45, 48, 52], [38, 41, 45, 50], [46, 50, 53, 57], [48, 52, 55, 60]],
        "pad": 0.62, "pluck": 0.55, "bass": 0.55, "percussion": 0.42, "texture": "air",
        "description": "轻盈的拨弦与柔和节拍，适合恋爱、日常和好物分享。"
    },
    "old-film": {
        "title": "旧日胶片", "mood": "怀旧", "bpm": 66, "duration": 42, "key": "D 小调",
        "progression": [[38, 41, 45, 48], [46, 50, 53, 57], [41, 45, 48, 52], [48, 52, 55, 60]],
        "pad": 0.9, "pluck": 0.3, "bass": 0.55, "percussion": 0.0, "texture": "vinyl",
        "description": "温暖的旧录音质感，适合老照片、回忆和人物故事。"
    },
    "starlight": {
        "title": "星河漫游", "mood": "氛围", "bpm": 58, "duration": 48, "key": "E 小调",
        "progression": [[40, 43, 47, 52], [36, 40, 43, 48], [43, 47, 50, 55], [38, 42, 45, 50]],
        "pad": 1.0, "pluck": 0.28, "bass": 0.5, "percussion": 0.0, "texture": "air",
        "description": "通透的合成器铺底与零星铃音，适合星空、宇宙和治愈画面。"
    },
    "daily-light": {
        "title": "轻快日常", "mood": "轻快", "bpm": 104, "duration": 38, "key": "G 大调",
        "progression": [[43, 47, 50, 55], [40, 43, 47, 52], [48, 52, 55, 60], [50, 54, 57, 62]],
        "pad": 0.6, "pluck": 0.6, "bass": 0.5, "percussion": 0.35, "texture": "air",
        "description": "清爽的节奏与明亮的拨弦，适合 vlog、开箱和日常记录。"
    },
    "suspense": {
        "title": "暗流", "mood": "悬疑", "bpm": 70, "duration": 42, "key": "C 小调",
        "progression": [[36, 39, 43, 46], [44, 47, 51, 54], [39, 43, 46, 51], [43, 46, 50, 53]],
        "pad": 0.95, "pluck": 0.12, "bass": 0.7, "percussion": 0.16, "texture": "drone",
        "description": "低沉的持续音与不安的和声，适合案件复盘和悬疑开场。"
    },
    "warm-memory": {
        "title": "暖光回忆", "mood": "温暖", "bpm": 64, "duration": 45, "key": "降 B 大调",
        "progression": [[46, 50, 53, 58], [43, 46, 50, 55], [39, 43, 46, 51], [41, 45, 48, 53]],
        "pad": 0.92, "pluck": 0.34, "bass": 0.52, "percussion": 0.0, "texture": "air",
        "description": "像午后阳光一样松弛的铺底，适合家庭、成长和纪念内容。"
    }
}


def midi_to_freq(note):
    return 440.0 * (2.0 ** ((note - 69) / 12.0))


def envelope(length, attack, release, sr=SR):
    n = max(1, int(length * sr))
    env = np.ones(n, dtype=np.float32)
    a = min(n, max(1, int(attack * sr)))
    r = min(n, max(1, int(release * sr)))
    env[:a] = np.linspace(0.0, 1.0, a, endpoint=False, dtype=np.float32) ** 0.6
    env[-r:] = np.linspace(1.0, 0.0, r, endpoint=False, dtype=np.float32) ** 1.4
    return env


def pad_note(freq, duration, gain, detune=0.0):
    n = int(duration * SR)
    t = np.arange(n, dtype=np.float32) / SR
    vibrato = 1.0 + 0.0015 * np.sin(2 * np.pi * 0.18 * t + freq)
    signal = np.zeros(n, dtype=np.float32)
    for harmonic, amplitude in ((1, 1.0), (2, 0.32), (3, 0.16), (4, 0.08), (5, 0.035)):
        signal += amplitude * np.sin(2 * np.pi * freq * harmonic * (1.0 + detune) * vibrato * t)
    signal *= envelope(duration, 1.4, 1.6) * gain
    return signal


def bass_note(freq, duration, gain):
    n = int(duration * SR)
    t = np.arange(n, dtype=np.float32) / SR
    signal = np.sin(2 * np.pi * freq * t) + 0.24 * np.sin(2 * np.pi * freq * 2 * t)
    signal += 0.08 * np.sin(2 * np.pi * freq * 0.5 * t)
    signal *= envelope(duration, 0.035, 0.4) * gain
    return signal


def pluck_note(freq, duration, gain):
    n = int(duration * SR)
    t = np.arange(n, dtype=np.float32) / SR
    signal = np.zeros(n, dtype=np.float32)
    for harmonic, amplitude in ((1, 1.0), (2, 0.4), (3, 0.2), (4, 0.1)):
        signal += amplitude * np.sin(2 * np.pi * freq * harmonic * t)
    decay = np.exp(-t * 4.2)
    click = np.exp(-t * 38.0) * 0.12
    signal = (signal * decay + click) * gain
    # 一阶低通，让拨弦更圆润。
    out = np.empty_like(signal)
    acc = 0.0
    for index in range(n):
        acc += 0.24 * (signal[index] - acc)
        out[index] = acc
    return out


def kick(duration, gain):
    n = int(duration * SR)
    t = np.arange(n, dtype=np.float32) / SR
    freq = 110 * np.exp(-t * 24) + 42
    phase = 2 * np.pi * np.cumsum(freq) / SR
    return (np.sin(phase) * np.exp(-t * 7.5) * gain).astype(np.float32)


def hat(duration, gain, rng):
    n = int(duration * SR)
    t = np.arange(n, dtype=np.float32) / SR
    noise = rng.normal(0, 1, n).astype(np.float32)
    out = np.empty_like(noise)
    acc = 0.0
    for index in range(n):
        acc += 0.75 * (noise[index] - acc)
        out[index] = noise[index] - acc
    return (out * np.exp(-t * 55) * gain).astype(np.float32)


def vinyl_noise(n, rng):
    noise = rng.normal(0, 1, n).astype(np.float32) * 0.006
    crackle = np.zeros(n, dtype=np.float32)
    count = n // 9000
    positions = rng.integers(0, max(1, n - 200), count)
    for pos in positions:
        crackle[pos:pos + 24] += rng.normal(0, 1, 24).astype(np.float32) * rng.uniform(0.01, 0.05)
    return noise + crackle


def build_track(track_id, config):
    seed = sum((index + 1) * ord(char) for index, char in enumerate(track_id)) % (2 ** 32)
    rng = np.random.default_rng(seed)
    bpm = config["bpm"]
    beat = 60.0 / bpm
    bar = beat * 4
    duration = config["duration"]
    total = int(duration * SR)
    left = np.zeros(total, dtype=np.float32)
    right = np.zeros(total, dtype=np.float32)
    progression = config["progression"]
    bars = int(np.ceil(duration / bar)) + 1

    def add(signal, start, pan=0.0, gain=1.0):
        start_index = int(start * SR)
        if start_index >= total:
            return
        end = min(total, start_index + len(signal))
        chunk = signal[:end - start_index] * gain
        l_gain = np.sqrt((1.0 - pan) / 2.0)
        r_gain = np.sqrt((1.0 + pan) / 2.0)
        left[start_index:end] += chunk * l_gain
        right[start_index:end] += chunk * r_gain

    for bar_index in range(bars):
        chord = progression[bar_index % len(progression)]
        start = bar_index * bar
        # 和弦铺底，允许和下一小节交叠。
        for note_index, note in enumerate(chord):
            freq = midi_to_freq(note)
            pan = (-0.55 + note_index * 0.35) * 0.8
            add(pad_note(freq, bar * 1.15, config["pad"] * 0.22, detune=0.0008), start, pan)
        # 低音。
        root = midi_to_freq(chord[0] - 12)
        add(bass_note(root, bar * 0.92, config["bass"] * 0.24), start, 0.0)
        # 拨弦/琶音。
        if config["pluck"] > 0:
            pattern = [0, 2, 1, 3, 2, 1, 3, 2]
            for step in range(8):
                note = chord[pattern[step] % len(chord)] + 12
                add(pluck_note(midi_to_freq(note), beat * 1.9, config["pluck"] * 0.14), start + step * beat * 0.5, -0.25 if step % 2 else 0.25)
        # 轻打击。
        if config["percussion"] > 0:
            for beat_index in range(4):
                if beat_index % 2 == 0:
                    add(kick(0.5, config["percussion"] * 0.4), start + beat_index * beat, 0.0)
                add(hat(0.12, config["percussion"] * 0.06, rng), start + beat_index * beat + beat * 0.5, 0.2)

    # 环境质感。
    if config["texture"] == "vinyl":
        left += vinyl_noise(total, rng)
        right += vinyl_noise(total, rng)
    elif config["texture"] in ("air", "drone"):
        t = np.arange(total, dtype=np.float32) / SR
        air = rng.normal(0, 1, total).astype(np.float32)
        # 简单的单极点低通，得到柔和空气感。
        smoothed = np.copy(air)
        acc = 0.0
        for index in range(total):
            acc += 0.015 * (air[index] - acc)
            smoothed[index] = acc
        left += smoothed * 0.16
        right += smoothed * 0.16
        if config["texture"] == "drone":
            drone = np.sin(2 * np.pi * 55 * t) * 0.02
            left += drone
            right += drone

    # 简易空间延时，制造纵深。
    for delay_seconds, gain, cross in ((0.13, 0.18, False), (0.23, 0.12, True), (0.37, 0.07, False)):
        delay = int(delay_seconds * SR)
        if cross:
            left[delay:] += right[:-delay] * gain
            right[delay:] += left[:-delay] * gain
        else:
            left[delay:] += left[:-delay] * gain
            right[delay:] += right[:-delay] * gain

    # 淡入淡出与软限幅。
    fade_in = int(1.2 * SR)
    fade_out = int(3.2 * SR)
    left[:fade_in] *= np.linspace(0, 1, fade_in, dtype=np.float32)
    right[:fade_in] *= np.linspace(0, 1, fade_in, dtype=np.float32)
    left[-fade_out:] *= np.linspace(1, 0, fade_out, dtype=np.float32)
    right[-fade_out:] *= np.linspace(1, 0, fade_out, dtype=np.float32)
    peak = max(float(np.max(np.abs(left))), float(np.max(np.abs(right))), 0.001)
    gain = 0.82 / peak
    left = np.tanh(left * gain * 1.05).astype(np.float32) * 0.92
    right = np.tanh(right * gain * 1.05).astype(np.float32) * 0.92
    return np.stack([left, right], axis=1)


def write_wav(path, audio):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    pcm = (np.clip(audio, -1, 1) * 32767.0).astype(np.int16)
    with wave.open(path, "wb") as handle:
        handle.setnchannels(2)
        handle.setsampwidth(2)
        handle.setframerate(SR)
        handle.writeframes(pcm.tobytes())


def to_mp3(wav_path, mp3_path):
    ffmpeg = os.environ.get("FFMPEG_PATH") or "ffmpeg"
    subprocess.run([
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-i", wav_path, "-af", "loudnorm=I=-18:TP=-1.8:LRA=12",
        "-ar", "44100", "-ac", "2", "-c:a", "libmp3lame", "-b:a", "192k", mp3_path
    ], check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--id", default="", help="只生成指定曲目 id")
    parser.add_argument("--output-dir", default=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "public", "music"))
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--wav", action="store_true", help="保留 WAV 文件")
    args = parser.parse_args()
    ids = [args.id] if args.id else list(TRACKS.keys())
    os.makedirs(args.output_dir, exist_ok=True)
    meta = []
    for track_id in ids:
        if track_id not in TRACKS:
            raise SystemExit("unknown track: " + track_id)
        config = TRACKS[track_id]
        mp3_path = os.path.join(args.output_dir, track_id + ".mp3")
        if os.path.exists(mp3_path) and not args.force:
            print("skip", track_id)
            meta.append({"id": track_id, **{k: v for k, v in config.items() if k != "progression"}})
            continue
        print("render", track_id, config["title"], flush=True)
        audio = build_track(track_id, config)
        wav_path = os.path.join(args.output_dir, track_id + ".wav")
        write_wav(wav_path, audio)
        to_mp3(wav_path, mp3_path)
        if not args.wav:
            os.unlink(wav_path)
        meta.append({"id": track_id, **{k: v for k, v in config.items() if k != "progression"}})
        print("  ->", mp3_path, os.path.getsize(mp3_path) // 1024, "KB", flush=True)
    with open(os.path.join(args.output_dir, "metadata.json"), "w", encoding="utf-8") as handle:
        json.dump(meta, handle, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
