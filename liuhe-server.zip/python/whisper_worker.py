#!/usr/bin/env python3
"""Persistent local faster-whisper worker.

Reads JSON lines from stdin and writes JSON lines to stdout.
No network service, no paid API — only free open-source models.
"""
import json
import os
import sys
import traceback


def emit(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def main():
    try:
        from faster_whisper import WhisperModel
        try:
            from zhconv import convert as to_simplified
        except Exception:
            to_simplified = None
    except Exception as exc:  # pragma: no cover - dependency error path
        emit({
            "type": "fatal",
            "message": "faster-whisper 未安装：%s。请运行 npm run setup:asr" % exc,
        })
        return 1

    model_name = os.environ.get("WHISPER_MODEL", "small")
    device = os.environ.get("WHISPER_DEVICE", "cpu")
    compute_type = os.environ.get("WHISPER_COMPUTE_TYPE", "int8")
    default_language = os.environ.get("WHISPER_LANGUAGE", "zh")
    beam_size = int(os.environ.get("WHISPER_BEAM_SIZE", "5"))

    try:
        model = WhisperModel(model_name, device=device, compute_type=compute_type)
    except Exception as exc:  # pragma: no cover - model download/load error
        emit({
            "type": "fatal",
            "message": "模型加载失败：%s" % exc,
        })
        return 1

    emit({"type": "ready", "model": model_name, "device": device})
    print("[whisper] ready: %s / %s / %s" % (model_name, device, compute_type), file=sys.stderr, flush=True)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            command = json.loads(line)
        except Exception:
            continue
        if command.get("cmd") == "shutdown":
            break

        job_id = str(command.get("id") or "")
        audio_path = command.get("file") or ""
        language = command.get("language") or default_language or None
        emit({"type": "stage", "id": job_id, "stage": "本地 Whisper 正在听写"})

        try:
            if not audio_path or not os.path.exists(audio_path):
                raise FileNotFoundError("音频文件不存在")

            prompt = ""
            if command.get("initial_prompt", True) and language in ("zh", "zh-CN", "zh-cn"):
                prompt = "以下是普通话内容，请使用简体中文输出，并补全标点。"

            segments, info = model.transcribe(
                audio_path,
                language=None if language in ("auto", "", None) else language,
                beam_size=beam_size,
                best_of=beam_size,
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 300},
                condition_on_previous_text=False,
                initial_prompt=prompt or None,
                word_timestamps=False,
            )

            duration = float(getattr(info, "duration", 0) or 0)
            output = []
            last_sent = -1
            for segment in segments:
                text = (segment.text or "").strip()
                if text and language in ("zh", "zh-CN", "zh-cn") and to_simplified:
                    text = to_simplified(text, "zh-cn")
                if text:
                    output.append({
                        "start": round(float(segment.start or 0), 2),
                        "end": round(float(segment.end or 0), 2),
                        "text": text,
                    })
                if duration > 0:
                    pct = int(min(99, max(0, float(segment.end or 0) / duration * 100)))
                    if pct >= last_sent + 8:
                        last_sent = pct
                        emit({"type": "progress", "id": job_id, "progress": pct})
            if not duration and output:
                duration = output[-1]["end"]

            emit({
                "id": job_id,
                "ok": True,
                "language": getattr(info, "language", language) or language or "zh",
                "duration": round(duration, 2),
                "segments": output,
            })
        except Exception as exc:
            emit({
                "id": job_id,
                "ok": False,
                "message": "识别失败：%s" % exc,
                "trace": traceback.format_exc()[-1200:],
            })
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(0)
