#!/usr/bin/env python3
"""Local photo repair and colorization worker. No paid APIs."""
import argparse
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np


def read_image(path):
    data = np.fromfile(path, dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("无法读取图片")
    return image


def write_image(path, image):
    ok, buffer = cv2.imencode(".jpg", image, [int(cv2.IMWRITE_JPEG_QUALITY), 94])
    if not ok:
        raise RuntimeError("无法保存图片")
    buffer.tofile(path)


def limit_size(image, max_side=2200):
    height, width = image.shape[:2]
    side = max(height, width)
    if side <= max_side:
        return image
    scale = max_side / float(side)
    return cv2.resize(image, (int(width * scale), int(height * scale)), interpolation=cv2.INTER_AREA)


def auto_damage_mask(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    top = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, kernel)
    black = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, kernel)
    response = cv2.max(top, black)
    # 只保留明显的高频划痕/污点，避免把正常纹理整片抹掉。
    high = float(np.percentile(response, 99.2))
    threshold = max(16.0, high * 0.72)
    mask = (response >= threshold).astype(np.uint8) * 255
    mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)
    return mask


def repair(image):
    mask = auto_damage_mask(image)
    if cv2.countNonZero(mask) > 0:
        image = cv2.inpaint(image, mask, 3, cv2.INPAINT_TELEA)
    # 轻度降噪 + 局部对比度 + 锐化，保留人像质感。
    image = cv2.bilateralFilter(image, 5, 32, 32)
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=1.6, tileGridSize=(8, 8))
    l = clahe.apply(l)
    image = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)
    blur = cv2.GaussianBlur(image, (0, 0), 1.1)
    image = cv2.addWeighted(image, 1.35, blur, -0.35, 0)
    return image


def load_colorizer(model_dir):
    prototxt = os.path.join(model_dir, "colorization_deploy_v2.prototxt")
    model = os.path.join(model_dir, "colorization_release_v2.caffemodel")
    hull = os.path.join(model_dir, "pts_in_hull.npy")
    missing = [p for p in (prototxt, model, hull) if not os.path.exists(p)]
    if missing:
        raise RuntimeError(
            "彩色化模型缺失，请运行 npm run download:color 下载。缺少：" + ", ".join(missing)
        )
    net = cv2.dnn.readNetFromCaffe(prototxt, model)
    points = np.load(hull).transpose().reshape(2, 313, 1, 1)
    class8 = net.getLayerId("class8_ab")
    conv8 = net.getLayerId("conv8_313_rh")
    net.getLayer(class8).blobs = [points.astype(np.float32)]
    net.getLayer(conv8).blobs = [np.full([1, 313], 2.606, dtype=np.float32)]
    return net


def colorize(image, net):
    # 模型在 224x224 的 L 通道上预测 ab，再与原图 L 合并。
    scaled = image.astype(np.float32) / 255.0
    lab = cv2.cvtColor(scaled, cv2.COLOR_BGR2LAB)
    l = lab[:, :, 0]
    l_rs = cv2.resize(l, (224, 224)) - 50
    net.setInput(cv2.dnn.blobFromImage(l_rs))
    ab = net.forward()[0, :, :, :].transpose((1, 2, 0))
    ab = cv2.resize(ab, (image.shape[1], image.shape[0]))
    colorized = np.concatenate((l[:, :, None], ab), axis=2)
    colorized = cv2.cvtColor(colorized, cv2.COLOR_LAB2BGR)
    colorized = np.clip(colorized, 0, 1)
    colorized = (colorized * 255).astype(np.uint8)
    # 轻微提升饱和度，避免老照片上色过灰。
    hsv = cv2.cvtColor(colorized, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 1] = np.clip(hsv[:, :, 1] * 1.12, 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--mode", choices=["repair", "colorize", "both"], default="both")
    parser.add_argument("--model-dir", required=True)
    parser.add_argument("--scale", type=int, choices=[2, 4], default=2)
    args = parser.parse_args()

    try:
        image = limit_size(read_image(args.input))
        if args.mode in ("repair", "both"):
            image = repair(image)
        if args.mode in ("colorize", "both"):
            net = load_colorizer(args.model_dir)
            image = colorize(image, net)
        if args.scale > 1:
            height, width = image.shape[:2]
            image = cv2.resize(image, (width * args.scale, height * args.scale), interpolation=cv2.INTER_LANCZOS4)
        write_image(args.output, image)
        print(json.dumps({"ok": True, "width": int(image.shape[1]), "height": int(image.shape[0])}, ensure_ascii=False))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())
