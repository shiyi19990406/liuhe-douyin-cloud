#!/usr/bin/env python3
"""六和本地 OpenVoice V2 CPU worker。

输入输出均为 JSON。参考音频只在本机提取音色特征，不上传到第三方。
"""

import json
import os
import sys
import tempfile
import time


def emit(payload):
    print(json.dumps(payload, ensure_ascii=False), flush=True)


def main():
    started = time.time()
    try:
        payload = json.load(sys.stdin)
        import torch

        # 在 macOS 上强制 CPU：MeloTTS 的中文 BERT 前端会错误地把 CPU 张量迁移到 MPS。
        if sys.platform == "darwin" and hasattr(torch.backends, "mps"):
            torch.backends.mps.is_available = lambda: False

        # MeloTTS 在导入日语前端时会读取 unidic.DICDIR；使用已安装的轻量词典，避免下载额外的大词典。
        import unidic
        import unidic_lite
        if not getattr(unidic, "DICDIR", None):
            unidic.DICDIR = unidic_lite.DICDIR

        from melo.api import TTS
        from openvoice.api import ToneColorConverter

        root = payload.get("modelDir") or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "models", "voices", "openvoice"
        )
        reference = payload.get("reference") or os.path.join(root, "reference", "voice-reference.mp3")
        converter_dir = os.path.join(root, "checkpoints_v2", "converter")
        speaker_path = os.path.join(root, "checkpoints_v2", "base_speakers", "ses", "zh.pth")
        melo_dir = os.path.join(root, "melo")
        output = payload.get("output")
        text = str(payload.get("text") or "").strip()
        speed = float(payload.get("speed") or 1.0)
        if not output or not text:
            raise RuntimeError("缺少文字或输出路径")
        required = [reference, speaker_path,
                    os.path.join(converter_dir, "config.json"),
                    os.path.join(converter_dir, "checkpoint.pth"),
                    os.path.join(melo_dir, "config.json"),
                    os.path.join(melo_dir, "checkpoint.pth")]
        missing = [item for item in required if not os.path.exists(item)]
        if missing:
            raise RuntimeError("OpenVoice 文件不完整：" + ", ".join(missing))

        torch.set_num_threads(max(1, min(4, os.cpu_count() or 4)))
        device = "cpu"
        emit({"type": "progress", "value": 0.05})
        tts = TTS(
            language="ZH",
            device=device,
            use_hf=False,
            config_path=os.path.join(melo_dir, "config.json"),
            ckpt_path=os.path.join(melo_dir, "checkpoint.pth"),
        )
        # 当前 OpenVoice 公开包的构造函数会把 enable_watermark 误传给父类，
        # 因此使用兼容的两个位置参数初始化，并保留官方默认水印。
        converter = ToneColorConverter(os.path.join(converter_dir, "config.json"), device)
        converter.load_ckpt(os.path.join(converter_dir, "checkpoint.pth"))
        emit({"type": "progress", "value": 0.4})

        target_se = converter.extract_se(reference)
        source_se = torch.load(speaker_path, map_location=device)
        speaker_ids = getattr(tts.hps.data, "spk2id", {})
        if isinstance(speaker_ids, dict):
            speaker_id = speaker_ids.get("ZH")
        else:
            speaker_id = getattr(speaker_ids, "ZH", None)
        if speaker_id is None:
            raise RuntimeError("MeloTTS 中文说话人未找到")

        with tempfile.TemporaryDirectory(prefix="openvoice-") as temp_dir:
            source_audio = os.path.join(temp_dir, "source.wav")
            tts.tts_to_file(text, speaker_id, source_audio, speed=speed, quiet=True)
            emit({"type": "progress", "value": 0.72})
            os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
            converter.convert(
                audio_src_path=source_audio,
                src_se=source_se,
                tgt_se=target_se,
                output_path=output,
                tau=0.3,
                message="liuhe-voice-clone",
            )
        if not os.path.exists(output) or os.path.getsize(output) == 0:
            raise RuntimeError("语音生成为空")
        emit({"type": "progress", "value": 1.0})
        emit({"type": "done", "output": output})
        emit({"type": "finished", "elapsed": round(time.time() - started, 3)})
    except Exception as exc:
        emit({"type": "error", "message": str(exc) or "OpenVoice 合成失败"})
        sys.exit(1)


if __name__ == "__main__":
    main()
