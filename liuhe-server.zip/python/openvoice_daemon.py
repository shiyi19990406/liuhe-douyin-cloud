#!/usr/bin/env python3
"""OpenVoice V2 常驻 CPU worker：模型只加载一次，随后通过 JSONL 接收任务。"""

import json
import os
import sys
import tempfile
import time

import torch

ENGINE = None
TARGET_CACHE = {}


def emit(request_id, payload):
    payload = {"requestId": request_id, **payload}
    print(json.dumps(payload, ensure_ascii=False), flush=True)


def load_engine(root):
    """模型只加载一次；参考音频的音色特征按文件修改时间缓存。"""
    global ENGINE
    if ENGINE is not None:
        return ENGINE
    if sys.platform == "darwin" and hasattr(torch.backends, "mps"):
        torch.backends.mps.is_available = lambda: False
    import unidic
    import unidic_lite
    dicdir = getattr(unidic, "DICDIR", None)
    if not dicdir or not os.path.exists(os.path.join(dicdir, "mecabrc")):
        unidic.DICDIR = unidic_lite.DICDIR
    from melo.api import TTS
    from openvoice.api import ToneColorConverter

    converter_dir = os.path.join(root, "checkpoints_v2", "converter")
    speaker_path = os.path.join(root, "checkpoints_v2", "base_speakers", "ses", "zh.pth")
    melo_dir = os.path.join(root, "melo")
    required = [speaker_path,
                os.path.join(converter_dir, "config.json"),
                os.path.join(converter_dir, "checkpoint.pth"),
                os.path.join(melo_dir, "config.json"),
                os.path.join(melo_dir, "checkpoint.pth")]
    missing = [item for item in required if not os.path.exists(item)]
    if missing:
        raise RuntimeError("OpenVoice 文件不完整：" + ", ".join(missing))

    torch.set_num_threads(max(1, min(4, os.cpu_count() or 4)))
    tts = TTS("ZH", device="cpu", use_hf=False,
              config_path=os.path.join(melo_dir, "config.json"),
              ckpt_path=os.path.join(melo_dir, "checkpoint.pth"))
    converter = ToneColorConverter(os.path.join(converter_dir, "config.json"), "cpu")
    converter.load_ckpt(os.path.join(converter_dir, "checkpoint.pth"))
    source_se = torch.load(speaker_path, map_location="cpu")
    speaker_ids = getattr(tts.hps.data, "spk2id", {})
    speaker_id = speaker_ids.get("ZH") if isinstance(speaker_ids, dict) else getattr(speaker_ids, "ZH", None)
    if speaker_id is None:
        raise RuntimeError("MeloTTS 中文说话人未找到")
    ENGINE = (tts, converter, source_se, speaker_id)
    return ENGINE


def load_target_se(reference):
    tts, converter, source_se, speaker_id = ENGINE
    if not reference or not os.path.exists(reference):
        raise RuntimeError("参考音频不存在：" + str(reference))
    stat = os.stat(reference)
    key = (os.path.abspath(reference), int(stat.st_mtime), int(stat.st_size))
    if key not in TARGET_CACHE:
        TARGET_CACHE.clear()
        TARGET_CACHE[key] = converter.extract_se(reference)
    return TARGET_CACHE[key]


def process(request_id, payload):
    root = payload.get("modelDir") or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models", "voices", "openvoice"
    )
    output = payload.get("output")
    text = str(payload.get("text") or "").strip()
    speed = float(payload.get("speed") or 1.0)
    reference = payload.get("reference") or os.path.join(root, "reference", "voice-reference.mp3")
    if not output or not text:
        raise RuntimeError("缺少文字或输出路径")
    emit(request_id, {"type": "progress", "value": 0.05})
    load_engine(root)
    target_se = load_target_se(reference)
    tts, converter, source_se, speaker_id = ENGINE
    emit(request_id, {"type": "progress", "value": 0.4})
    with tempfile.TemporaryDirectory(prefix="openvoice-") as temp_dir:
        source_audio = os.path.join(temp_dir, "source.wav")
        tts.tts_to_file(text, speaker_id, source_audio, speed=speed, quiet=True)
        emit(request_id, {"type": "progress", "value": 0.72})
        os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
        converter.convert(source_audio, source_se, target_se, output_path=output,
                          tau=0.3, message="liuhe-voice-clone")
    if not os.path.exists(output) or os.path.getsize(output) == 0:
        raise RuntimeError("语音生成为空")
    emit(request_id, {"type": "progress", "value": 1.0})
    emit(request_id, {"type": "done", "output": output})


def main():
    for line in sys.stdin:
        try:
            payload = json.loads(line)
            request_id = str(payload.get("requestId") or "")
            started = time.time()
            process(request_id, payload)
            emit(request_id, {"type": "finished", "elapsed": round(time.time() - started, 3)})
        except Exception as exc:
            emit(request_id if "request_id" in locals() else "", {"type": "error", "message": str(exc) or "OpenVoice 合成失败"})


if __name__ == "__main__":
    main()
