#!/usr/bin/env python3
"""把照片成片的标题/副标题渲染为透明 PNG，供 ffmpeg overlay 使用。"""

import argparse
import os
import sys

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    os.environ.get("OVERLAY_FONT_PATH", ""),
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/Supplemental/Songti.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]


def find_font():
    for candidate in FONT_CANDIDATES:
        if candidate and os.path.exists(candidate):
            return candidate
    return ""


def load_font(path, size):
    if path:
        for index in range(0, 4):
            try:
                return ImageFont.truetype(path, size, index=index)
            except Exception:
                continue
    try:
        return ImageFont.truetype("DejaVuSans.ttf", size)
    except Exception:
        return ImageFont.load_default()


def text_width(draw, text, font):
    try:
        return draw.textlength(text, font=font)
    except Exception:
        box = draw.textbbox((0, 0), text, font=font)
        return box[2] - box[0]


def wrap(draw, text, font, max_width, max_lines):
    lines = []
    current = ""
    for char in text:
        if char == "\n":
            if current:
                lines.append(current)
                current = ""
            continue
        candidate = current + char
        if text_width(draw, candidate, font) <= max_width:
            current = candidate
            continue
        if current:
            lines.append(current)
            current = char
        else:
            current = char
        if len(lines) >= max_lines:
            break
    if current and len(lines) < max_lines:
        lines.append(current)
    if len(lines) == max_lines:
        # 检查是否还有剩余文字，补省略号。
        consumed = sum(len(line) for line in lines)
        if consumed < len(text.replace("\n", "")):
            last = lines[-1]
            while last and text_width(draw, last + "…", font) > max_width:
                last = last[:-1]
            lines[-1] = last + "…"
    return lines


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--title", default="")
    parser.add_argument("--subtitle", default="")
    parser.add_argument("--width", type=int, default=720)
    parser.add_argument("--height", type=int, default=1280)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    title = (args.title or "").strip()[:28]
    subtitle = (args.subtitle or "").strip()[:48]
    if not title and not subtitle:
        return 0

    width, height = max(240, args.width), max(240, args.height)
    image = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)

    # 底部渐变遮罩，保证文字在亮照片上也可读。
    scrim_top = int(height * 0.52)
    for y in range(scrim_top, height):
        ratio = (y - scrim_top) / max(1, height - scrim_top)
        alpha = int(178 * (ratio ** 1.35))
        draw.line([(0, y), (width, y)], fill=(4, 8, 18, alpha))

    font_path = find_font()
    title_size = max(30, int(width * 0.052))
    subtitle_size = max(20, int(title_size * 0.58))
    title_font = load_font(font_path, title_size)
    subtitle_font = load_font(font_path, subtitle_size)
    max_text_width = int(width * 0.82)
    title_lines = wrap(draw, title, title_font, max_text_width, 2) if title else []
    subtitle_lines = wrap(draw, subtitle, subtitle_font, max_text_width, 2) if subtitle else []

    line_gap = int(title_size * 0.28)
    subtitle_gap = int(title_size * 0.34) if subtitle_lines else 0
    title_height = len(title_lines) * (title_size + line_gap)
    subtitle_height = len(subtitle_lines) * (subtitle_size + int(subtitle_size * 0.25))
    total_height = title_height + subtitle_gap + subtitle_height

    bottom_margin = int(height * 0.105)
    start_y = height - bottom_margin - total_height
    accent_y = start_y - int(title_size * 0.7)
    accent_width = max(36, int(width * 0.055))
    draw.rounded_rectangle(
        [(width - accent_width) // 2, accent_y, (width + accent_width) // 2, accent_y + max(4, int(height * 0.004))],
        radius=8,
        fill=(92, 152, 255, 235),
    )

    y = start_y
    for line in title_lines:
        line_width = text_width(draw, line, title_font)
        x = (width - line_width) / 2
        draw.text((x + 1, y + 3), line, font=title_font, fill=(0, 0, 0, 150))
        draw.text((x, y), line, font=title_font, fill=(255, 255, 255, 246))
        y += title_size + line_gap

    y += subtitle_gap
    for line in subtitle_lines:
        line_width = text_width(draw, line, subtitle_font)
        x = (width - line_width) / 2
        draw.text((x + 1, y + 2), line, font=subtitle_font, fill=(0, 0, 0, 130))
        draw.text((x, y), line, font=subtitle_font, fill=(255, 255, 255, 208))
        y += subtitle_size + int(subtitle_size * 0.25)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    image.save(args.output, "PNG", optimize=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
