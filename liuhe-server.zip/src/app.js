import express from 'express';
import path from 'node:path';
import { config } from './config.js';
import { AppError, toPublicError } from './lib/errors.js';
import healthRoutes from './routes/health.js';
import resolveRoutes from './routes/resolve.js';
import subtitleRoutes from './routes/subtitles.js';
import mediaRoutes from './routes/media.js';
import watermarkRoutes from './routes/watermark.js';
import followRoutes from './routes/follow.js';
import photoRoutes from './routes/photo.js';
import imageVideoRoutes from './routes/image-video.js';
import voiceRoutes from './routes/voice.js';
import authRoutes from './routes/auth.js';
import feedbackRoutes from './routes/feedback.js';
import { attachUser } from './lib/auth.js';

const app = express();
app.disable('x-powered-by');
app.disable('etag');
app.set('trust proxy', true);

app.use((req, res, next) => {
  res.setHeader('access-control-allow-origin', '*');
  res.setHeader('access-control-allow-methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('access-control-allow-headers', 'content-type,authorization,range');
  res.setHeader('access-control-expose-headers', 'content-range,content-length,accept-ranges');
  res.setHeader('x-content-type-options', 'nosniff');
  res.setHeader('referrer-policy', 'no-referrer');
  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }
  const startedAt = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - startedAt;
    if (!/\/api\/subtitles\/[^/]+$/.test(req.path) || res.statusCode >= 400) {
      console.log(`${req.method} ${req.originalUrl.split('?')[0]} ${res.statusCode} ${ms}ms`);
    }
  });
  next();
});

app.use(express.json({ limit: '2mb' }));
app.use('/api', attachUser);
app.use('/demo', express.static(path.join(config.publicDir, 'demo'), {
  maxAge: '1h',
  fallthrough: true,
  acceptRanges: true,
  index: false
}));
app.use('/api', healthRoutes);
app.use('/api', resolveRoutes);
app.use('/api', subtitleRoutes);
app.use('/api', mediaRoutes);
app.use('/api', watermarkRoutes);
app.use('/api', followRoutes);
app.use('/api', photoRoutes);
app.use('/api', imageVideoRoutes);
app.use('/api', voiceRoutes);
app.use('/api', authRoutes);
app.use('/api', feedbackRoutes);

app.use((req, res) => {
  res.status(404).json({
    ok: false,
    error: {
      code: 'NOT_FOUND',
      message: '接口不存在'
    }
  });
});

app.use((error, req, res, next) => {
  if (res.headersSent) {
    if (next) next(error);
    return;
  }
  if (error && error.name === 'MulterError') {
    const publicError = {
      status: 400,
      body: {
        ok: false,
        error: { code: error.code, message: '上传失败：' + error.message }
      }
    };
    res.status(publicError.status).json(publicError.body);
    return;
  }
  const publicError = toPublicError(error);
  if (publicError.status >= 500) {
    console.error('[server]', error);
  }
  res.status(publicError.status).json(publicError.body);
});

export default app;
