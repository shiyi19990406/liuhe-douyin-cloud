import express from 'express';
import multer from 'multer';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { enqueueLinkJob, enqueueUploadJob } from '../services/transcribe.js';
import { getJob, publicJob, deleteJob } from '../services/jobs.js';

const router = express.Router();

const storage = multer.diskStorage({
  destination(req, file, callback) {
    callback(null, config.uploadDir);
  },
  filename(req, file, callback) {
    const ext = path.extname(file.originalname || '').toLowerCase().slice(0, 8) || '.mp4';
    callback(null, crypto.randomUUID() + ext);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: config.maxUploadBytes,
    files: 1
  },
  fileFilter(req, file, callback) {
    const mime = String(file.mimetype || '');
    const name = String(file.originalname || '').toLowerCase();
    const looksVideo = mime.startsWith('video/') || /\.(mp4|mov|m4v|webm|mkv|avi|3gp)$/i.test(name) || mime === 'application/octet-stream';
    if (!looksVideo) {
      callback(new AppError(415, 'UNSUPPORTED_FILE', '请选择视频文件'));
      return;
    }
    callback(null, true);
  }
});

router.post('/subtitles/link', async (req, res, next) => {
  try {
    const url = String((req.body && req.body.url) || '').trim();
    if (!url) throw new AppError(400, 'NO_URL', '请提供视频链接');
    const job = enqueueLinkJob(url);
    res.status(202).json({ ok: true, data: job });
  } catch (error) {
    next(error);
  }
});

router.post('/subtitles/upload', (req, res, next) => {
  upload.single('file')(req, res, (error) => {
    if (error) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        next(new AppError(413, 'FILE_TOO_LARGE', '视频超过 ' + config.maxUploadMb + 'MB 限制'));
        return;
      }
      next(error);
      return;
    }
    try {
      if (!req.file) throw new AppError(400, 'NO_FILE', '没有收到视频文件');
      const job = enqueueUploadJob(req.file.path, req.file.originalname);
      res.status(202).json({ ok: true, data: job });
    } catch (nestedError) {
      next(nestedError);
    }
  });
});

router.get('/subtitles/:id', (req, res, next) => {
  try {
    const job = getJob(req.params.id);
    res.setHeader('cache-control', 'no-store');
    res.json({ ok: true, data: publicJob(job) });
  } catch (error) {
    next(error);
  }
});

router.get('/subtitles/:id/srt', (req, res, next) => {
  try {
    const job = getJob(req.params.id);
    if (job.status !== 'done' || !job.result) {
      throw new AppError(409, 'JOB_NOT_READY', '字幕还没有生成');
    }
    res.setHeader('content-type', 'application/x-subrip; charset=utf-8');
    res.setHeader(
      'content-disposition',
      "attachment; filename*=UTF-8''" + encodeURIComponent('liuhe-subtitle.srt')
    );
    res.send(job.result.srt || '');
  } catch (error) {
    next(error);
  }
});

router.delete('/subtitles/:id', (req, res, next) => {
  try {
    const removed = deleteJob(req.params.id);
    res.json({ ok: true, data: { removed } });
  } catch (error) {
    next(error);
  }
});

export default router;
