import express from 'express';
import multer from 'multer';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import {
  getCatalog,
  getVoiceBySlug,
  getVoiceJob,
  createVoiceJob,
  deleteVoiceJob,
  getVoiceOutput,
  getVoiceMp4,
  ensureVoiceSample,
  getVoiceSampleText,
  publicVoiceJob,
  engineInfo,
  publicEngineInfo
} from '../services/voice.js';
import {
  getCloneState,
  getClonePolicy,
  getCloneSamplePath,
  registerClone,
  renewConsent,
  deleteClone,
  getGuestCloneSummary,
  adoptGuestClone,
  assertVoiceConsentFields,
  assertVoiceCloneAudio
} from '../services/voice-clone.js';
import { probeDuration, safeUnlink } from '../lib/process.js';
import { requireUser } from '../lib/auth.js';
import { AppError } from '../lib/errors.js';

const router = express.Router();

const cloneStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadDir),
  filename: (req, file, cb) => cb(null, 'clone-' + crypto.randomUUID() + (path.extname(file.originalname || '') || '.audio'))
});
const cloneUpload = multer({ storage: cloneStorage, limits: { fileSize: config.maxVoiceCloneBytes, files: 1 } });

const referenceStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadDir),
  filename: (req, file, cb) => cb(null, 'ref-' + crypto.randomUUID() + (path.extname(file.originalname || '') || '.audio'))
});
const referenceUpload = multer({ storage: referenceStorage, limits: { fileSize: config.maxVoiceCloneBytes, files: 1 } });

function ownedJob(req, id) {
  const job = getVoiceJob(id);
  const userId = (req.user && req.user.id) || '';
  if (job.userId && job.userId !== userId) {
    throw new AppError(404, 'VOICE_JOB_NOT_FOUND', '配音任务不存在或已过期');
  }
  return job;
}

router.get('/voice/catalog', (req, res) => {
  res.setHeader('cache-control', 'no-store');
  res.json({ ok: true, data: getCatalog({ category: req.query.category, q: req.query.q, userId: req.user && req.user.id }) });
});

router.get('/voice/engine', (req, res) => {
  res.setHeader('cache-control', 'no-store');
  res.json({ ok: true, data: publicEngineInfo(engineInfo(req.user && req.user.id)) });
});

router.get('/voice/clone', (req, res) => {
  res.setHeader('cache-control', 'no-store');
  res.json({ ok: true, data: getCloneState(req.user && req.user.id) });
});

router.get('/voice/clone/policy', (req, res) => {
  res.setHeader('cache-control', 'no-store');
  res.json({ ok: true, data: getClonePolicy() });
});

router.post('/voice/clone', (req, res, next) => {
  cloneUpload.single('file')(req, res, async (error) => {
    if (error) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        next(new AppError(413, 'VOICE_CLONE_TOO_LARGE', '参考音频不能超过 ' + Math.round(config.maxVoiceCloneBytes / 1024 / 1024) + 'MB'));
        return;
      }
      next(error);
      return;
    }
    if (!config.voiceLegacyCloneEnabled) {
      safeUnlink(req.file && req.file.path);
      next(new AppError(410, 'VOICE_LEGACY_CLONE_DISABLED', '旧版服务端音色上传已关闭', '新版本参考音频只保存在手机本地，生成配音时再临时上传。'));
      return;
    }
    try {
      const profile = await registerClone({ file: req.file, body: req.body || {}, req, userId: req.user && req.user.id });
      res.status(201).json({ ok: true, data: { profile, state: getCloneState(req.user && req.user.id) } });
    } catch (nestedError) {
      next(nestedError);
    }
  });
});

router.get('/voice/clone/guest', requireUser, (req, res) => {
  res.setHeader('cache-control', 'no-store');
  res.json({ ok: true, data: getGuestCloneSummary() });
});

router.post('/voice/clone/adopt', requireUser, (req, res, next) => {
  try {
    const state = adoptGuestClone({ body: req.body || {}, req, userId: req.user.id });
    res.json({ ok: true, data: state });
  } catch (error) { next(error); }
});

router.post('/voice/clone/consent', (req, res, next) => {
  try {
    res.json({ ok: true, data: renewConsent({ body: req.body || {}, req, userId: req.user && req.user.id }) });
  } catch (error) { next(error); }
});

router.delete('/voice/clone', (req, res, next) => {
  try {
    const userId = req.user && req.user.id;
    const result = deleteClone({ req, reason: req.query && req.query.reason, userId });
    res.json({ ok: true, data: Object.assign({}, result, { state: getCloneState(userId) }) });
  } catch (error) { next(error); }
});

router.get('/voice/clone/reference.mp3', (req, res, next) => {
  try {
    const file = getCloneSamplePath(req.query && req.query.u);
    if (!file) throw new AppError(404, 'VOICE_CLONE_NOT_FOUND', '还没有保存的声音，请先录制');
    res.setHeader('cache-control', 'private, max-age=0, no-store');
    res.type('audio/mpeg');
    res.sendFile(file);
  } catch (error) { next(error); }
});

router.get('/voice/catalog/:id', (req, res, next) => {
  try {
    const voice = getVoiceBySlug(req.params.id);
    if (!voice) throw new AppError(404, 'VOICE_NOT_FOUND', '音色不存在');
    res.json({ ok: true, data: { ...voice, sampleUrl: '/api/voice/sample/' + encodeURIComponent(voice.id) + '.mp3' } });
  } catch (error) { next(error); }
});

router.get('/voice/sample/:id.mp3', async (req, res, next) => {
  try {
    const voiceId = String(req.params.id || '').replace(/\.mp3$/i, '');
    if (!getVoiceBySlug(voiceId)) throw new AppError(404, 'VOICE_NOT_FOUND', '音色不存在');
    const file = await ensureVoiceSample(voiceId);
    res.setHeader('cache-control', 'public, max-age=86400');
    res.type('audio/mpeg');
    res.sendFile(file);
  } catch (error) { next(error); }
});

router.get('/voice/sample/:id/text', (req, res, next) => {
  try { res.json({ ok: true, data: getVoiceSampleText(req.params.id) }); } catch (error) { next(error); }
});

router.post('/voice/synthesize-reference', (req, res, next) => {
  referenceUpload.single('file')(req, res, async (error) => {
    if (error) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        next(new AppError(413, 'VOICE_CLONE_TOO_LARGE', '参考音频不能超过 ' + Math.round(config.maxVoiceCloneBytes / 1024 / 1024) + 'MB'));
        return;
      }
      next(error);
      return;
    }
    const file = req.file;
    try {
      if (!file || !file.path) throw new AppError(400, 'VOICE_REFERENCE_MISSING', '请先选择本机参考音频');
      assertVoiceConsentFields(req.body || {});
      let duration = 0;
      try { duration = await probeDuration(file.path); } catch (error) { duration = 0; }
      assertVoiceCloneAudio(duration);
      const job = createVoiceJob({
        text: req.body && req.body.text,
        speed: req.body && req.body.speed,
        voiceId: (req.body && req.body.voiceId) || 'my-voice',
        referencePath: file.path
      }, req.user && req.user.id);
      res.status(202).json({ ok: true, data: publicVoiceJob(job) });
    } catch (nestedError) {
      safeUnlink(file && file.path);
      next(nestedError);
    }
  });
});

router.post('/voice/synthesize', (req, res, next) => {
  try {
    const job = createVoiceJob(req.body || {}, req.user && req.user.id);
    res.status(202).json({ ok: true, data: publicVoiceJob(job) });
  } catch (error) { next(error); }
});

router.get('/voice/jobs/:id', (req, res, next) => {
  try { res.json({ ok: true, data: publicVoiceJob(ownedJob(req, req.params.id)) }); } catch (error) { next(error); }
});

router.delete('/voice/jobs/:id', (req, res, next) => {
  try {
    ownedJob(req, req.params.id);
    res.json({ ok: true, data: { deleted: deleteVoiceJob(req.params.id) } });
  } catch (error) { next(error); }
});

router.get('/voice/result/:id.mp3', (req, res, next) => {
  try {
    res.setHeader('cache-control', 'private, max-age=3600');
    res.type('audio/mpeg');
    res.sendFile(getVoiceOutput(req.params.id));
  } catch (error) { next(error); }
});

router.get('/voice/result/:id.mp4', async (req, res, next) => {
  try {
    res.setHeader('cache-control', 'private, max-age=3600');
    res.type('video/mp4');
    res.sendFile(await getVoiceMp4(req.params.id));
  } catch (error) { next(error); }
});

export default router;
