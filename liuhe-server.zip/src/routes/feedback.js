import express from 'express';
import { createFeedback } from '../services/feedback.js';

const router = express.Router();

router.post('/feedback', (req, res, next) => {
  try {
    const result = createFeedback({ body: req.body || {}, req });
    res.status(201).json({ ok: true, data: result });
  } catch (error) {
    next(error);
  }
});

export default router;
