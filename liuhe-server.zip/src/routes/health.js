import express from 'express';
import { config } from '../config.js';
import { engineInfo, publicEngineInfo } from '../services/voice.js';
import { getMusicCatalog } from '../services/music-library.js';

const router = express.Router();

router.get('/health', (req, res) => {
  res.setHeader('cache-control', 'no-store');
  res.json({
    ok: true,
    data: {
      app: '六和 API',
      version: config.version,
      demoMode: config.demoMode,
      asrProvider: config.asrProvider,
      resolverProvider: config.demoMode ? 'mock' : config.customResolverUrl ? 'custom' : 'native',
      whisperModel: config.whisperModel,
      followModel: config.followModel,
      watermark: true,
      imageVideo: true,
      imageVideoMaxImages: config.imageVideoMaxImages,
      imageVideoMaxSeconds: config.maxImageVideoSeconds,
      voice: publicEngineInfo(engineInfo()),
      voiceCatalog: true,
      musicTracks: getMusicCatalog().tracks.length,
      free: true,
      uptime: Math.round(process.uptime())
    }
  });
});

router.get('/', (req, res) => {
  res.json({
    ok: true,
    data: {
      name: '六和 API',
      version: config.version,
      description: '无水印视频 · 图片成片 · 文字配音 · 提词器 · 字幕 · 视频修复 · 完全免费',
      endpoints: [
        'POST /api/resolve',
        'POST /api/subtitles/link',
        'POST /api/subtitles/upload',
        'GET /api/subtitles/:id',
        'POST /api/follow/start',
        'POST /api/watermark/preview',
        'POST /api/photo/process',
        'GET /api/image-video/presets',
        'POST /api/image-video/upload',
        'POST /api/image-video/extract-audio',
        'POST /api/image-video/create',
        'GET /api/image-video/:id',
        'GET /api/image-video/result/:id.mp4',
        'GET /api/voice/catalog',
        'GET /api/voice/sample/:id.mp3',
        'POST /api/voice/synthesize',
        'GET /api/voice/jobs/:id',
        'GET /api/voice/result/:id.mp3',
        'GET /api/health'
      ]
    }
  });
});

export default router;
