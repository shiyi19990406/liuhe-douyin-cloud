import express from 'express';
import { Readable } from 'node:stream';
import { verifyToken } from '../lib/sign.js';
import { fetchWithTimeout, withRefererFor } from '../lib/http.js';
import { AppError } from '../lib/errors.js';
import { safeFilename } from '../lib/url.js';

const router = express.Router();

async function streamAsset(req, res, expectedKind) {
  const payload = verifyToken(req.query.token);
  if (payload.k !== expectedKind) {
    throw new AppError(400, 'TOKEN_KIND_MISMATCH', '媒体凭证类型不匹配');
  }
  const upstreamUrl = payload.u;
  if (!/^https?:\/\//i.test(upstreamUrl)) {
    throw new AppError(400, 'BAD_MEDIA_URL', '媒体地址无效');
  }

  const headers = {
    accept: '*/*',
    referer: withRefererFor(upstreamUrl)
  };
  if (req.headers.range) headers.range = req.headers.range;

  const upstream = await fetchWithTimeout(upstreamUrl, { headers }, expectedKind === 'media' ? 120000 : 30000);
  if (!upstream.ok && upstream.status !== 206) {
    throw new AppError(
      502,
      'MEDIA_UPSTREAM_FAILED',
      '视频源暂时不可用',
      '直链可能已过期，请重新解析后再试。'
    );
  }

  const contentType = upstream.headers.get('content-type') || (expectedKind === 'image' ? 'image/jpeg' : 'video/mp4');
  if (expectedKind === 'media' && /text\/html/i.test(contentType)) {
    throw new AppError(502, 'MEDIA_NOT_VIDEO', '视频源返回了网页而不是视频', '请重新解析这条链接。');
  }

  res.status(upstream.status);
  res.setHeader('content-type', contentType);
  res.setHeader('access-control-allow-origin', '*');
  res.setHeader('cache-control', expectedKind === 'image' ? 'public, max-age=3600' : 'private, max-age=3600');
  const contentLength = upstream.headers.get('content-length');
  const contentRange = upstream.headers.get('content-range');
  const acceptRanges = upstream.headers.get('accept-ranges');
  if (contentLength) res.setHeader('content-length', contentLength);
  if (contentRange) res.setHeader('content-range', contentRange);
  if (acceptRanges) res.setHeader('accept-ranges', acceptRanges);
  else if (expectedKind === 'media') res.setHeader('accept-ranges', 'bytes');
  if (expectedKind === 'media' && req.query.download === '1') {
    const filename = safeFilename(payload.f, 'liuhe-video.mp4');
    res.setHeader(
      'content-disposition',
      `attachment; filename*=UTF-8''${encodeURIComponent(filename.endsWith('.mp4') ? filename : filename + '.mp4')}`
    );
  }

  if (!upstream.body) {
    res.end();
    return;
  }
  const stream = Readable.fromWeb(upstream.body);
  stream.on('error', () => {
    if (!res.headersSent) res.status(502).end();
    else res.destroy();
  });
  req.on('close', () => {
    if (!res.writableEnded) stream.destroy();
  });
  stream.pipe(res);
}

router.get('/media.mp4', async (req, res, next) => {
  try {
    await streamAsset(req, res, 'media');
  } catch (error) {
    next(error);
  }
});

router.get('/image.jpg', async (req, res, next) => {
  try {
    await streamAsset(req, res, 'image');
  } catch (error) {
    next(error);
  }
});

router.get('/media', async (req, res, next) => {
  try {
    await streamAsset(req, res, 'media');
  } catch (error) {
    next(error);
  }
});

router.get('/image', async (req, res, next) => {
  try {
    await streamAsset(req, res, 'image');
  } catch (error) {
    next(error);
  }
});

export default router;
