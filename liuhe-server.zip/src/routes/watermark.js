import express from 'express';
import multer from 'multer';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import {
  createPreview,
  createWatermarkJob,
  publicWatermarkJob,
  getWatermarkOutput,
  getAssetFrame,
  deleteWatermarkJob
} from '../services/watermark.js';

const router = express.Router();

const storage = multer.diskStorage({
  destination(req, file, callback) {
    callback(null, config.uploadDir);
  },
  filename(req, file, callback) {
    const ext = path.extname(file.originalname || '').toLowerCase().slice(0, 8) || '.mp4';
    callback(null, crypto.randomUUID() + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: config.maxUploadBytes, files: 1 },
  fileFilter(req, file, callback) {
    const mime = String(file.mimetype || '');
    const name = String(file.originalname || '').toLowerCase();
    if (mime.startsWith('video/') || /\.(mp4|mov|m4v|webm|mkv|avi|3gp)$/i.test(name) || mime === 'application/octet-stream') {
      callback(null, true);
      return;
    }
    callback(new AppError(415, 'UNSUPPORTED_FILE', '请选择视频文件'));
  }
});

router.post('/watermark/preview', (req, res, next) => {
  upload.single('file')(req, res, async (error) => {
    if (error) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        next(new AppError(413, 'FILE_TOO_LARGE', '视频超过 ' + config.maxUploadMb + 'MB 限制'));
        return;
      }
      next(error);
      return;
    }
    try {
      if (!req.file) throw new AppError(400, 'NO_FILE', '没有收到视频文件');
      const data = await createPreview(req.file, req.file.originalname);
      res.status(201).json({ ok: true, data });
    } catch (nestedError) {
      next(nestedError);
    }
  });
});

router.get('/watermark/frame/:assetId/:index.jpg', (req, res, next) => {
  try {
    const framePath = getAssetFrame(req.params.assetId, req.params.index);
    res.setHeader('cache-control', 'private, max-age=600');
    res.type('jpg');
    res.sendFile(framePath);
  } catch (error) {
    next(error);
  }
});

router.post('/watermark/remove', (req, res, next) => {
  try {
    const job = createWatermarkJob(req.body || {});
    res.status(202).json({ ok: true, data: job });
  } catch (error) {
    next(error);
  }
});

router.get('/watermark/result/:jobId/video.mp4', (req, res, next) => {
  try {
    const outputPath = getWatermarkOutput(req.params.jobId);
    res.setHeader('cache-control', 'private, max-age=3600');
    res.type('mp4');
    res.sendFile(outputPath);
  } catch (error) {
    next(error);
  }
});

router.get('/watermark/:jobId', (req, res, next) => {
  try {
    res.setHeader('cache-control', 'no-store');
    res.json({ ok: true, data: publicWatermarkJob(req.params.jobId) });
  } catch (error) {
    next(error);
  }
});

router.delete('/watermark/:jobId', (req, res, next) => {
  try {
    res.json({ ok: true, data: { removed: deleteWatermarkJob(req.params.jobId) } });
  } catch (error) {
    next(error);
  }
});

export default router;
