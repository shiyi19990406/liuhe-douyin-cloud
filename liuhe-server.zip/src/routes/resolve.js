import express from 'express';
import { resolveVideo } from '../services/resolver/index.js';
import { imagePath, mediaPath } from '../lib/sign.js';
import { safeFilename } from '../lib/url.js';
import { AppError } from '../lib/errors.js';
import { config } from '../config.js';

const DIRECT_PROBE_TTL_MS = 5 * 60 * 1000;
const directProbeCache = new Map();
const MOBILE_UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0';

function readProbeCache(url) {
  const hit = directProbeCache.get(url);
  if (!hit) return null;
  if (Date.now() - hit.at > DIRECT_PROBE_TTL_MS) {
    directProbeCache.delete(url);
    return null;
  }
  return hit.ok;
}

function writeProbeCache(url, ok) {
  if (directProbeCache.size >= 120) {
    const oldest = directProbeCache.keys().next().value;
    if (oldest) directProbeCache.delete(oldest);
  }
  directProbeCache.set(url, { ok, at: Date.now() });
}

async function directUrlUsable(url) {
  if (!/^https?:\/\//i.test(url)) return false;
  const cached = readProbeCache(url);
  if (cached !== null) return cached;
  let ok = false;
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'user-agent': MOBILE_UA,
        accept: '*/*',
        range: 'bytes=0-0'
      },
      redirect: 'follow',
      signal: AbortSignal.timeout(2000)
    });
    const type = String(response.headers.get('content-type') || '');
    ok = (response.status === 200 || response.status === 206) && (/^video\//i.test(type) || /octet-stream/i.test(type));
    if (response.body && response.body.cancel) response.body.cancel().catch(() => {});
  } catch (error) {
    ok = false;
  }
  writeProbeCache(url, ok);
  return ok;
}

const router = express.Router();

export async function publicResolveResult(result) {
  const rawImages = Array.isArray(result.images)
    ? result.images.filter((item) => typeof item === 'string' && /^https?:\/\//i.test(item)).slice(0, 40)
    : [];
  const type = result.type || (result.videoUrl ? 'video' : rawImages.length ? 'images' : 'video');
  const title = result.title || (type === 'images' ? '图片' : '视频');
  const sourceVideoUrl = result.videoUrl || '';
  let videoUrl = type === 'video' ? sourceVideoUrl : '';
  if (videoUrl && !videoUrl.startsWith('/')) {
    videoUrl = mediaPath(videoUrl, safeFilename(title, 'liuhe-video') + '.mp4');
  }
  const directUrl = type === 'video' && config.mediaDirectEnabled && sourceVideoUrl && !sourceVideoUrl.startsWith('/') && await directUrlUsable(sourceVideoUrl)
    ? sourceVideoUrl
    : '';
  const images = rawImages.map((url) => url.startsWith('/') ? url : imagePath(url));
  let coverSource = result.cover || rawImages[0] || '';
  let coverUrl = coverSource;
  if (coverUrl && !coverUrl.startsWith('/')) {
    coverUrl = imagePath(coverUrl);
  }
  return {
    platform: result.platform,
    type,
    id: result.id || '',
    title,
    author: result.author || '',
    authorId: result.authorId || '',
    coverUrl,
    videoUrl,
    downloadUrl: videoUrl,
    directUrl,
    directDownloadUrl: directUrl,
    images,
    imageCount: images.length,
    duration: Math.round((result.duration || 0) * 10) / 10,
    stats: result.stats || {},
    quality: result.quality || '原片',
    sourceUrl: result.sourceUrl || '',
    music: result.music || '',
    demo: !!result.demo,
    resolver: result.resolver || 'native'
  };
}

router.post('/resolve', async (req, res, next) => {
  try {
    const text = String((req.body && (req.body.text || req.body.url)) || '').trim();
    if (!text) throw new AppError(400, 'NO_INPUT', '请粘贴小红书、抖音或快手分享链接');
    const result = await resolveVideo(text);
    res.json({ ok: true, data: await publicResolveResult(result) });
  } catch (error) {
    next(error);
  }
});

export default router;
