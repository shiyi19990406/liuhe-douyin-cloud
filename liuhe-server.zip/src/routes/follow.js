import express from 'express';
import { createFollowSession, appendPcm, getFollowState, stopFollowSession } from '../services/follow.js';

const router = express.Router();

router.post('/follow/start', (req, res) => {
  res.json({ ok: true, data: createFollowSession() });
});

router.post('/follow/chunk', express.raw({ type: '*/*', limit: '4mb' }), (req, res, next) => {
  try {
    const sessionId = String(req.query.sessionId || '');
    const chunk = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!sessionId) {
      res.status(400).json({ ok: false, error: { code: 'NO_SESSION', message: '缺少跟读会话' } });
      return;
    }
    res.status(202).json({ ok: true, data: appendPcm(sessionId, chunk) });
  } catch (error) {
    next(error);
  }
});

router.get('/follow/state', (req, res, next) => {
  try {
    const state = getFollowState(String(req.query.sessionId || ''));
    res.setHeader('cache-control', 'no-store');
    res.json({ ok: true, data: state });
  } catch (error) {
    next(error);
  }
});

router.post('/follow/stop', (req, res, next) => {
  try {
    const data = stopFollowSession(String((req.body && req.body.sessionId) || ''));
    res.json({ ok: true, data });
  } catch (error) {
    next(error);
  }
});

export default router;
