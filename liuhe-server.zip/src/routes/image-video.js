import express from 'express';
import multer from 'multer';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import {
  registerUpload,
  extractAudioFromVideo,
  getPresets,
  createImageVideoJob,
  getImageVideoJob,
  getImageVideoOutput,
  deleteImageVideoJob,
  deleteUpload,
  getUpload,
  publicImageVideoJob
} from '../services/image-video.js';
import { getMusicCatalog, ensureMusicTrack, getMusicOutput } from '../services/music-library.js';

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadDir),
  filename: (req, file, cb) => cb(null, crypto.randomUUID() + (path.extname(file.originalname || '') || '.bin'))
});
const upload = multer({ storage, limits: { fileSize: config.maxUploadBytes, files: 1 } });

router.get('/image-video/presets', (req, res) => {
  res.setHeader('cache-control', 'public, max-age=300');
  res.json({ ok: true, data: { ...getPresets(), music: getMusicCatalog() } });
});

router.get('/image-video/music', (req, res) => {
  res.setHeader('cache-control', 'public, max-age=300');
  res.json({ ok: true, data: getMusicCatalog() });
});

router.get('/image-video/music/:id.mp3', async (req, res, next) => {
  try {
    const id = String(req.params.id || '').replace(/\.mp3$/i, '');
    await ensureMusicTrack(id);
    const { file } = getMusicOutput(id);
    res.setHeader('cache-control', 'public, max-age=86400');
    res.type('audio/mpeg');
    res.sendFile(file);
  } catch (error) { next(error); }
});

router.post('/image-video/upload', (req, res, next) => {
  upload.single('file')(req, res, async (error) => {
    if (error) return next(error);
    try {
      const kind = String((req.query && req.query.kind) || (req.body && req.body.kind) || '');
      const asset = await registerUpload(req.file, kind);
      res.status(201).json({ ok: true, data: asset });
    } catch (nestedError) { next(nestedError); }
  });
});

router.get('/image-video/upload/:id/preview', (req, res, next) => {
  try {
    const asset = getUpload(req.params.id);
    if (asset.kind !== 'image') throw new AppError(400, 'NOT_AN_IMAGE', '这个素材不是照片');
    res.setHeader('cache-control', 'private, max-age=600');
    res.sendFile(asset.path);
  } catch (error) { next(error); }
});

router.delete('/image-video/upload/:id', (req, res, next) => {
  try { res.json({ ok: true, data: { deleted: deleteUpload(req.params.id) } }); } catch (error) { next(error); }
});

router.post('/image-video/extract-audio', async (req, res, next) => {
  try {
    const videoId = String(req.body && req.body.videoId || '');
    if (!videoId) throw new AppError(400, 'VIDEO_ID_MISSING', '请先选择视频');
    const audio = await extractAudioFromVideo(videoId);
    res.status(201).json({ ok: true, data: audio });
  } catch (error) { next(error); }
});

router.post('/image-video/create', (req, res, next) => {
  try {
    const job = createImageVideoJob(req.body || {});
    res.status(202).json({ ok: true, data: publicImageVideoJob(job) });
  } catch (error) { next(error); }
});

router.get('/image-video/:id', (req, res, next) => {
  try { res.json({ ok: true, data: publicImageVideoJob(getImageVideoJob(req.params.id)) }); } catch (error) { next(error); }
});

router.delete('/image-video/:id', (req, res, next) => {
  try { res.json({ ok: true, data: { deleted: deleteImageVideoJob(req.params.id) } }); } catch (error) { next(error); }
});

router.get('/image-video/result/:id.mp4', (req, res, next) => {
  try {
    res.setHeader('cache-control', 'private, max-age=3600');
    res.type('video/mp4');
    res.sendFile(getImageVideoOutput(req.params.id));
  } catch (error) { next(error); }
});

export default router;
