import express from 'express';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { issueToken, userIdFromOpenid, requireUser } from '../lib/auth.js';

const router = express.Router();

function publicUser(req) {
  if (!req.user) return null;
  return {
    id: req.user.id,
    suffix: req.user.id.slice(-4),
    nickname: req.user.nickname || '',
    avatarUrl: req.user.avatarUrl || '',
    expiresAt: req.user.expiresAt
  };
}

router.get('/auth/me', (req, res) => {
  res.setHeader('cache-control', 'no-store');
  res.json({
    ok: true,
    data: {
      loggedIn: !!req.user,
      user: publicUser(req)
    }
  });
});

router.post('/auth/profile', requireUser, (req, res, next) => {
  try {
    const raw = req.body || {};
    const nickname = String(raw.nickname || '').trim().slice(0, 32);
    const rawAvatar = String(raw.avatarUrl || '').trim();
    const avatarUrl = /^https:\/\//i.test(rawAvatar) ? rawAvatar.slice(0, 512) : req.user.avatarUrl || '';
    const session = issueToken(req.user.id, { nickname, avatarUrl });
    res.json({
      ok: true,
      data: {
        token: session.token,
        expiresAt: session.expiresAt,
        user: {
          id: req.user.id,
          suffix: req.user.id.slice(-4),
          nickname,
          avatarUrl,
          expiresAt: session.expiresAt
        }
      }
    });
  } catch (error) {
    next(error);
  }
});

router.post('/auth/wechat', async (req, res, next) => {
  try {
    const code = String((req.body && req.body.code) || '').trim();
    if (!code) throw new AppError(400, 'WECHAT_CODE_MISSING', '缺少微信登录凭证');
    if (code.length > 256) throw new AppError(400, 'WECHAT_CODE_INVALID', '微信登录凭证无效');

    let openid = '';
    let mock = false;
    if (config.wechatMockLogin) {
      mock = true;
      openid = config.wechatMockOpenid
        ? 'mock_' + config.wechatMockOpenid
        : 'mock_' + crypto.createHash('sha256').update(code).digest('hex').slice(0, 16);
    } else {
      if (!config.wechatSecret) {
        throw new AppError(
          503,
          'WECHAT_LOGIN_NOT_CONFIGURED',
          '服务端还没有配置微信登录',
          '请在 server/.env 设置 WECHAT_SECRET；本地调试可临时设置 WECHAT_MOCK_LOGIN=true。'
        );
      }
      const endpoint = new URL('https://api.weixin.qq.com/sns/jscode2session');
      endpoint.searchParams.set('appid', config.wechatAppId);
      endpoint.searchParams.set('secret', config.wechatSecret);
      endpoint.searchParams.set('js_code', code);
      endpoint.searchParams.set('grant_type', 'authorization_code');

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10000);
      let data = null;
      try {
        const response = await fetch(endpoint, { signal: controller.signal });
        data = await response.json().catch(() => null);
        if (!response.ok) {
          throw new AppError(502, 'WECHAT_LOGIN_FAILED', '微信登录服务暂时不可用', '请稍后重试。');
        }
      } catch (error) {
        if (error instanceof AppError) throw error;
        throw new AppError(502, 'WECHAT_LOGIN_FAILED', '无法连接微信登录服务', '请检查服务器网络后重试。');
      } finally {
        clearTimeout(timer);
      }

      if (!data || data.errcode || !data.openid) {
        const codeText = data && data.errcode ? String(data.errcode) : '';
        throw new AppError(
          401,
          'WECHAT_LOGIN_REJECTED',
          codeText === '40029' ? '登录凭证已失效，请重新登录' : '微信登录没有完成',
          '请重新点击登录；如果持续失败，请检查 WECHAT_APPID / WECHAT_SECRET 是否匹配。'
        );
      }
      openid = String(data.openid);
    }

    const userId = userIdFromOpenid(openid);
    const rawProfile = (req.body && req.body.profile) || {};
    const nickname = String(rawProfile.nickname || '').trim().slice(0, 32);
    const rawAvatar = String(rawProfile.avatarUrl || '').trim();
    const avatarUrl = /^https:\/\//i.test(rawAvatar) ? rawAvatar.slice(0, 512) : '';
    const session = issueToken(userId, { nickname, avatarUrl });
    res.json({
      ok: true,
      data: {
        token: session.token,
        expiresAt: session.expiresAt,
        mock,
        user: {
          id: userId,
          suffix: userId.slice(-4),
          nickname,
          avatarUrl,
          expiresAt: session.expiresAt
        }
      }
    });
  } catch (error) {
    next(error);
  }
});

router.post('/auth/douyin', async (req, res, next) => {
  try {
    const code = String((req.body && req.body.code) || '').trim();
    if (!code) throw new AppError(400, 'DOUYIN_CODE_MISSING', '缺少抖音登录凭证');
    if (code.length > 512) throw new AppError(400, 'DOUYIN_CODE_INVALID', '抖音登录凭证无效');

    let openid = '';
    let mock = false;
    if (config.douyinMockLogin) {
      mock = true;
      openid = 'douyin_mock_' + crypto.createHash('sha256').update(code).digest('hex').slice(0, 16);
    } else {
      if (!config.douyinSecret || !config.douyinAppId) {
        throw new AppError(
          503,
          'DOUYIN_LOGIN_NOT_CONFIGURED',
          '服务端还没有配置抖音登录',
          '请在 server/.env 设置 DOUYIN_APPID / DOUYIN_SECRET；本地调试可临时设置 DOUYIN_MOCK_LOGIN=true。'
        );
      }
      let data = null;
      try {
        const response = await fetch('https://developer.toutiao.com/api/apps/v2/jscode2session', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ appid: config.douyinAppId, secret: config.douyinSecret, code })
        });
        data = await response.json().catch(() => null);
        if (!response.ok) throw new Error('HTTP ' + response.status);
      } catch (error) {
        throw new AppError(502, 'DOUYIN_LOGIN_FAILED', '无法连接抖音登录服务', '请检查服务器网络后重试。');
      }
      if (!data || data.err_no !== 0 || !data.data || !data.data.openid) {
        throw new AppError(
          401,
          'DOUYIN_LOGIN_REJECTED',
          '抖音登录没有完成',
          '请重新点击登录；如果持续失败，请检查 DOUYIN_APPID / DOUYIN_SECRET 是否匹配。'
        );
      }
      openid = String(data.data.openid);
    }

    const userId = userIdFromOpenid(openid);
    const session = issueToken(userId, {});
    res.json({
      ok: true,
      data: {
        token: session.token,
        expiresAt: session.expiresAt,
        mock,
        user: {
          id: userId,
          suffix: userId.slice(-4),
          nickname: '',
          avatarUrl: '',
          expiresAt: session.expiresAt
        }
      }
    });
  } catch (error) {
    next(error);
  }
});

export default router;
