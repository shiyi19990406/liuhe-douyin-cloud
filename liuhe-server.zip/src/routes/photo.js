import express from 'express';
import multer from 'multer';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { processPhoto, getPhotoResult } from '../services/photo.js';

const router = express.Router();

const storage = multer.diskStorage({
  destination(req, file, callback) {
    callback(null, config.uploadDir);
  },
  filename(req, file, callback) {
    const ext = path.extname(file.originalname || '').toLowerCase().slice(0, 8) || '.jpg';
    callback(null, crypto.randomUUID() + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: config.maxPhotoBytes, files: 1 },
  fileFilter(req, file, callback) {
    const mime = String(file.mimetype || '');
    const name = String(file.originalname || '').toLowerCase();
    if (mime.startsWith('image/') || /\.(jpg|jpeg|png|webp|bmp|heic)$/i.test(name)) {
      callback(null, true);
      return;
    }
    callback(new AppError(415, 'UNSUPPORTED_PHOTO', '请选择 JPG / PNG / WebP 图片'));
  }
});

router.post('/photo/process', (req, res, next) => {
  upload.single('file')(req, res, async (error) => {
    if (error) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        next(new AppError(413, 'PHOTO_TOO_LARGE', '图片超过 ' + Math.round(config.maxPhotoBytes / 1024 / 1024) + 'MB 限制'));
        return;
      }
      next(error);
      return;
    }
    try {
      if (!req.file) throw new AppError(400, 'NO_PHOTO', '没有收到图片');
      const data = await processPhoto(req.file, String((req.body && req.body.mode) || 'both'), Number((req.body && req.body.scale) || 2));
      res.status(201).json({ ok: true, data });
    } catch (nestedError) {
      next(nestedError);
    }
  });
});

router.get('/photo/result/:id.jpg', (req, res, next) => {
  try {
    const filePath = getPhotoResult(req.params.id);
    res.setHeader('cache-control', 'private, max-age=3600');
    res.type('jpg');
    res.sendFile(filePath);
  } catch (error) {
    next(error);
  }
});

export default router;
