import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const serverRoot = path.resolve(__dirname, '..');
dotenv.config({ path: path.join(serverRoot, '.env') });

const isProduction = process.env.NODE_ENV === 'production';
const configuredMediaSecret = String(process.env.MEDIA_SIGNING_SECRET || '').trim();
if (isProduction && (!configuredMediaSecret || configuredMediaSecret === 'change-me-to-a-long-random-string' || configuredMediaSecret.length < 32)) {
  throw new Error('生产环境必须在 server/.env 配置至少 32 位随机 MEDIA_SIGNING_SECRET');
}
if (isProduction && bool(process.env.WECHAT_MOCK_LOGIN, false)) {
  throw new Error('生产环境不能开启 WECHAT_MOCK_LOGIN');
}
if (isProduction && process.env.AUTH_SECRET && String(process.env.AUTH_SECRET).length < 32) {
  throw new Error('生产环境 AUTH_SECRET 至少需要 32 位随机字符');
}

function bool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  return /^(1|true|yes|on)$/i.test(String(value));
}

function number(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function firstExisting(candidates, fallback) {
  for (const candidate of candidates) {
    if (candidate && fs.existsSync(candidate)) return candidate;
  }
  return fallback;
}

const venvPython = path.join(serverRoot, '.venv', 'bin', 'python');
const venvYtDlp = path.join(serverRoot, '.venv', 'bin', 'yt-dlp');

export const config = {
  serverRoot,
  port: number(process.env.PORT, 8787),
  host: process.env.HOST || '0.0.0.0',
  demoMode: bool(process.env.DEMO_MODE, false),
  version: '1.2.0',

  mediaSecret: configuredMediaSecret || crypto.randomBytes(32).toString('hex'),
  authSecret: process.env.AUTH_SECRET || configuredMediaSecret || crypto.randomBytes(32).toString('hex'),
  authTokenTtlMs: number(process.env.AUTH_TOKEN_TTL_DAYS, 30) * 24 * 60 * 60 * 1000,
  wechatAppId: process.env.WECHAT_APPID || 'wx140b2865e6b60a8a',
  wechatSecret: String(process.env.WECHAT_SECRET || '').trim(),
  wechatMockLogin: bool(process.env.WECHAT_MOCK_LOGIN, false),
  wechatMockOpenid: String(process.env.WECHAT_MOCK_OPENID || '').trim(),
  douyinAppId: String(process.env.DOUYIN_APPID || '').trim(),
  douyinSecret: String(process.env.DOUYIN_SECRET || '').trim(),
  douyinMockLogin: bool(process.env.DOUYIN_MOCK_LOGIN, false),
  feedbackDir: path.join(serverRoot, 'data', 'feedback'),
  mediaTtlMs: number(process.env.MEDIA_TTL_MS, 6 * 60 * 60 * 1000),
  mediaDirectEnabled: process.env.MEDIA_DIRECT_ENABLED !== 'false',
  jobTtlMs: number(process.env.JOB_TTL_MS, 60 * 60 * 1000),

  maxUploadBytes: number(process.env.MAX_UPLOAD_MB, 200) * 1024 * 1024,
  maxUploadMb: number(process.env.MAX_UPLOAD_MB, 200),
  maxVideoSeconds: number(process.env.MAX_VIDEO_SECONDS, 20 * 60),
  maxWatermarkSeconds: number(process.env.MAX_WATERMARK_SECONDS, 5 * 60),

  uploadDir: path.join(serverRoot, 'tmp', 'uploads'),
  workDir: path.join(serverRoot, 'tmp', 'work'),
  watermarkDir: path.join(serverRoot, 'tmp', 'watermark'),
  photoDir: path.join(serverRoot, 'tmp', 'photo'),
  voiceDir: path.join(serverRoot, 'tmp', 'voice'),
  overlayDir: path.join(serverRoot, 'tmp', 'overlay'),
  publicDir: path.join(serverRoot, 'public'),
  demoVideoPath: path.join(serverRoot, 'public', 'demo', 'demo.mp4'),
  demoCoverPath: path.join(serverRoot, 'public', 'demo', 'cover.jpg'),

  ffmpegPath: process.env.FFMPEG_PATH || 'ffmpeg',
  ffprobePath: process.env.FFPROBE_PATH || 'ffprobe',

  asrProvider: String(process.env.ASR_PROVIDER || 'local').toLowerCase(),
  pythonBin: process.env.ASR_PYTHON || firstExisting([venvPython], 'python3'),
  whisperWorker: path.join(serverRoot, 'python', 'whisper_worker.py'),
  watermarkWorker: path.join(serverRoot, 'python', 'watermark_remove.py'),
  photoWorker: path.join(serverRoot, 'python', 'photo_restore.py'),
  colorModelDir: path.join(serverRoot, 'models', 'colorization'),
  nltkDataDir: path.join(serverRoot, 'models', 'nltk_data'),
  voiceOpenVoiceDir: process.env.VOICE_OPENVOICE_DIR || path.join(serverRoot, 'models', 'voices', 'openvoice'),
  voiceCatalogPath: path.join(serverRoot, 'data', 'voice-catalog.json'),
  voiceProvider: String(process.env.VOICE_PROVIDER || 'local').toLowerCase(),
  voiceHttpBase: (process.env.VOICE_HTTP_BASE || '').replace(/\/$/, ''),
  voiceServiceUrl: (process.env.VOICE_SERVICE_URL || '').replace(/\/$/, ''),
  voiceServiceKey: process.env.VOICE_SERVICE_KEY || '',
  voiceHttpKey: process.env.VOICE_HTTP_KEY || '',
  voiceHttpModel: process.env.VOICE_HTTP_MODEL || 'default',
  voiceSampleDir: path.join(serverRoot, 'public', 'voice-samples'),
  voiceCloneDir: path.join(serverRoot, 'data', 'voice-clone'),
  voiceCloneReferencePath: path.join(serverRoot, 'data', 'voice-clone', 'reference.mp3'),
  voiceConsentVersion: process.env.VOICE_CONSENT_VERSION || '2026-10-21-v3',
  voiceAllowGuestAdoption: bool(process.env.VOICE_ALLOW_GUEST_ADOPTION, false),
  voiceLegacyCloneEnabled: bool(process.env.VOICE_LEGACY_CLONE_ENABLED, false),
  maxVoiceCloneBytes: number(process.env.MAX_VOICE_CLONE_MB, 20) * 1024 * 1024,
  minVoiceCloneSeconds: number(process.env.MIN_VOICE_CLONE_SECONDS, 6),
  maxVoiceCloneSeconds: number(process.env.MAX_VOICE_CLONE_SECONDS, 60),
  ttsWorker: path.join(serverRoot, 'python', 'openvoice_worker.py'),
  voiceDaemonWorker: path.join(serverRoot, 'python', 'openvoice_daemon.py'),
  maxVoiceChars: number(process.env.MAX_VOICE_CHARS, 1200),
  imageVideoDir: path.join(serverRoot, 'tmp', 'image-video'),
  imageVideoMaxImages: number(process.env.IMAGE_VIDEO_MAX_IMAGES, 9),
  maxImageVideoSeconds: number(process.env.MAX_IMAGE_VIDEO_SECONDS, 60),
  musicDir: path.join(serverRoot, 'public', 'music'),
  musicWorker: path.join(serverRoot, 'python', 'generate_music.py'),
  overlayWorker: path.join(serverRoot, 'python', 'render_overlay.py'),
  overlayFontPath: process.env.OVERLAY_FONT_PATH || '',
  maxPhotoBytes: number(process.env.MAX_PHOTO_MB, 25) * 1024 * 1024,
  whisperModel: process.env.WHISPER_MODEL || 'small',
  whisperDevice: process.env.WHISPER_DEVICE || 'cpu',
  whisperComputeType: process.env.WHISPER_COMPUTE_TYPE || 'int8',
  whisperLanguage: process.env.WHISPER_LANGUAGE || 'zh',
  whisperBeamSize: number(process.env.WHISPER_BEAM_SIZE, 5),
  followModel: process.env.WHISPER_FOLLOW_MODEL || 'base',
  followBeamSize: number(process.env.WHISPER_FOLLOW_BEAM_SIZE, 1),
  hfEndpoint: process.env.HF_ENDPOINT || '',


  browserResolverEnabled: bool(process.env.BROWSER_RESOLVER, true),
  chromePath: process.env.CHROME_PATH || '',
  chromeNoSandbox: bool(process.env.CHROME_NO_SANDBOX, false),

  ytdlpEnabled: bool(process.env.YTDLP_ENABLED, true),
  ytdlpBin: process.env.YTDLP_BIN || firstExisting([venvYtDlp], 'yt-dlp'),
  ytdlpCookiesFile: process.env.YTDLP_COOKIES_FILE || '',

  xhsCookie: String(process.env.XHS_COOKIE || '').trim(),

  customResolverUrl: process.env.CUSTOM_RESOLVER_URL || '',
  customResolverToken: process.env.CUSTOM_RESOLVER_TOKEN || '',
  publicBaseUrl: (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '')
};

for (const dir of [config.uploadDir, config.workDir, config.watermarkDir, config.photoDir, config.imageVideoDir, config.voiceDir, config.overlayDir, config.voiceSampleDir, config.musicDir, config.feedbackDir]) {
  fs.mkdirSync(dir, { recursive: true });
}
