import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { runCommand, probeDuration } from '../lib/process.js';

const catalogFile = path.join(config.serverRoot, 'data', 'music-catalog.json');
const catalog = JSON.parse(fs.readFileSync(catalogFile, 'utf8'));
const tracks = (catalog.tracks || []).map((track) => ({ ...track }));
const trackMap = new Map(tracks.map((track) => [track.id, track]));
const pending = new Map();

function trackPath(id) {
  return path.join(config.musicDir, id + '.mp3');
}

function publicTrack(track) {
  return {
    ...track,
    url: '/api/image-video/music/' + encodeURIComponent(track.id) + '.mp3',
    license: catalog.license,
    source: catalog.source
  };
}

export function getMusicCatalog() {
  return {
    license: catalog.license,
    source: catalog.source,
    tracks: tracks.map(publicTrack),
    moods: Array.from(new Set(tracks.map((track) => track.mood)))
  };
}

export function getMusicTrack(id) {
  return trackMap.get(String(id)) || null;
}

export async function ensureMusicTrack(id) {
  const track = getMusicTrack(id);
  if (!track) throw new AppError(404, 'MUSIC_NOT_FOUND', '内置音乐不存在');
  const file = trackPath(track.id);
  if (fs.existsSync(file)) {
    const stat = await fs.promises.stat(file);
    if (stat.size > 1024) return file;
  }
  if (pending.has(track.id)) return pending.get(track.id);
  const promise = (async () => {
    const python = config.pythonBin;
    if (!fs.existsSync(python)) throw new AppError(503, 'MUSIC_ENGINE_MISSING', '缺少 Python 运行环境，无法生成内置音乐');
    await runCommand(python, [config.musicWorker, '--id', track.id, '--output-dir', config.musicDir], {
      timeoutMs: 5 * 60 * 1000
    });
    if (!fs.existsSync(file)) throw new AppError(500, 'MUSIC_GENERATE_FAILED', '内置音乐生成失败');
    return file;
  })();
  pending.set(track.id, promise);
  try {
    return await promise;
  } finally {
    pending.delete(track.id);
  }
}

export async function resolveMusic(id) {
  const track = getMusicTrack(id);
  if (!track) throw new AppError(404, 'MUSIC_NOT_FOUND', '内置音乐不存在');
  const file = await ensureMusicTrack(track.id);
  const duration = await probeDuration(file);
  return {
    ...publicTrack(track),
    path: file,
    duration: duration || track.duration
  };
}

export function getMusicOutput(id) {
  const track = getMusicTrack(id);
  if (!track) throw new AppError(404, 'MUSIC_NOT_FOUND', '内置音乐不存在');
  const file = trackPath(track.id);
  if (!fs.existsSync(file)) throw new AppError(404, 'MUSIC_NOT_READY', '内置音乐尚未生成');
  return { file, track };
}
