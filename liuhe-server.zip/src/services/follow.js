import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { safeUnlink } from '../lib/process.js';
import { transcribeWithFollow } from './asr/index.js';

const SAMPLE_RATE = 16000;
const CHANNELS = 1;
const BYTES_PER_SAMPLE = 2;
const CHUNK_SECONDS = Number(process.env.FOLLOW_CHUNK_SECONDS) || 2.2;
const OVERLAP_SECONDS = 0.3;
const CHUNK_BYTES = Math.floor(SAMPLE_RATE * BYTES_PER_SAMPLE * CHUNK_SECONDS);
const OVERLAP_BYTES = Math.floor(SAMPLE_RATE * BYTES_PER_SAMPLE * OVERLAP_SECONDS);
const sessions = new Map();

function wavHeader(dataLength) {
  const header = Buffer.alloc(44);
  const byteRate = SAMPLE_RATE * CHANNELS * BYTES_PER_SAMPLE;
  const blockAlign = CHANNELS * BYTES_PER_SAMPLE;
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataLength, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(CHANNELS, 22);
  header.writeUInt32LE(SAMPLE_RATE, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataLength, 40);
  return header;
}

function mergeText(previous, next) {
  const prev = String(previous || '');
  const incoming = String(next || '').replace(/\s+/g, '');
  if (!incoming) return prev;
  if (!prev) return incoming;
  for (let length = Math.min(12, prev.length, incoming.length); length >= 2; length -= 1) {
    if (prev.endsWith(incoming.slice(0, length))) {
      return prev + incoming.slice(length);
    }
  }
  return prev + incoming;
}

export function createFollowSession() {
  const id = crypto.randomUUID();
  const session = {
    id,
    buffer: Buffer.alloc(0),
    overlap: Buffer.alloc(0),
    processing: false,
    fullText: '',
    lastText: '',
    status: 'listening',
    error: null,
    samples: 0,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  sessions.set(id, session);
  return {
    sessionId: id,
    sampleRate: SAMPLE_RATE,
    channels: CHANNELS,
    chunkSeconds: CHUNK_SECONDS,
    pollMs: 900
  };
}

export function getFollowSession(id) {
  const session = sessions.get(id);
  if (!session) throw new AppError(404, 'FOLLOW_SESSION_NOT_FOUND', '语音跟读会话已结束，请重新开始');
  return session;
}

export function appendPcm(id, chunk) {
  const session = getFollowSession(id);
  if (!chunk || !chunk.length) return { accepted: true };
  // 防止客户端异常导致无限增长；只保留最近 20 秒未处理音频。
  const maxBuffer = SAMPLE_RATE * BYTES_PER_SAMPLE * 20;
  session.buffer = Buffer.concat([session.buffer, chunk]);
  if (session.buffer.length > maxBuffer) {
    session.buffer = session.buffer.slice(session.buffer.length - maxBuffer);
  }
  session.samples += chunk.length;
  session.updatedAt = Date.now();
  if (!session.processing && session.buffer.length >= CHUNK_BYTES) {
    setImmediate(() => processSession(session));
  }
  return { accepted: true };
}

async function processSession(session) {
  if (session.processing) return;
  if (session.buffer.length < CHUNK_BYTES) return;
  session.processing = true;
  session.status = 'transcribing';
  session.updatedAt = Date.now();
  const pcm = Buffer.concat([session.overlap, session.buffer]);
  session.buffer = Buffer.alloc(0);
  session.overlap = pcm.slice(Math.max(0, pcm.length - OVERLAP_BYTES));
  const wavPath = path.join(config.workDir, 'follow-' + session.id + '-' + Date.now() + '.wav');
  try {
    await fs.promises.writeFile(wavPath, Buffer.concat([wavHeader(pcm.length), pcm]));
    const result = await transcribeWithFollow(wavPath, {
      language: 'zh',
      onStage: () => {
        session.updatedAt = Date.now();
      }
    });
    const text = (result.segments || []).map((segment) => segment.text).join('').trim();
    if (text) {
      session.fullText = mergeText(session.fullText, text);
      session.lastText = text;
    }
    session.status = 'listening';
    session.error = null;
  } catch (error) {
    session.status = 'error';
    session.error = {
      code: error.code || 'FOLLOW_ASR_FAILED',
      message: error.message || '实时识别失败'
    };
    console.error('[follow]', error.message);
  } finally {
    safeUnlink(wavPath);
    session.processing = false;
    session.updatedAt = Date.now();
    if (session.buffer.length >= CHUNK_BYTES) {
      setImmediate(() => processSession(session));
    }
  }
}

export function getFollowState(id) {
  const session = getFollowSession(id);
  return {
    sessionId: session.id,
    status: session.status,
    text: session.lastText,
    fullText: session.fullText,
    processing: session.processing,
    error: session.error,
    updatedAt: session.updatedAt
  };
}

export function stopFollowSession(id) {
  const session = sessions.get(id);
  if (!session) return { fullText: '' };
  sessions.delete(id);
  return { fullText: session.fullText, lastText: session.lastText };
}

setInterval(() => {
  const cutoff = Date.now() - 10 * 60 * 1000;
  for (const [id, session] of sessions.entries()) {
    if (session.updatedAt < cutoff) sessions.delete(id);
  }
}, 60 * 1000).unref();
