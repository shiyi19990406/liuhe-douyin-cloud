import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { runCommand, probeDuration, safeUnlink } from '../lib/process.js';

const MIN_SECONDS = Math.max(3, Number(config.minVoiceCloneSeconds) || 6);
const MAX_SECONDS = Math.max(MIN_SECONDS + 1, Number(config.maxVoiceCloneSeconds) || 60);

function normalizeUserId(userId) {
  const value = String(userId || '').trim();
  return /^[a-zA-Z0-9_-]{8,64}$/.test(value) ? value : '';
}

function scopePaths(userId) {
  const id = normalizeUserId(userId);
  const dir = id ? path.join(config.voiceCloneDir, 'users', id) : config.voiceCloneDir;
  return {
    id,
    dir,
    profile: path.join(dir, 'profile.json'),
    reference: path.join(dir, 'reference.mp3'),
    consentLog: path.join(dir, 'consent-log.jsonl')
  };
}

function ensureDir(scope) {
  fs.mkdirSync(scope.dir, { recursive: true });
}

function readJson(file) {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const value = JSON.parse(raw);
    return value && typeof value === 'object' ? value : null;
  } catch (error) {
    return null;
  }
}

function formatDuration(seconds) {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  const minute = Math.floor(total / 60);
  const rest = total % 60;
  return minute + ':' + String(rest).padStart(2, '0');
}

function hashFile(file) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(file);
    stream.on('error', reject);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function hashIp(req) {
  const raw = String((req && (req.ip || (req.socket && req.socket.remoteAddress))) || '');
  if (!raw) return '';
  return crypto.createHash('sha256').update(raw + '|' + config.mediaSecret).digest('hex').slice(0, 24);
}

function sanitizeName(value) {
  const text = String(value || '')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 16);
  return text || '我的音色';
}

function readConsentLog(scope) {
  try {
    const raw = fs.readFileSync(scope.consentLog, 'utf8');
    return raw
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        try { return JSON.parse(line); } catch (error) { return null; }
      })
      .filter(Boolean);
  } catch (error) {
    return [];
  }
}

function recordConsent(type, options = {}) {
  const scope = options.scope;
  const entry = {
    type,
    at: Date.now(),
    version: options.version || config.voiceConsentVersion,
    hash: options.hash || null,
    profileId: options.profileId || null,
    reason: options.reason || '',
    ipHash: hashIp(options.req),
    userAgent: String((options.req && options.req.headers && options.req.headers['user-agent']) || '').slice(0, 160)
  };
  ensureDir(scope);
  fs.appendFileSync(scope.consentLog, JSON.stringify(entry) + '\n', 'utf8');
  return entry;
}

function hasValidGrant(profile, log) {
  if (!profile || !profile.hash) return false;
  let grant = null;
  let revoke = null;
  for (const entry of log) {
    if (entry.hash !== profile.hash) continue;
    if (entry.type === 'grant') {
      grant = entry;
      revoke = null;
    } else if (entry.type === 'revoke' && grant && Number(entry.at) >= Number(grant.at)) {
      revoke = entry;
    }
  }
  if (!grant || revoke) return false;
  return grant.version === config.voiceConsentVersion && profile.consentVersion === config.voiceConsentVersion;
}

export function getCloneProfile(userId) {
  const scope = scopePaths(userId);
  const profile = readJson(scope.profile);
  if (!profile || profile.status !== 'ready') return null;
  if (!fs.existsSync(scope.reference)) return null;
  return profile;
}

export function publicCloneProfile(profile, userId) {
  if (!profile) return null;
  const scope = scopePaths(userId);
  const hash = String(profile.hash || '').slice(0, 12);
  const query = ['v=' + hash];
  if (scope.id) query.push('u=' + encodeURIComponent(scope.id));
  return {
    id: profile.id,
    name: profile.name || '我的音色',
    status: 'ready',
    duration: Number(profile.duration) || 0,
    durationText: formatDuration(profile.duration),
    createdAt: Number(profile.createdAt) || 0,
    consentVersion: profile.consentVersion || '',
    hash: String(profile.hash || '').slice(0, 16),
    size: Number(profile.size) || 0,
    sampleUrl: '/api/voice/clone/reference.mp3?' + query.join('&')
  };
}

export function getCloneReferencePath(userId) {
  const scope = scopePaths(userId);
  return getCloneProfile(userId) ? scope.reference : null;
}

export function getCloneSamplePath(userId) {
  const scope = scopePaths(userId);
  return getCloneProfile(userId) ? scope.reference : null;
}

export function getCloneState(userId) {
  const scope = scopePaths(userId);
  const profile = getCloneProfile(userId);
  const log = readConsentLog(scope);
  let grant = null;
  if (profile) {
    for (const entry of log) {
      if (entry.hash === profile.hash && entry.type === 'grant') grant = entry;
    }
  }
  return {
    profile: publicCloneProfile(profile, userId),
    requiredVersion: config.voiceConsentVersion,
    grantedAt: grant ? grant.at : null,
    grantVersion: grant ? grant.version : null,
    valid: hasValidGrant(profile, log),
    minSeconds: MIN_SECONDS,
    maxSeconds: MAX_SECONDS,
    retention: '参考音频保留到你主动删除声音数据为止',
    scope: scope.id ? 'user' : 'guest'
  };
}

export function getGuestCloneSummary() {
  if (!config.voiceAllowGuestAdoption) return { available: false };
  const profile = getCloneProfile(undefined);
  if (!profile) return { available: false };
  return {
    available: true,
    durationText: formatDuration(profile.duration),
    createdAt: Number(profile.createdAt) || 0
  };
}

export function adoptGuestClone({ body, req, userId }) {
  if (!config.voiceAllowGuestAdoption) {
    throw new AppError(403, 'VOICE_GUEST_ADOPTION_DISABLED', '当前服务未开放访客音色绑定', '请直接登录后重新录制音色。');
  }
  const consent = assertConsentFields(body);
  if (!normalizeUserId(userId)) {
    throw new AppError(401, 'AUTH_REQUIRED', '请先使用微信登录');
  }
  if (getCloneProfile(userId)) return getCloneState(userId);
  const guest = getCloneProfile(undefined);
  if (!guest || !guest.hash) {
    throw new AppError(404, 'VOICE_GUEST_CLONE_MISSING', '没有可绑定的登录前音色', '请先在声音克隆页录制一段参考音频。');
  }
  const guestScope = scopePaths(undefined);
  const userScope = scopePaths(userId);
  ensureDir(userScope);
  try {
    fs.copyFileSync(guestScope.reference, userScope.reference);
  } catch (error) {
    throw new AppError(500, 'VOICE_CLONE_ADOPT_FAILED', '音色绑定失败', '请检查服务端数据目录权限。');
  }
  const now = Date.now();
  const profile = Object.assign({}, guest, {
    id: 'clone_' + crypto.randomBytes(6).toString('hex'),
    consentVersion: consent.version,
    consentAcceptedAt: now,
    createdAt: now,
    updatedAt: now
  });
  fs.writeFileSync(userScope.profile, JSON.stringify(profile, null, 2) + '\n', 'utf8');
  recordConsent('grant', {
    scope: userScope,
    version: consent.version,
    hash: profile.hash,
    profileId: profile.id,
    req,
    reason: 'adopt_guest'
  });
  return getCloneState(userId);
}

export function getClonePolicy() {
  return {
    version: config.voiceConsentVersion,
    effectiveAt: config.voiceConsentVersion,
    title: '六和声音克隆服务协议',
    minSeconds: MIN_SECONDS,
    maxSeconds: MAX_SECONDS,
    retention: '参考音频保留到你主动删除声音数据为止',
    summary: [
      '仅可克隆本人声音，或已取得声音权利人明确、可证明的授权。',
      '禁止克隆公众人物、未成年人或他人声音，禁止冒充、诈骗、诽谤、色情与虚假信息。',
      '参考音频上传到你配置的服务器，用于提取音色特征，可随时删除。',
      '声音鉴定仅供娱乐，不构成声学鉴定或身份识别。'
    ]
  };
}

function assertConsentFields(body) {
  const source = body || {};
  const version = String(source.consentVersion || '');
  const accepted = String(source.consentAccepted || '') === 'true';
  const ownership = String(source.ownershipConfirmed || '') === 'true';
  const adult = String(source.adultConfirmed || '') === 'true';
  if (!accepted || !ownership || !adult) {
    throw new AppError(
      403,
      'VOICE_CONSENT_REQUIRED',
      '请先阅读并同意《声音克隆用户协议》',
      '声音克隆仅允许本人或已获明确授权的声音，不同意协议将无法使用。'
    );
  }
  if (version !== config.voiceConsentVersion) {
    throw new AppError(
      403,
      'VOICE_CONSENT_OUTDATED',
      '声音克隆协议已更新，请重新阅读并同意',
      '协议版本：' + config.voiceConsentVersion
    );
  }
  return { version, accepted, ownership, adult };
}

export function assertVoiceConsentFields(body) {
  return assertConsentFields(body);
}

export function assertVoiceCloneAudio(duration) {
  return assertAudioDuration(duration);
}

function assertAudioDuration(duration) {
  if (!Number.isFinite(duration) || duration <= 0) {
    throw new AppError(400, 'VOICE_CLONE_UNREADABLE', '无法读取这段音频', '请换一段 MP3 / M4A / WAV 音频，或重新录制。');
  }
  if (duration < MIN_SECONDS) {
    throw new AppError(
      400,
      'VOICE_CLONE_TOO_SHORT',
      '参考音频太短，请至少录制 ' + Math.ceil(MIN_SECONDS) + ' 秒',
      '建议在安静环境里用正常语速朗读 10–20 秒。'
    );
  }
  if (duration > MAX_SECONDS) {
    throw new AppError(
      400,
      'VOICE_CLONE_TOO_LONG',
      '参考音频过长，请控制在 ' + Math.round(MAX_SECONDS) + ' 秒以内',
      '只需要一小段自然说话，不需要整段朗读。'
    );
  }
}

async function normalizeReference(inputPath, scope) {
  const tempOutput = path.join(scope.dir, 'reference-' + crypto.randomUUID() + '.mp3');
  try {
    await runCommand(config.ffmpegPath, [
      '-y', '-hide_banner', '-loglevel', 'error',
      '-i', inputPath,
      '-vn',
      '-ac', '1',
      '-ar', '24000',
      '-c:a', 'libmp3lame',
      '-b:a', '96k',
      '-af', 'highpass=f=70,lowpass=f=8500,loudnorm=I=-18:TP=-2:LRA=11',
      '-metadata', 'title=六和声音克隆参考音频',
      '-metadata', 'comment=仅用于本人或已获授权的声音克隆',
      tempOutput
    ], { timeoutMs: 120000 });
    const stat = await fs.promises.stat(tempOutput);
    if (!stat.size) throw new AppError(400, 'VOICE_CLONE_EMPTY', '处理后的音频为空', '请重新录制或换一段音频。');
    return { tempOutput, size: stat.size };
  } catch (error) {
    safeUnlink(tempOutput);
    if (error && (error.code === 'PROCESS_TIMEOUT' || error.code === 'MISSING_BINARY')) throw error;
    if (error instanceof AppError && error.status < 500) throw error;
    throw new AppError(400, 'VOICE_CLONE_CONVERT_FAILED', '这段音频无法用于声音克隆', '请换一段清晰的 MP3 / M4A / WAV 音频，或重新录制。');
  }
}

export async function registerClone({ file, body, req, userId }) {
  const consent = assertConsentFields(body);
  if (!file || !file.path) {
    throw new AppError(400, 'VOICE_CLONE_FILE_MISSING', '请先录制或选择一段参考音频');
  }
  const scope = scopePaths(userId);
  ensureDir(scope);
  const inputPath = file.path;
  let duration = 0;
  try {
    duration = await probeDuration(inputPath);
  } catch (error) {
    duration = 0;
  }
  assertAudioDuration(duration);

  const normalized = await normalizeReference(inputPath, scope);
  let finalDuration = 0;
  try {
    finalDuration = (await probeDuration(normalized.tempOutput)) || duration;
    assertAudioDuration(finalDuration);
  } catch (error) {
    safeUnlink(normalized.tempOutput);
    safeUnlink(inputPath);
    throw error;
  }

  try {
    fs.renameSync(normalized.tempOutput, scope.reference);
  } catch (error) {
    safeUnlink(normalized.tempOutput);
    throw new AppError(500, 'VOICE_CLONE_SAVE_FAILED', '参考音频保存失败', '请检查服务端数据目录权限。');
  } finally {
    safeUnlink(inputPath);
  }

  const hash = await hashFile(scope.reference);
  const now = Date.now();
  const profile = {
    id: 'clone_' + crypto.randomBytes(6).toString('hex'),
    name: sanitizeName(body && body.name),
    status: 'ready',
    duration: Math.round(finalDuration * 100) / 100,
    size: normalized.size,
    hash,
    consentVersion: consent.version,
    consentAcceptedAt: now,
    createdAt: now,
    updatedAt: now
  };
  try {
    fs.writeFileSync(scope.profile, JSON.stringify(profile, null, 2) + '\n', 'utf8');
  } catch (error) {
    throw new AppError(500, 'VOICE_CLONE_PROFILE_FAILED', '声音配置保存失败', '请检查服务端数据目录权限。');
  }

  recordConsent('grant', {
    scope,
    version: consent.version,
    hash,
    profileId: profile.id,
    req
  });

  return publicCloneProfile(profile, userId);
}

export function renewConsent({ body, req, userId }) {
  const consent = assertConsentFields(body);
  const scope = scopePaths(userId);
  const profile = getCloneProfile(userId);
  if (!profile) {
    throw new AppError(409, 'VOICE_CLONE_REQUIRED', '还没有可续期的克隆音色', '请先录制一段参考音频完成声音克隆。');
  }
  const updated = Object.assign({}, profile, {
    consentVersion: consent.version,
    consentAcceptedAt: Date.now(),
    updatedAt: Date.now()
  });
  fs.writeFileSync(scope.profile, JSON.stringify(updated, null, 2) + '\n', 'utf8');
  recordConsent('grant', {
    scope,
    version: consent.version,
    hash: profile.hash,
    profileId: profile.id,
    req,
    reason: 'renew'
  });
  return getCloneState(userId);
}

export function deleteClone({ req, reason, userId }) {
  const scope = scopePaths(userId);
  const profile = getCloneProfile(userId);
  const hash = profile ? profile.hash : null;
  const profileId = profile ? profile.id : null;
  const version = profile ? profile.consentVersion : config.voiceConsentVersion;
  if (profile) {
    recordConsent('revoke', {
      scope,
      version,
      hash,
      profileId,
      req,
      reason: reason || 'user_deleted'
    });
  }
  safeUnlink(scope.reference);
  safeUnlink(scope.profile);
  const leftovers = fs.existsSync(scope.dir)
    ? fs.readdirSync(scope.dir).filter((name) => /^reference-.*\.mp3$/.test(name))
    : [];
  for (const name of leftovers) safeUnlink(path.join(scope.dir, name));
  return { deleted: !!profile, hash: hash ? hash.slice(0, 16) : null, scope: scope.id ? 'user' : 'guest' };
}

export function assertVoiceCloneAllowed(userId) {
  const profile = getCloneProfile(userId);
  if (!profile) {
    throw new AppError(
      409,
      'VOICE_CLONE_REQUIRED',
      '请先录制并保存你的声音',
      '声音克隆仅使用你本人或已获授权的声音，完成克隆后才能生成配音。'
    );
  }
  const state = getCloneState(userId);
  if (!state.valid) {
    throw new AppError(
      403,
      'VOICE_CONSENT_OUTDATED',
      '声音克隆协议已更新，请重新阅读并同意',
      '协议版本：' + config.voiceConsentVersion
    );
  }
  return profile;
}

export function getCloneAuditSummary(userId) {
  const scope = scopePaths(userId);
  const log = readConsentLog(scope);
  return {
    grants: log.filter((item) => item.type === 'grant').length,
    revokes: log.filter((item) => item.type === 'revoke').length,
    lastGrantAt: log.filter((item) => item.type === 'grant').map((item) => item.at).pop() || null,
    lastRevokeAt: log.filter((item) => item.type === 'revoke').map((item) => item.at).pop() || null
  };
}
