import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { runCommand, probeDuration, safeUnlink } from '../lib/process.js';
import {
  getCloneProfile,
  getCloneReferencePath,
  publicCloneProfile,
  assertVoiceCloneAllowed
} from './voice-clone.js';

const catalogData = JSON.parse(fs.readFileSync(config.voiceCatalogPath, 'utf8'));
const categories = catalogData.categories || [];
const voices = (catalogData.voices || []).map((voice) => ({ ...voice }));
const voiceMap = new Map(voices.map((voice) => [voice.id, voice]));
const jobs = new Map();
const samplePending = new Map();
const mp4Pending = new Map();
const JOB_TTL_MS = 2 * 60 * 60 * 1000;
const MAX_ACTIVE_WORKERS = 1;

let activeWorkers = 0;
const workerQueue = [];
let openVoiceDaemon = null;

function getOpenVoiceDaemon() {
  if (openVoiceDaemon && !openVoiceDaemon.child.killed) return openVoiceDaemon;
  const child = spawn(config.pythonBin, [config.voiceDaemonWorker], {
    cwd: config.serverRoot,
    env: { ...process.env, PYTHONUNBUFFERED: '1', NLTK_DATA: config.nltkDataDir },
    stdio: ['pipe', 'pipe', 'pipe']
  });
  const state = { child, buffer: '', pending: new Map() };
  child.stdout.on('data', (chunk) => {
    state.buffer += chunk.toString();
    const lines = state.buffer.split('\n');
    state.buffer = lines.pop() || '';
    for (const line of lines) {
      let payload;
      try { payload = JSON.parse(line); } catch { continue; }
      const item = state.pending.get(payload.requestId);
      if (!item) continue;
      if (payload.type === 'progress') {
        if (item.onProgress) item.onProgress(Number(payload.value) || 0);
      } else if (payload.type === 'done') {
        item.resolve(payload);
        state.pending.delete(payload.requestId);
      } else if (payload.type === 'error') {
        item.reject(new Error(payload.message || 'OpenVoice 合成失败'));
        state.pending.delete(payload.requestId);
      }
    }
  });
  child.stderr.on('data', () => {});
  const failPending = () => {
    for (const item of state.pending.values()) item.reject(new Error('OpenVoice 常驻进程已退出'));
    state.pending.clear();
    if (openVoiceDaemon === state) openVoiceDaemon = null;
  };
  child.on('error', failPending);
  child.on('close', failPending);
  openVoiceDaemon = state;
  return state;
}

function requestOpenVoice(payload, onProgress) {
  const state = getOpenVoiceDaemon();
  const requestId = crypto.randomUUID();
  return new Promise((resolve, reject) => {
    state.pending.set(requestId, { resolve, reject, onProgress });
    try {
      state.child.stdin.write(JSON.stringify({ ...payload, requestId }) + '\n');
    } catch (error) {
      state.pending.delete(requestId);
      reject(error);
    }
  });
}

function withWorkerSlot(task) {
  const run = () => new Promise((resolve, reject) => {
    activeWorkers += 1;
    Promise.resolve()
      .then(task)
      .then(resolve, reject)
      .finally(() => {
        activeWorkers = Math.max(0, activeWorkers - 1);
        const next = workerQueue.shift();
        if (next) next();
      });
  });
  if (activeWorkers < MAX_ACTIVE_WORKERS) return run();
  return new Promise((resolve, reject) => {
    workerQueue.push(() => run().then(resolve, reject));
  });
}

function clamp(value, low, high) {
  const number = Number(value);
  if (!Number.isFinite(number)) return low;
  return Math.max(low, Math.min(high, number));
}

function now() {
  return Date.now();
}

export function engineInfo(userId) {
  const modelPath = path.join(config.voiceOpenVoiceDir, 'checkpoints_v2', 'converter', 'checkpoint.pth');
  const converterConfigPath = path.join(config.voiceOpenVoiceDir, 'checkpoints_v2', 'converter', 'config.json');
  const speakerPath = path.join(config.voiceOpenVoiceDir, 'checkpoints_v2', 'base_speakers', 'ses', 'zh.pth');
  const meloModelPath = path.join(config.voiceOpenVoiceDir, 'melo', 'checkpoint.pth');
  const meloConfigPath = path.join(config.voiceOpenVoiceDir, 'melo', 'config.json');
  const referencePath = path.join(config.voiceOpenVoiceDir, 'reference', 'voice-reference.mp3');
  const localReady = [modelPath, converterConfigPath, speakerPath, meloModelPath, meloConfigPath, referencePath]
    .every((file) => fs.existsSync(file));
  const httpReady = !!(config.voiceHttpBase && /^https?:\/\//.test(config.voiceHttpBase));
  const remoteReady = !!(config.voiceServiceUrl && /^https?:\/\//.test(config.voiceServiceUrl));
  const provider = remoteReady ? 'remote' : config.voiceProvider === 'http' ? 'http' : config.voiceProvider === 'auto' ? (localReady ? 'local' : httpReady ? 'http' : 'none') : 'local';
  return {
    provider,
    localReady,
    httpReady,
    remoteReady,
    ready: provider === 'remote' ? remoteReady : provider === 'http' ? httpReady : localReady,
    cloneReady: !!getCloneProfile(userId),
    clone: publicCloneProfile(getCloneProfile(userId), userId),
    consentVersion: config.voiceConsentVersion,
    engine: catalogData.engine,
    modelPath,
    referencePath,
    maxChars: config.maxVoiceChars,
    python: config.pythonBin
  };
}

export function publicEngineInfo(info = engineInfo()) {
  const { modelPath, referencePath, python, ...rest } = info;
  return rest;
}

function publicVoice(voice, userId) {
  if (!voice) return null;
  const clone = voice.id === 'my-voice' ? getCloneProfile(userId) : null;
  const cloneSample = clone ? publicCloneProfile(clone, userId) : null;
  return {
    id: voice.id,
    name: voice.name,
    role: voice.role,
    category: voice.category,
    categories: voice.categories || [voice.category],
    gender: voice.gender,
    tone: voice.tone,
    tags: voice.tags || [],
    description: voice.description,
    sampleText: voice.sampleText,
    sampleUrl: cloneSample
      ? cloneSample.sampleUrl
      : '/api/voice/sample/' + encodeURIComponent(voice.id) + '.mp3',
    cloneReady: voice.id === 'my-voice' ? !!clone : true,
    featured: !!voice.featured,
    hot: Number(voice.hot) || 0,
    license: catalogData.engine.license,
    source: catalogData.engine.source,
    engine: catalogData.engine.name
  };
}

export function getCatalog(options = {}) {
  const info = engineInfo(options.userId);
  const category = String(options.category || 'all');
  const query = String(options.q || '').trim().toLowerCase();
  let list = voices;
  if (category && category !== 'all') {
    list = list.filter((voice) => (voice.categories || [voice.category]).includes(category));
  }
  if (query) {
    list = list.filter((voice) => {
      const haystack = [voice.name, voice.role, voice.tone, voice.description, ...(voice.tags || [])].join(' ').toLowerCase();
      return haystack.includes(query);
    });
  }
  const sorted = list.slice().sort((a, b) => (Number(b.hot) || 0) - (Number(a.hot) || 0));
  const categoriesWithCount = categories.map((item) => ({
    ...item,
    count: item.id === 'all' ? voices.length : voices.filter((voice) => (voice.categories || [voice.category]).includes(item.id)).length
  }));
  return {
    engine: publicEngineInfo(info),
    categories: categoriesWithCount,
    voices: sorted.map((voice) => publicVoice(voice, options.userId)),
    total: voices.length,
    featured: voices.filter((voice) => voice.featured).slice(0, 6).map((voice) => publicVoice(voice, options.userId))
  };
}

export function getVoiceBySlug(id) {
  return voiceMap.get(String(id)) || null;
}

function resolveVoice(voiceId) {
  const voice = getVoiceBySlug(voiceId) || voices[0];
  if (!voice) throw new AppError(503, 'VOICE_CATALOG_EMPTY', '音色库为空');
  return voice;
}

function ensureDirs() {
  fs.mkdirSync(config.voiceDir, { recursive: true });
  fs.mkdirSync(config.voiceSampleDir, { recursive: true });
}

function samplePath(voiceId) {
  return path.join(config.voiceSampleDir, voiceId + '.mp3');
}

async function convertToMp3(wavPath, mp3Path, pitch) {
  const duration = await probeDuration(wavPath);
  const filters = [];
  if (Math.abs(pitch - 1) > 0.001) {
    filters.push('asetrate=24000*' + pitch.toFixed(4));
    filters.push('aresample=24000');
    filters.push('atempo=' + (1 / pitch).toFixed(4));
  }
  filters.push('loudnorm=I=-16:TP=-1.5:LRA=11');
  filters.push('afade=t=in:st=0:d=0.05');
  if (duration > 0.5) filters.push('afade=t=out:st=' + Math.max(0, duration - 0.18).toFixed(3) + ':d=0.18');
  await runCommand(config.ffmpegPath, [
    '-y', '-hide_banner', '-loglevel', 'error',
    '-i', wavPath,
    '-af', filters.join(','),
    '-ar', '44100', '-ac', '1',
    '-c:a', 'libmp3lame', '-b:a', '160k',
    '-metadata', 'title=六和 AI 合成语音',
    '-metadata', 'artist=六和声音克隆',
    '-metadata', 'comment=AI-generated voice by Liuhe Voice Clone. 仅限本人或已获授权的声音。',
    '-metadata', 'encoding_tool=Liuhe',
    mp3Path
  ], { timeoutMs: 120000 });
  const stat = await fs.promises.stat(mp3Path);
  if (!stat.size) throw new AppError(500, 'VOICE_AUDIO_EMPTY', '配音文件为空');
  return { size: stat.size, duration: await probeDuration(mp3Path) };
}

function parseWorkerLine(line, handlers) {
  const text = String(line || '').trim();
  if (!text) return;
  let payload = null;
  try {
    payload = JSON.parse(text);
  } catch (error) {
    return;
  }
  if (payload.type === 'progress' && handlers.onProgress) handlers.onProgress(Number(payload.value) || 0);
  if (payload.type === 'done' && handlers.onDone) handlers.onDone(payload);
}

async function synthesizeLocal({ text, voice, speed, outputWav, onProgress, userId, referencePath }) {
  ensureDirs();
  const reference = referencePath || getCloneReferencePath(userId);
  try {
    await requestOpenVoice({
      text,
      voice: voice.engineVoice,
      speed,
      output: outputWav,
      modelDir: config.voiceOpenVoiceDir,
      reference
    }, (value) => {
      if (onProgress) onProgress(Math.max(0, Math.min(1, value)));
    });
  } catch (error) {
    throw new AppError(503, 'VOICE_LOCAL_FAILED', error.message || '本地语音合成失败', '请检查 OpenVoice 模型文件和本地依赖。');
  }
  if (!fs.existsSync(outputWav)) {
    throw new AppError(500, 'VOICE_EMPTY', '语音生成为空', '请换一段更短的文字重试。');
  }
}

async function synthesizeHttp({ text, voice, speed, outputWav, onProgress }) {
  if (!config.voiceHttpBase) {
    throw new AppError(503, 'VOICE_HTTP_NOT_CONFIGURED', '未配置远程开源语音服务', '请在 server/.env 设置 VOICE_HTTP_BASE。');
  }
  if (onProgress) onProgress(0.15);
  let response;
  try {
    response = await fetch(config.voiceHttpBase.replace(/\/$/, '') + '/v1/audio/speech', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(config.voiceHttpKey ? { authorization: 'Bearer ' + config.voiceHttpKey } : {})
      },
      body: JSON.stringify({
        model: config.voiceHttpModel,
        input: text,
        voice: voice.engineVoice,
        speed,
        response_format: 'wav'
      })
    });
  } catch (error) {
    throw new AppError(502, 'VOICE_HTTP_FAILED', '无法连接远程开源语音服务', '请检查 VOICE_HTTP_BASE 是否可访问。');
  }
  if (!response.ok) {
    throw new AppError(502, 'VOICE_HTTP_BAD_STATUS', '远程语音服务返回异常（' + response.status + '）', '请检查服务日志与音色名称。');
  }
  if (onProgress) onProgress(0.7);
  const arrayBuffer = await response.arrayBuffer();
  if (!arrayBuffer || !arrayBuffer.byteLength) throw new AppError(502, 'VOICE_HTTP_EMPTY', '远程语音服务返回空音频');
  await fs.promises.writeFile(outputWav, Buffer.from(arrayBuffer));
  if (onProgress) onProgress(1);
}

async function synthesizeRemote({ text, speed, outputWav, onProgress, userId, referencePath }) {
  if (!config.voiceServiceUrl) {
    throw new AppError(503, 'VOICE_SERVICE_NOT_CONFIGURED', '独立声音服务未配置', '请设置 VOICE_SERVICE_URL。');
  }
  const reference = referencePath || getCloneReferencePath(userId);
  if (!reference || !fs.existsSync(reference)) {
    throw new AppError(400, 'VOICE_REFERENCE_MISSING', '本机参考音频不存在', '请重新录制或选择音频。');
  }
  if (onProgress) onProgress(0.08);
  const file = await fs.promises.readFile(reference);
  const form = new FormData();
  form.append('file', new Blob([file]), 'reference' + (path.extname(reference) || '.mp3'));
  form.append('text', text);
  form.append('speed', String(speed || 1));
  let response;
  try {
    response = await fetch(config.voiceServiceUrl + '/synthesize', {
      method: 'POST',
      headers: config.voiceServiceKey ? { 'x-voice-key': config.voiceServiceKey } : {},
      body: form,
      signal: AbortSignal.timeout(180000)
    });
  } catch (error) {
    throw new AppError(502, 'VOICE_SERVICE_UNREACHABLE', '独立声音服务连接失败', '请检查 VOICE_SERVICE_URL 和服务状态。');
  }
  if (response.status === 202) {
    let payload = null;
    try { payload = await response.json(); } catch (error) { /* ignore */ }
    const jobId = payload && payload.data && payload.data.id;
    if (!jobId) throw new AppError(502, 'VOICE_SERVICE_BAD_RESPONSE', '独立声音服务没有返回任务 ID');
    if (onProgress) onProgress(0.2);
    const deadline = Date.now() + 180000;
    while (Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      let result;
      try {
        result = await fetch(config.voiceServiceUrl + '/result/' + encodeURIComponent(jobId), {
          headers: config.voiceServiceKey ? { 'x-voice-key': config.voiceServiceKey } : {},
          signal: AbortSignal.timeout(30000)
        });
      } catch (error) {
        continue;
      }
      if (result.status === 202) continue;
      if (!result.ok) {
        let message = '独立声音服务合成失败';
        try {
          const body = await result.json();
          message = (body && body.error && body.error.message) || message;
        } catch (error) { /* ignore */ }
        throw new AppError(502, 'VOICE_SERVICE_FAILED', message, '请检查声音服务日志。');
      }
      if (onProgress) onProgress(0.9);
      const buffer = Buffer.from(await result.arrayBuffer());
      if (!buffer.length) throw new AppError(502, 'VOICE_SERVICE_EMPTY', '独立声音服务返回空音频');
      await fs.promises.writeFile(outputWav, buffer);
      if (onProgress) onProgress(1);
      return;
    }
    throw new AppError(504, 'VOICE_SERVICE_TIMEOUT', '声音服务处理超时', '请稍后重试。');
  }
  if (!response.ok) {
    let message = '独立声音服务返回异常';
    try {
      const body = await response.json();
      message = (body && body.error && body.error.message) || message;
    } catch (error) { /* ignore */ }
    throw new AppError(502, 'VOICE_SERVICE_FAILED', message, '请检查声音服务日志。');
  }
  if (onProgress) onProgress(0.85);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (!buffer.length) throw new AppError(502, 'VOICE_SERVICE_EMPTY', '独立声音服务返回空音频');
  await fs.promises.writeFile(outputWav, buffer);
  if (onProgress) onProgress(1);
}

async function synthesizeToWav({ text, voice, speed, outputWav, onProgress, userId, referencePath }) {
  const info = engineInfo(userId);
  if (!info.ready) {
    throw new AppError(503, 'VOICE_ENGINE_MISSING', '开源音色模型尚未安装', '请在服务端准备 OpenVoice V2 + MeloTTS 模型，或配置 VOICE_HTTP_BASE 使用自建兼容 TTS 服务。');
  }
  if (info.provider === 'remote') {
    await synthesizeRemote({ text, speed, outputWav, onProgress, userId, referencePath });
  } else if (info.provider === 'http') {
    await synthesizeHttp({ text, voice, speed, outputWav, onProgress });
  } else {
    await synthesizeLocal({ text, voice, speed, outputWav, onProgress, userId, referencePath });
  }
}

function setJob(job, patch) {
  Object.assign(job, patch, { updatedAt: now() });
}

export function publicVoiceJob(job) {
  if (!job) return null;
  return {
    id: job.id,
    status: job.status,
    stage: job.stage,
    progress: job.progress,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    voice: publicVoice(job.voice, job.userId),
    textLength: job.text.length,
    textPreview: job.text.slice(0, 42),
    speed: job.speed,
    result: job.result,
    error: job.error
  };
}

async function runVoiceJob(job) {
  const wavPath = path.join(config.voiceDir, job.id + '.wav');
  const mp3Path = path.join(config.voiceDir, job.id + '.mp3');
  try {
    setJob(job, { status: 'processing', stage: '正在准备音色', progress: 4 });
    await withWorkerSlot(async () => {
      setJob(job, { stage: '正在合成语音', progress: 8 });
      await synthesizeToWav({
        text: job.text,
        voice: job.voice,
        speed: job.speed,
        outputWav: wavPath,
        userId: job.userId,
        referencePath: job.referencePath,
        onProgress(value) {
          setJob(job, {
            progress: Math.max(8, Math.min(78, Math.round(8 + value * 70))),
            stage: value >= 1 ? '正在整理音频' : '正在合成语音'
          });
        }
      });
    });
    setJob(job, { stage: '正在整理音频', progress: 84 });
    const info = await convertToMp3(wavPath, mp3Path, job.pitch);
    const result = {
      audioUrl: '/api/voice/result/' + job.id + '.mp3',
      duration: Math.round(info.duration * 100) / 100,
      size: info.size,
      voice: publicVoice(job.voice, job.userId),
      textLength: job.text.length,
      textPreview: job.text.slice(0, 60),
      speed: job.speed,
      license: catalogData.engine.license,
      aiGenerated: true,
      cloneHash: job.cloneHash || ''
    };
    setJob(job, { status: 'done', stage: '配音完成', progress: 100, result });
  } catch (error) {
    const message = error instanceof AppError ? error.message : '配音生成失败，请稍后重试';
    const hint = error instanceof AppError ? error.hint : '请确认服务端语音依赖已安装。';
    setJob(job, {
      status: 'failed',
      stage: '生成失败',
      progress: Math.max(job.progress || 0, 2),
      error: { code: (error && error.code) || 'VOICE_FAILED', message, hint }
    });
    safeUnlink(mp3Path);
  } finally {
    safeUnlink(wavPath);
    if (job.referencePath) safeUnlink(job.referencePath);
  }
}

export function createVoiceJob(input = {}, userId) {
  const text = String(input.text || '').trim();
  if (!text) throw new AppError(400, 'VOICE_TEXT_EMPTY', '请先输入要配音的文字');
  if (text.length > config.maxVoiceChars) {
    throw new AppError(413, 'VOICE_TEXT_TOO_LONG', '单次配音最多 ' + config.maxVoiceChars + ' 字', '可以分成几段生成，然后再拼接使用。');
  }
  const voice = resolveVoice(input.voiceId);
  const referencePath = input.referencePath ? String(input.referencePath) : '';
  const clone = !referencePath && voice.id === 'my-voice' ? assertVoiceCloneAllowed(userId) : null;
  const speed = clamp(input.speed || 1, 0.75, 1.3);
  const pitch = clamp(input.pitch || voice.pitch || 1, 0.85, 1.15);
  const job = {
    id: crypto.randomUUID(),
    status: 'queued',
    stage: '排队中',
    progress: 0,
    text,
    speed,
    pitch,
    voice,
    userId,
    referencePath,
    cloneHash: clone ? String(clone.hash || '').slice(0, 16) : '',
    createdAt: now(),
    updatedAt: now(),
    result: null,
    error: null
  };
  jobs.set(job.id, job);
  runVoiceJob(job);
  return job;
}

export function getVoiceJob(id) {
  const job = jobs.get(String(id));
  if (!job) throw new AppError(404, 'VOICE_JOB_NOT_FOUND', '配音任务不存在或已过期');
  return job;
}

export function getVoiceOutput(id) {
  const file = path.join(config.voiceDir, String(id) + '.mp3');
  if (!fs.existsSync(file)) throw new AppError(404, 'VOICE_OUTPUT_GONE', '配音文件已过期，请重新生成');
  return file;
}

export async function getVoiceMp4(id) {
  const key = String(id || '');
  const output = path.join(config.voiceDir, key + '.mp4');
  if (fs.existsSync(output)) return output;
  if (mp4Pending.has(key)) return mp4Pending.get(key);
  const task = (async () => {
    const mp3 = getVoiceOutput(key);
    const cover = path.join(config.serverRoot, 'public', 'voice-cover.jpg');
    if (!fs.existsSync(cover)) {
      throw new AppError(500, 'VOICE_MP4_COVER_MISSING', '配音封面资源缺失');
    }
    const job = jobs.get(key);
    let duration = Number(job && job.result && job.result.duration) || 0;
    if (!duration) {
      try { duration = await probeDuration(mp3); } catch (error) { duration = 0; }
    }
    const temp = path.join(config.voiceDir, key + '-video-' + crypto.randomUUID() + '.mp4');
    const args = [
      '-y',
      '-loop', '1',
      '-i', cover,
      '-i', mp3,
      '-vf', 'scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,setsar=1',
      '-r', '30',
      '-c:v', 'libx264',
      '-preset', 'veryfast',
      '-crf', '22',
      '-pix_fmt', 'yuv420p',
      '-c:a', 'aac',
      '-b:a', '192k',
      '-ar', '44100',
      '-movflags', '+faststart',
      '-shortest'
    ];
    if (duration > 0) args.push('-t', (duration + 0.2).toFixed(3));
    args.push(temp);
    try {
      await runCommand(config.ffmpegPath, args, { timeoutMs: 120000 });
      await fs.promises.rename(temp, output);
      return output;
    } catch (error) {
      safeUnlink(temp);
      throw new AppError(500, 'VOICE_MP4_FAILED', 'MP4 生成失败，请稍后重试');
    }
  })();
  mp4Pending.set(key, task);
  try { return await task; } finally { mp4Pending.delete(key); }
}

export function deleteVoiceJob(id) {
  const job = jobs.get(String(id));
  if (!job) return false;
  jobs.delete(job.id);
  safeUnlink(path.join(config.voiceDir, job.id + '.mp3'));
  safeUnlink(path.join(config.voiceDir, job.id + '.mp4'));
  safeUnlink(path.join(config.voiceDir, job.id + '.wav'));
  return true;
}

export async function ensureVoiceSample(voiceId, options = {}) {
  const voice = resolveVoice(voiceId);
  const file = samplePath(voice.id);
  if (fs.existsSync(file) && !options.force) return file;
  if (samplePending.has(voice.id)) return samplePending.get(voice.id);
  const promise = withWorkerSlot(async () => {
    ensureDirs();
    const wavPath = path.join(config.voiceDir, 'sample-' + voice.id + '-' + Date.now() + '.wav');
    try {
      await synthesizeToWav({
        text: voice.sampleText,
        voice,
        speed: clamp(voice.speed || 1, 0.75, 1.3),
        outputWav: wavPath
      });
      const tempMp3 = file + '.tmp.mp3';
      await convertToMp3(wavPath, tempMp3, clamp(voice.pitch || 1, 0.85, 1.15));
      await fs.promises.rename(tempMp3, file);
      return file;
    } finally {
      safeUnlink(wavPath);
    }
  });
  samplePending.set(voice.id, promise);
  try {
    return await promise;
  } finally {
    samplePending.delete(voice.id);
  }
}

export function getVoiceSamplePath(voiceId) {
  return samplePath(String(voiceId));
}

export function getVoiceSampleText(voiceId) {
  const voice = resolveVoice(voiceId);
  return { id: voice.id, name: voice.name, role: voice.role, sampleText: voice.sampleText };
}

setInterval(() => {
  const cutoff = now() - JOB_TTL_MS;
  for (const [id, job] of jobs.entries()) {
    if (job.updatedAt < cutoff) {
      jobs.delete(id);
      safeUnlink(path.join(config.voiceDir, id + '.mp3'));
      safeUnlink(path.join(config.voiceDir, id + '.wav'));
    }
  }
}, 10 * 60 * 1000).unref();
