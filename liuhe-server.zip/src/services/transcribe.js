import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { downloadToFile, withRefererFor } from '../lib/http.js';
import { safeFilename } from '../lib/url.js';
import { extractAudio, probeDuration, safeUnlink } from '../lib/process.js';
import { mediaPath, imagePath } from '../lib/sign.js';
import { splitSegments, segmentsToSrt, fullTextFromSegments } from '../lib/srt.js';
import { resolveVideo } from './resolver/index.js';
import { DEMO_SEGMENTS } from './resolver/demo.js';
import { transcribeAudio } from './asr/index.js';
import {
  createJob,
  updateJob,
  completeJob,
  failJob,
  publicJob,
  getJob
} from './jobs.js';

function addTemp(jobId, filePath) {
  const job = getJob(jobId);
  if (filePath) job.internal.tempFiles.push(filePath);
}

function cleanup(jobId) {
  let job;
  try {
    job = getJob(jobId);
  } catch (error) {
    return;
  }
  for (const filePath of job.internal.tempFiles) safeUnlink(filePath);
  job.internal.tempFiles = [];
}

function safeUpdate(jobId, patch) {
  try {
    const job = getJob(jobId);
    if (!job || job.status === 'failed' || job.status === 'done') return;
    updateJob(jobId, patch);
  } catch (error) {
    // 任务可能已被删除。
  }
}

function normalizeProxiedVideo(resolved, title) {
  if (!resolved.videoUrl) return '';
  if (resolved.videoUrl.startsWith('/')) return resolved.videoUrl;
  return mediaPath(resolved.videoUrl, safeFilename(title, 'liuhe-video') + '.mp4');
}

function normalizeProxiedCover(resolved) {
  if (!resolved.cover) return '';
  if (resolved.cover.startsWith('/')) return resolved.cover;
  if (/^https?:\/\//i.test(resolved.cover)) return imagePath(resolved.cover);
  return '';
}

function buildVideoMeta(resolved, duration) {
  const title = resolved.title || '视频字幕';
  return {
    title,
    author: resolved.author || '',
    coverUrl: normalizeProxiedCover(resolved),
    videoUrl: normalizeProxiedVideo(resolved, title),
    duration: Math.round((duration || resolved.duration || 0) * 10) / 10,
    platform: resolved.platform || 'douyin',
    sourceUrl: resolved.sourceUrl || '',
    quality: resolved.quality || '原片',
    stats: resolved.stats || {},
    demo: !!resolved.demo
  };
}

function buildUploadVideoMeta(duration) {
  return {
    title: '本地视频字幕 · ' + Math.round(duration || 0) + ' 秒',
    author: '',
    coverUrl: '',
    videoUrl: '',
    duration: Math.round((duration || 0) * 10) / 10,
    platform: 'local',
    sourceUrl: '',
    quality: '本地',
    stats: {},
    demo: config.demoMode
  };
}

function buildResult({ sourceType, asr, duration, video }) {
  const rawSegments = asr.segments && asr.segments.length ? asr.segments : [];
  const segments = splitSegments(rawSegments, 22);
  if (!segments.length) {
    throw new AppError(
      422,
      'NO_SPEECH',
      '没有识别到清晰的语音',
      '请确认视频中包含人声，或换一段更清晰的音频重试。'
    );
  }
  const fullText = fullTextFromSegments(segments);
  const srt = segmentsToSrt(segments);
  return {
    provider: asr.provider || '本地 Whisper',
    language: asr.language || 'zh',
    duration: Math.round((duration || asr.duration || 0) * 10) / 10,
    segments,
    fullText,
    srt,
    video,
    sourceType,
    createdAt: Date.now()
  };
}

function demoAsr(duration) {
  const capped = duration || 18;
  return {
    provider: '演示字幕',
    language: 'zh',
    duration: capped,
    segments: DEMO_SEGMENTS.filter((segment) => segment.start < capped).map((segment) => ({
      start: segment.start,
      end: Math.min(segment.end, capped),
      text: segment.text
    }))
  };
}

async function runLinkJob(jobId, inputUrl) {
  let resolved;
  try {
    safeUpdate(jobId, { status: 'processing', stage: '正在解析视频链接', progress: 8 });
    resolved = await resolveVideo(inputUrl);
    safeUpdate(jobId, {
      stage: '链接解析完成，正在准备视频',
      progress: 22
    });

    if (config.asrProvider === 'mock') {
      const asr = demoAsr(resolved.duration || 18);
      const video = buildVideoMeta(resolved, asr.duration);
      safeUpdate(jobId, { stage: '正在整理演示字幕', progress: 72 });
      await new Promise((resolve) => setTimeout(resolve, 900));
      const result = buildResult({
        sourceType: 'link',
        asr,
        duration: asr.duration,
        video
      });
      completeJob(jobId, result);
      return;
    }

    let videoPath;
    if (resolved.videoUrl.startsWith('/')) {
      videoPath = path.join(config.publicDir, resolved.videoUrl.replace(/^\//, ''));
      if (!fs.existsSync(videoPath)) {
        throw new AppError(404, 'DEMO_MEDIA_MISSING', '演示视频文件不存在', '请运行 npm run demo:media 生成演示素材。');
      }
    } else {
      videoPath = path.join(config.workDir, jobId + '-video.mp4');
      addTemp(jobId, videoPath);
      safeUpdate(jobId, { stage: '正在下载视频到本地', progress: 30 });
      await downloadToFile(resolved.videoUrl, videoPath, {
        referer: withRefererFor(resolved.videoUrl),
        maxBytes: config.maxUploadBytes,
        timeoutMs: 240000
      });
    }

    safeUpdate(jobId, { stage: '正在读取视频信息', progress: 40 });
    let duration = await probeDuration(videoPath);
    if (!duration) duration = resolved.duration || 0;
    if (duration > config.maxVideoSeconds) {
      throw new AppError(
        413,
        'VIDEO_TOO_LONG',
        '视频超过 ' + Math.round(config.maxVideoSeconds / 60) + ' 分钟',
        '请使用更短的视频，或在 .env 中调整 MAX_VIDEO_SECONDS。'
      );
    }

    const audioPath = path.join(config.workDir, jobId + '-audio.mp3');
    addTemp(jobId, audioPath);
    safeUpdate(jobId, { stage: '正在提取音轨', progress: 46 });
    await extractAudio(videoPath, audioPath);

    safeUpdate(jobId, { stage: '正在加载本地 Whisper', progress: 55 });
    const asr = await transcribeAudio(audioPath, {
      duration,
      language: config.whisperLanguage,
      onStage: (stage) => safeUpdate(jobId, { stage, progress: 62 }),
      onProgress: (progress) => {
        safeUpdate(jobId, {
          stage: '本地 Whisper 正在听写',
          progress: 62 + Math.round((Math.min(100, progress) / 100) * 30)
        });
      }
    });
    safeUpdate(jobId, { stage: '正在整理逐句字幕', progress: 94 });
    const video = buildVideoMeta(resolved, asr.duration || duration);
    const result = buildResult({
      sourceType: 'link',
      asr,
      duration: asr.duration || duration,
      video
    });
    completeJob(jobId, result);
  } catch (error) {
    failJob(jobId, error);
    console.error('[link job]', error.message);
    if (error.detail) console.error(error.detail);
  } finally {
    cleanup(jobId);
  }
}

async function runUploadJob(jobId, filePath, originalName) {
  try {
    safeUpdate(jobId, { status: 'processing', stage: '正在读取本地视频', progress: 10 });
    let duration = 0;
    try {
      duration = await probeDuration(filePath);
    } catch (error) {
      if (config.asrProvider !== 'mock') throw error;
    }
    if (duration > config.maxVideoSeconds) {
      throw new AppError(
        413,
        'VIDEO_TOO_LONG',
        '视频超过 ' + Math.round(config.maxVideoSeconds / 60) + ' 分钟',
        '请使用更短的视频，或在 .env 中调整 MAX_VIDEO_SECONDS。'
      );
    }

    if (config.asrProvider === 'mock') {
      const asr = demoAsr(duration || 18);
      safeUpdate(jobId, { stage: '正在整理演示字幕', progress: 72 });
      await new Promise((resolve) => setTimeout(resolve, 900));
      const result = buildResult({
        sourceType: 'upload',
        asr,
        duration: duration || asr.duration,
        video: buildUploadVideoMeta(duration || asr.duration)
      });
      completeJob(jobId, result);
      return;
    }

    const audioPath = path.join(config.workDir, jobId + '-audio.mp3');
    addTemp(jobId, audioPath);
    safeUpdate(jobId, { stage: '正在提取音轨', progress: 34 });
    await extractAudio(filePath, audioPath);

    safeUpdate(jobId, { stage: '正在加载本地 Whisper', progress: 50 });
    const asr = await transcribeAudio(audioPath, {
      duration,
      language: config.whisperLanguage,
      onStage: (stage) => safeUpdate(jobId, { stage, progress: 58 }),
      onProgress: (progress) => {
        safeUpdate(jobId, {
          stage: '本地 Whisper 正在听写',
          progress: 58 + Math.round((Math.min(100, progress) / 100) * 34)
        });
      }
    });
    safeUpdate(jobId, { stage: '正在整理逐句字幕', progress: 94 });
    const result = buildResult({
      sourceType: 'upload',
      asr,
      duration: asr.duration || duration,
      video: buildUploadVideoMeta(asr.duration || duration)
    });
    completeJob(jobId, result);
  } catch (error) {
    failJob(jobId, error);
    console.error('[upload job]', error.message);
    if (error.detail) console.error(error.detail);
  } finally {
    safeUnlink(filePath);
    cleanup(jobId);
  }
}

export function enqueueLinkJob(inputUrl) {
  const job = createJob({ sourceType: 'link' });
  setImmediate(() => {
    runLinkJob(job.id, inputUrl);
  });
  return publicJob(job);
}

export function enqueueUploadJob(filePath, originalName) {
  const job = createJob({ sourceType: 'upload' });
  setImmediate(() => {
    runUploadJob(job.id, filePath, originalName);
  });
  return publicJob(job);
}
