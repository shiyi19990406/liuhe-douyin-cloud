import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';

const TYPES = {
  issue: '问题反馈',
  idea: '功能建议',
  business: '商务合作'
};

function hashIp(req) {
  const raw = String((req && (req.ip || (req.socket && req.socket.remoteAddress))) || '');
  if (!raw) return '';
  return crypto.createHash('sha256').update(raw + '|' + config.mediaSecret).digest('hex').slice(0, 24);
}

export function createFeedback({ body, req }) {
  const source = body || {};
  const type = Object.prototype.hasOwnProperty.call(TYPES, source.type) ? source.type : 'issue';
  const content = String(source.content || '').replace(/\r\n/g, '\n').trim();
  const contact = String(source.contact || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 120);
  if (content.length < 2) throw new AppError(400, 'FEEDBACK_EMPTY', '请先写下你的反馈内容');
  if (content.length > 2000) throw new AppError(413, 'FEEDBACK_TOO_LONG', '反馈内容请控制在 2000 字以内');

  const entry = {
    id: 'fb_' + crypto.randomBytes(8).toString('hex'),
    type,
    typeLabel: TYPES[type],
    content,
    contact,
    userId: (req && req.user && req.user.id) || '',
    page: String(source.page || '').slice(0, 40),
    version: config.version,
    ipHash: hashIp(req),
    userAgent: String((req && req.headers && req.headers['user-agent']) || '').slice(0, 160),
    createdAt: Date.now()
  };

  fs.mkdirSync(config.feedbackDir, { recursive: true });
  fs.appendFileSync(path.join(config.feedbackDir, 'feedback.jsonl'), JSON.stringify(entry) + '\n', 'utf8');
  return {
    id: entry.id,
    type: entry.type,
    typeLabel: entry.typeLabel,
    createdAt: entry.createdAt
  };
}
