import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { runCommand, safeUnlink } from '../lib/process.js';

const results = new Map();

export async function processPhoto(file, modeInput, scaleInput) {
  const mode = ['repair', 'colorize', 'both'].includes(modeInput) ? modeInput : 'both';
  const scale = Number(scaleInput) === 4 ? 4 : 2;
  const id = crypto.randomUUID();
  const outputPath = path.join(config.photoDir, id + '.jpg');
  try {
    const { stdout } = await runCommand(
      config.pythonBin,
      [
        config.photoWorker,
        '--input',
        file.path,
        '--output',
        outputPath,
        '--mode',
        mode,
        '--model-dir',
        config.colorModelDir,
        '--scale',
        String(scale)
      ],
      { timeoutMs: 5 * 60 * 1000 }
    );
    const lastLine = String(stdout || '').trim().split('\n').pop() || '{}';
    let payload = {};
    try {
      payload = JSON.parse(lastLine);
    } catch (error) {
      payload = {};
    }
    if (payload.ok === false) {
      throw new AppError(500, 'PHOTO_PROCESS_FAILED', payload.error || '照片处理失败');
    }
    const stat = await fs.promises.stat(outputPath);
    if (!stat.size) throw new AppError(500, 'PHOTO_EMPTY', '照片处理结果为空');
    results.set(id, { path: outputPath, createdAt: Date.now() });
    return {
      id,
      mode,
      scale,
      width: Number(payload.width) || 0,
      height: Number(payload.height) || 0,
      url: '/api/photo/result/' + id + '.jpg'
    };
  } catch (error) {
    safeUnlink(outputPath);
    if (error instanceof AppError) throw error;
    throw new AppError(
      500,
      'PHOTO_PROCESS_FAILED',
      error.message || '照片处理失败',
      '黑白上色需要先下载本地模型：npm run download:color'
    );
  } finally {
    safeUnlink(file.path);
  }
}

export function getPhotoResult(id) {
  const record = results.get(id);
  if (!record || !fs.existsSync(record.path)) {
    throw new AppError(404, 'PHOTO_NOT_FOUND', '照片结果已过期，请重新处理');
  }
  return record.path;
}

setInterval(() => {
  const cutoff = Date.now() - 2 * 60 * 60 * 1000;
  for (const [id, record] of results.entries()) {
    if (record.createdAt < cutoff) {
      safeUnlink(record.path);
      results.delete(id);
    }
  }
}, 10 * 60 * 1000).unref();
