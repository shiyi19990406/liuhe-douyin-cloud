import crypto from 'node:crypto';
import { config } from '../config.js';
import { notFound } from '../lib/errors.js';

const jobs = new Map();

export function createJob(meta = {}) {
  const id = crypto.randomUUID();
  const now = Date.now();
  const job = {
    id,
    status: 'queued',
    stage: '排队中',
    progress: 0,
    sourceType: meta.sourceType || 'link',
    createdAt: now,
    updatedAt: now,
    result: null,
    error: null,
    internal: {
      tempFiles: []
    }
  };
  jobs.set(id, job);
  return job;
}

export function getJob(id) {
  const job = jobs.get(id);
  if (!job) throw notFound('字幕任务不存在或已过期');
  return job;
}

export function updateJob(id, patch) {
  const job = jobs.get(id);
  if (!job) return null;
  Object.assign(job, patch, { updatedAt: Date.now() });
  return job;
}

export function completeJob(id, result) {
  const job = jobs.get(id);
  if (!job) return null;
  job.status = 'done';
  job.stage = '识别完成';
  job.progress = 100;
  job.result = result;
  job.updatedAt = Date.now();
  return job;
}

export function failJob(id, error) {
  const job = jobs.get(id);
  if (!job) return null;
  job.status = 'failed';
  job.stage = '识别失败';
  job.progress = Math.max(job.progress || 0, 1);
  job.error = {
    code: (error && error.code) || 'ASR_FAILED',
    message: (error && error.message) || '识别失败，请稍后重试',
    hint: (error && error.hint) || ''
  };
  job.updatedAt = Date.now();
  return job;
}

export function deleteJob(id) {
  const job = jobs.get(id);
  if (!job) return false;
  jobs.delete(id);
  return true;
}

export function publicJob(job) {
  if (!job) return null;
  return {
    id: job.id,
    status: job.status,
    stage: job.stage,
    progress: job.progress,
    sourceType: job.sourceType,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    result: job.result,
    error: job.error
  };
}

setInterval(() => {
  const now = Date.now();
  for (const [id, job] of jobs.entries()) {
    if (now - job.updatedAt > config.jobTtlMs) {
      jobs.delete(id);
    }
  }
}, 10 * 60 * 1000).unref();
