import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { runCommand, probeMedia, probeDuration, safeUnlink } from '../lib/process.js';
import { resolveMusic, getMusicTrack } from './music-library.js';

const ASPECTS = {
  '9:16': { id: '9:16', width: 720, height: 1280, label: '竖屏 9:16', hint: '抖音 / 快手 / 视频号' },
  '1:1': { id: '1:1', width: 960, height: 960, label: '方形 1:1', hint: '朋友圈 / 小红书' },
  '16:9': { id: '16:9', width: 1280, height: 720, label: '横屏 16:9', hint: 'B站 / 西瓜视频' },
  '4:3': { id: '4:3', width: 960, height: 720, label: '经典 4:3', hint: '老照片 / 复古画面' }
};

const STYLES = [
  { id: 'alive', name: '照片呼吸', desc: '单图 2.5D 推拉，像照片在呼吸', badge: '单图' },
  { id: 'slow-zoom', name: '缓慢推进', desc: '克制、电影感，最百搭', badge: '推荐' },
  { id: 'drift', name: '轻微漂移', desc: '横向移动，更有呼吸感', badge: '' },
  { id: 'kenburns', name: 'Ken Burns', desc: '推拉摇移，适合多张照片', badge: '多图' },
  { id: 'breath', name: '呼吸感', desc: '轻微缩放，安静不抢戏', badge: '' },
  { id: 'beat', name: '节拍律动', desc: '跟随音乐轻轻起伏', badge: '音乐' },
  { id: 'still', name: '静帧', desc: '保留原始构图，只做转场', badge: '' }
];

const TRANSITIONS = [
  { id: 'fade', name: '淡入淡出', desc: '柔和、稳妥' },
  { id: 'slide', name: '横向滑动', desc: '干净、有节奏' },
  { id: 'zoom', name: '推近叠化', desc: '更有电影感' },
  { id: 'none', name: '直接切换', desc: '最接近原始照片' }
];

const FILTERS = [
  { id: 'none', name: '原片', desc: '保留真实色彩', swatch: 'linear-gradient(135deg,#dfe7f5,#b9c8e4)' },
  { id: 'warm', name: '暖阳', desc: '偏暖、适合人像', swatch: 'linear-gradient(135deg,#ffd7b0,#ff9f7a)' },
  { id: 'film', name: '胶片', desc: '低饱和、轻暗角', swatch: 'linear-gradient(135deg,#d8c8ae,#8b7b66)' },
  { id: 'cool', name: '清冷', desc: '偏蓝、适合风景', swatch: 'linear-gradient(135deg,#cfe6ff,#7ea9df)' },
  { id: 'mono', name: '黑白', desc: '经典、叙事感', swatch: 'linear-gradient(135deg,#e6e6e6,#7b7b7b)' },
  { id: 'vivid', name: '鲜明', desc: '提高饱和与对比', swatch: 'linear-gradient(135deg,#ffe0f0,#8fd6ff)' }
];

const uploads = new Map();
const jobs = new Map();
const UPLOAD_TTL_MS = 30 * 60 * 1000;
const JOB_TTL_MS = 2 * 60 * 60 * 1000;

function now() {
  return Date.now();
}

function clamp(value, low, high) {
  const number = Number(value);
  if (!Number.isFinite(number)) return low;
  return Math.max(low, Math.min(high, value));
}

function even(value) {
  return Math.max(2, Math.round(value / 2) * 2);
}

function inferKind(file) {
  const mime = String((file && file.mimetype) || '');
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('audio/')) return 'audio';
  if (mime.startsWith('video/')) return 'video';
  const ext = path.extname((file && (file.originalname || file.path)) || '').toLowerCase();
  if (/\.(jpe?g|png|webp|heic|bmp)$/.test(ext)) return 'image';
  if (/\.(mp3|m4a|aac|wav|flac|ogg)$/.test(ext)) return 'audio';
  return 'video';
}

function publicUpload(asset) {
  if (!asset) return null;
  return {
    id: asset.id,
    kind: asset.kind,
    name: asset.name,
    width: asset.width,
    height: asset.height,
    duration: Math.round(asset.duration * 100) / 100,
    size: asset.size
  };
}

export async function registerUpload(file, kindHint) {
  if (!file || !file.path) throw new AppError(400, 'IMAGE_VIDEO_NO_FILE', '没有收到文件');
  const kind = ['image', 'audio', 'video'].includes(kindHint) ? kindHint : inferKind(file);
  const meta = await probeMedia(file.path);
  if (kind === 'image' && (!meta.hasVideo || !meta.width || !meta.height)) {
    safeUnlink(file.path);
    throw new AppError(422, 'IMAGE_INVALID', '无法读取这张照片', '请选择 JPG / PNG / WebP 图片。');
  }
  if (kind === 'audio' && !meta.hasAudio) {
    safeUnlink(file.path);
    throw new AppError(422, 'AUDIO_INVALID', '这段文件没有可用的音轨', '请选择 MP3 / M4A / WAV 音频。');
  }
  if (kind === 'video' && !meta.hasVideo) {
    safeUnlink(file.path);
    throw new AppError(422, 'VIDEO_INVALID', '没有读取到视频画面');
  }
  if (kind === 'audio' && meta.duration > 30 * 60) {
    safeUnlink(file.path);
    throw new AppError(413, 'AUDIO_TOO_LONG', '音乐文件不能超过 30 分钟');
  }
  const stat = await fs.promises.stat(file.path);
  if (kind === 'image' && stat.size > 30 * 1024 * 1024) {
    safeUnlink(file.path);
    throw new AppError(413, 'IMAGE_TOO_LARGE', '单张照片不能超过 30MB', '请先在相册中压缩或裁剪后再试。');
  }
  if (kind === 'image' && (meta.width > 16000 || meta.height > 16000)) {
    safeUnlink(file.path);
    throw new AppError(413, 'IMAGE_TOO_LARGE_PIXELS', '这张照片分辨率过高', '请选择不超过 16000 像素的照片。');
  }
  const asset = {
    id: crypto.randomUUID(),
    kind,
    path: file.path,
    name: String(file.originalname || (kind === 'image' ? '照片' : kind === 'audio' ? '音乐' : '视频')).slice(0, 80),
    size: stat.size,
    width: meta.width,
    height: meta.height,
    duration: meta.duration,
    createdAt: now()
  };
  uploads.set(asset.id, asset);
  return publicUpload(asset);
}

export function getUpload(id) {
  const asset = uploads.get(String(id));
  if (!asset) throw new AppError(404, 'UPLOAD_EXPIRED', '上传文件已过期，请重新选择');
  return asset;
}

export function deleteUpload(id) {
  const asset = uploads.get(String(id));
  if (!asset) return false;
  uploads.delete(asset.id);
  safeUnlink(asset.path);
  return true;
}

export async function extractAudioFromVideo(videoId) {
  const asset = getUpload(videoId);
  if (asset.kind !== 'video') throw new AppError(400, 'NOT_A_VIDEO', '请选择一个视频文件');
  const output = path.join(config.uploadDir, crypto.randomUUID() + '.mp3');
  try {
    await runCommand(config.ffmpegPath, [
      '-y', '-hide_banner', '-loglevel', 'error',
      '-i', asset.path,
      '-vn', '-ac', '2', '-ar', '44100',
      '-c:a', 'libmp3lame', '-b:a', '192k',
      output
    ], { timeoutMs: 5 * 60 * 1000 });
    const stat = await fs.promises.stat(output);
    if (!stat.size) throw new AppError(422, 'VIDEO_AUDIO_EMPTY', '这个视频没有可提取的音轨');
    const duration = await probeDuration(output);
    const audio = {
      id: crypto.randomUUID(),
      kind: 'audio',
      path: output,
      name: (asset.name || '视频') + ' · 提取音频',
      size: stat.size,
      width: 0,
      height: 0,
      duration,
      createdAt: now()
    };
    uploads.set(audio.id, audio);
    return publicUpload(audio);
  } catch (error) {
    safeUnlink(output);
    if (error instanceof AppError) throw error;
    throw new AppError(422, 'VIDEO_AUDIO_FAILED', '无法从视频中提取音频', '请换一个带声音的视频。');
  }
}

export function getPresets() {
  return {
    aspects: Object.values(ASPECTS),
    styles: STYLES,
    transitions: TRANSITIONS,
    filters: FILTERS,
    maxImages: config.imageVideoMaxImages,
    maxSeconds: config.maxImageVideoSeconds,
    defaultSeconds: 12,
    fps: 25,
    music: true,
    title: true,
    outputFormats: ['mp4'],
    engine: 'ffmpeg',
    license: 'CC0-1.0 · 内置音乐由代码生成'
  };
}

async function resolveAudioInput(job) {
  if (!job.audio || job.audio.type === 'none') return null;
  if (job.audio.type === 'music') {
    const track = await resolveMusic(job.audio.id);
    return {
      path: track.path,
      duration: track.duration,
      label: track.title,
      license: track.license,
      source: 'music'
    };
  }
  const asset = getUpload(job.audio.id);
  if (asset.kind !== 'audio') throw new AppError(400, 'AUDIO_REQUIRED', '请选择一个音频文件');
  return {
    path: asset.path,
    duration: asset.duration,
    label: asset.name,
    license: '',
    source: 'upload'
  };
}

function motionFilter(style, index, frames, motion, fps, bpm) {
  const zoomAmount = 0.1 * motion;
  const direction = index % 2 === 0 ? 1 : -1;
  switch (style) {
    case 'drift': {
      const maxZoom = 1.06 + 0.03 * motion;
      return {
        z: maxZoom.toFixed(4),
        x: direction > 0 ? '(iw-iw/zoom)*(on/' + frames + ')' : '(iw-iw/zoom)*(1-on/' + frames + ')',
        y: 'ih/2-(ih/zoom/2)'
      };
    }
    case 'kenburns': {
      const maxZoom = 1.04 + zoomAmount;
      return {
        z: 'min(1.02+' + (zoomAmount * 0.55 / frames).toFixed(8) + '*on,' + maxZoom.toFixed(4) + ')',
        x: direction > 0
          ? '(iw-iw/zoom)*(0.5+0.45*sin(on/' + frames + '*PI/2))'
          : '(iw-iw/zoom)*(0.5-0.45*sin(on/' + frames + '*PI/2))',
        y: '(ih-ih/zoom)*(0.5+' + (index % 3 === 0 ? '0.12' : '-0.08') + '*sin(on/' + frames + '*PI/2))'
      };
    }
    case 'alive': {
      const maxZoom = 1.14 + 0.04 * motion;
      const step = (0.075 * motion / frames).toFixed(8);
      return {
        z: 'min(1.035+' + step + '*on,' + maxZoom.toFixed(4) + ')',
        x: '(iw-iw/zoom)*(0.5+0.16*sin(on/' + frames + '*PI))',
        y: '(ih-ih/zoom)*(0.5+0.10*sin(on/' + frames + '*PI+1.2))'
      };
    }
    case 'breath': {
      const base = 1.035 + 0.02 * motion;
      return {
        z: '(' + base.toFixed(4) + '+0.012*sin(on/' + fps + '*0.9))',
        x: 'iw/2-(iw/zoom/2)',
        y: 'ih/2-(ih/zoom/2)'
      };
    }
    case 'beat': {
      const beatFrames = Math.max(8, Math.round(fps * 60 / Math.max(60, bpm || 100)));
      return {
        z: '(1.035+0.022*abs(sin(PI*on/' + beatFrames + ')))',
        x: 'iw/2-(iw/zoom/2)',
        y: 'ih/2-(ih/zoom/2)'
      };
    }
    case 'still':
      return { z: '1.001', x: 'iw/2-(iw/zoom/2)', y: 'ih/2-(ih/zoom/2)' };
    default: {
      const maxZoom = 1 + zoomAmount;
      return {
        z: 'min(1+' + (zoomAmount / frames).toFixed(8) + '*on,' + maxZoom.toFixed(4) + ')',
        x: 'iw/2-(iw/zoom/2)',
        y: 'ih/2-(ih/zoom/2)'
      };
    }
  }
}

function colorFilter(id) {
  switch (id) {
    case 'warm': return 'eq=contrast=1.04:saturation=1.12:brightness=0.008,colorbalance=rs=0.055:gs=0.008:bs=-0.045';
    case 'film': return 'eq=contrast=1.08:saturation=0.9:brightness=-0.012,colorbalance=rs=0.04:bs=-0.03,vignette=angle=PI/5';
    case 'cool': return 'eq=contrast=1.03:saturation=1.02,colorbalance=rs=-0.04:bs=0.06';
    case 'mono': return 'hue=s=0,eq=contrast=1.08';
    case 'vivid': return 'eq=contrast=1.06:saturation=1.28';
    default: return '';
  }
}

function setJob(job, patch) {
  Object.assign(job, patch, { updatedAt: now() });
}

export function publicImageVideoJob(job) {
  if (!job) return null;
  return {
    id: job.id,
    status: job.status,
    stage: job.stage,
    progress: job.progress,
    style: job.style,
    aspect: job.aspect,
    filter: job.filter,
    transition: job.transition,
    seconds: job.seconds,
    imageCount: job.imageIds.length,
    title: job.title,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    result: job.result,
    error: job.error
  };
}

async function makeOverlay(job, width, height) {
  if (!job.title && !job.subtitle) return null;
  const output = path.join(config.overlayDir, job.id + '.png');
  try {
    await runCommand(config.pythonBin, [
      config.overlayWorker,
      '--title', job.title,
      '--subtitle', job.subtitle,
      '--width', String(width),
      '--height', String(height),
      '--output', output
    ], { timeoutMs: 60 * 1000 });
    if (!fs.existsSync(output)) return null;
    return output;
  } catch (error) {
    return null;
  }
}

function buildFilterGraph(job, options) {
  const { width, height, imageCount, segmentSeconds, transitionSeconds, transition, overlayIndex, fps, bpm } = options;
  const scaleWidth = even(width * 1.2);
  const scaleHeight = even(height * 1.2);
  const parts = [];
  for (let index = 0; index < imageCount; index += 1) {
    const motion = motionFilter(job.style, index, Math.max(1, Math.round(segmentSeconds * fps)), job.motion, fps, bpm);
    parts.push(
      '[' + index + ':v]scale=' + scaleWidth + ':' + scaleHeight + ':force_original_aspect_ratio=increase:flags=lanczos,' +
      'crop=' + scaleWidth + ':' + scaleHeight + ',' +
      'zoompan=z=\'' + motion.z + '\':x=\'' + motion.x + '\':y=\'' + motion.y + '\':d=1:s=' + width + 'x' + height + ':fps=' + fps + ',' +
      'trim=duration=' + segmentSeconds.toFixed(3) + ',setpts=PTS-STARTPTS[v' + index + ']'
    );
  }

  let current = 'v0';
  if (imageCount > 1 && transition !== 'none') {
    const xfadeTransition = transition === 'slide' ? 'slideleft' : transition === 'zoom' ? 'zoomin' : 'fade';
    for (let index = 1; index < imageCount; index += 1) {
      const output = 'x' + index;
      const offset = (index * (segmentSeconds - transitionSeconds)).toFixed(3);
      parts.push('[' + current + '][v' + index + ']xfade=transition=' + xfadeTransition + ':duration=' + transitionSeconds.toFixed(3) + ':offset=' + offset + '[' + output + ']');
      current = output;
    }
  } else if (imageCount > 1) {
    const inputs = Array.from({ length: imageCount }, (_, index) => '[v' + index + ']').join('');
    parts.push(inputs + 'concat=n=' + imageCount + ':v=1:a=0[vcat]');
    current = 'vcat';
  }

  const grade = colorFilter(job.filter);
  const baseFilters = ['format=yuv420p'];
  if (grade) baseFilters.unshift(grade);
  const baseLabel = overlayIndex === null ? 'vout' : 'vbase';
  parts.push('[' + current + ']' + baseFilters.join(',') + '[' + baseLabel + ']');
  if (overlayIndex !== null) {
    parts.push('[' + overlayIndex + ':v]format=rgba,fade=t=in:st=0.45:d=0.65:alpha=1[ov]');
    parts.push('[vbase][ov]overlay=0:0:format=auto:eof_action=repeat[vout]');
  }
  return parts.join(';');
}

async function runImageVideoJob(job) {
  let outputPath = path.join(config.imageVideoDir, job.id + '.mp4');
  let overlayPath = null;
  try {
    setJob(job, { status: 'processing', stage: '正在读取素材', progress: 5 });
    const images = job.imageIds.map((id) => getUpload(id));
    if (images.length !== job.imageIds.length) throw new AppError(400, 'IMAGE_MISSING', '照片素材不完整');
    const audio = await resolveAudioInput(job);
    if (audio && audio.duration > 0 && !job.seconds) {
      job.seconds = Math.min(audio.duration, config.maxImageVideoSeconds);
    }
    const aspect = ASPECTS[job.aspect] || ASPECTS['9:16'];
    const width = aspect.width;
    const height = aspect.height;
    const totalSeconds = clamp(job.seconds || 12, 3, config.maxImageVideoSeconds);
    job.seconds = totalSeconds;
    const fps = 25;
    const imageCount = images.length;
    const transitionSeconds = job.transition === 'none' || imageCount === 1 ? 0 : Math.min(0.8, Math.max(0.35, totalSeconds / imageCount * 0.16));
    const segmentSeconds = imageCount > 1 && transitionSeconds > 0
      ? (totalSeconds + (imageCount - 1) * transitionSeconds) / imageCount
      : totalSeconds / imageCount;

    setJob(job, { stage: '正在渲染标题', progress: 9 });
    overlayPath = await makeOverlay(job, width, height);

    setJob(job, { stage: '正在生成动态镜头', progress: 12 });
    const args = ['-y', '-hide_banner', '-loglevel', 'error', '-progress', 'pipe:1', '-nostats'];
    for (const image of images) {
      args.push('-loop', '1', '-t', segmentSeconds.toFixed(3), '-i', image.path);
    }
    const overlayIndex = overlayPath ? imageCount : null;
    if (overlayPath) args.push('-loop', '1', '-t', totalSeconds.toFixed(3), '-i', overlayPath);
    let audioIndex;
    if (audio) {
      args.push('-stream_loop', '-1', '-i', audio.path);
      audioIndex = imageCount + (overlayPath ? 1 : 0);
    } else {
      args.push('-f', 'lavfi', '-t', totalSeconds.toFixed(3), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100');
      audioIndex = imageCount + (overlayPath ? 1 : 0);
    }

    const bpm = (audio && audio.source === 'music' && getMusicTrack(job.audio.id) && getMusicTrack(job.audio.id).bpm) || 100;
    const graph = buildFilterGraph(job, {
      width, height, imageCount, segmentSeconds, transitionSeconds,
      transition: job.transition, overlayIndex, fps, bpm
    });
    args.push('-filter_complex', graph, '-map', '[vout]', '-map', audioIndex + ':a:0');
    args.push('-t', totalSeconds.toFixed(3), '-r', String(fps));
    args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p');
    const fadeOutStart = Math.max(0.4, totalSeconds - 0.9);
    args.push(
      '-af', 'afade=t=in:st=0:d=0.6,afade=t=out:st=' + fadeOutStart.toFixed(2) + ':d=0.9,volume=0.92',
      '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2',
      '-movflags', '+faststart',
      outputPath
    );

    let progressBuffer = '';
    await runCommand(config.ffmpegPath, args, {
      timeoutMs: 20 * 60 * 1000,
      onStdout(chunk) {
        progressBuffer += chunk;
        const lines = progressBuffer.split('\n');
        progressBuffer = lines.pop() || '';
        for (const line of lines) {
          const match = line.match(/^out_time_(?:us|ms)=(\d+)/);
          if (!match) continue;
          const seconds = Number(match[1]) / 1000000;
          const ratio = Math.max(0, Math.min(1, seconds / totalSeconds));
          setJob(job, {
            progress: Math.max(job.progress, Math.min(95, Math.round(12 + ratio * 82))),
            stage: ratio >= 0.94 ? '正在封装成片' : '正在生成动态镜头'
          });
        }
      },
      onStderr() {}
    });

    const stat = await fs.promises.stat(outputPath);
    if (!stat.size) throw new AppError(500, 'IMAGE_VIDEO_EMPTY', '成片结果为空');
    const duration = await probeDuration(outputPath);
    setJob(job, {
      status: 'done',
      stage: '成片完成',
      progress: 100,
      result: {
        videoUrl: '/api/image-video/result/' + job.id + '.mp4',
        duration: Math.round((duration || totalSeconds) * 100) / 100,
        width,
        height,
        size: stat.size,
        style: job.style,
        aspect: job.aspect,
        filter: job.filter,
        transition: job.transition,
        title: job.title,
        imageCount,
        music: audio ? { title: audio.label, license: audio.license, source: audio.source } : null,
        license: 'CC0-1.0 · 内置音乐由代码生成'
      }
    });
  } catch (error) {
    safeUnlink(outputPath);
    const message = error instanceof AppError ? error.message : '照片成片失败，请稍后重试';
    const hint = error instanceof AppError ? error.hint : '请换一张清晰照片或更短的音乐重试。';
    setJob(job, {
      status: 'failed',
      stage: '处理失败',
      progress: Math.max(job.progress || 0, 2),
      error: { code: (error && error.code) || 'IMAGE_VIDEO_FAILED', message, hint }
    });
  } finally {
    safeUnlink(overlayPath);
  }
}

export function createImageVideoJob(input = {}) {
  const imageIds = Array.isArray(input.imageIds) ? input.imageIds.map(String).filter(Boolean) : [];
  if (!imageIds.length) throw new AppError(400, 'IMAGE_VIDEO_NO_IMAGE', '请先选择至少一张照片');
  if (imageIds.length > config.imageVideoMaxImages) {
    throw new AppError(413, 'IMAGE_VIDEO_TOO_MANY', '最多支持 ' + config.imageVideoMaxImages + ' 张照片');
  }
  for (const id of imageIds) {
    const asset = getUpload(id);
    if (asset.kind !== 'image') throw new AppError(400, 'IMAGE_REQUIRED', '请选择照片文件');
  }
  const style = STYLES.some((item) => item.id === input.style) ? input.style : 'slow-zoom';
  const aspect = ASPECTS[input.aspect] ? input.aspect : '9:16';
  const transition = TRANSITIONS.some((item) => item.id === input.transition) ? input.transition : 'fade';
  const filter = FILTERS.some((item) => item.id === input.filter) ? input.filter : 'none';
  const audioInput = input.audio && typeof input.audio === 'object' ? input.audio : { type: 'none' };
  const audioType = ['music', 'asset', 'none'].includes(audioInput.type) ? audioInput.type : 'none';
  if (audioType !== 'none' && !audioInput.id) throw new AppError(400, 'AUDIO_ID_MISSING', '请选择音乐');
  if (audioType === 'music' && !getMusicTrack(audioInput.id)) throw new AppError(404, 'MUSIC_NOT_FOUND', '内置音乐不存在');
  if (audioType === 'asset') {
    const asset = getUpload(audioInput.id);
    if (asset.kind !== 'audio') throw new AppError(400, 'AUDIO_REQUIRED', '请选择音频文件');
  }
  const seconds = clamp(input.seconds || 0, 0, config.maxImageVideoSeconds) || 0;
  const job = {
    id: crypto.randomUUID(),
    status: 'queued',
    stage: '排队中',
    progress: 0,
    imageIds,
    audio: audioType === 'none' ? { type: 'none' } : { type: audioType, id: String(audioInput.id) },
    style,
    aspect,
    transition,
    filter,
    seconds,
    motion: clamp(input.motion || 1, 0.6, 1.4),
    title: String(input.title || '').trim().slice(0, 28),
    subtitle: String(input.subtitle || '').trim().slice(0, 48),
    createdAt: now(),
    updatedAt: now(),
    result: null,
    error: null
  };
  jobs.set(job.id, job);
  runImageVideoJob(job);
  return job;
}

export function getImageVideoJob(id) {
  const job = jobs.get(String(id));
  if (!job) throw new AppError(404, 'IMAGE_VIDEO_NOT_FOUND', '成片任务不存在或已过期');
  return job;
}

export function getImageVideoOutput(id) {
  const job = getImageVideoJob(id);
  if (job.status !== 'done' || !job.result) throw new AppError(409, 'IMAGE_VIDEO_NOT_READY', '成片还没有完成');
  const outputPath = path.join(config.imageVideoDir, job.id + '.mp4');
  if (!fs.existsSync(outputPath)) throw new AppError(404, 'IMAGE_VIDEO_GONE', '成片文件已清理，请重新生成');
  return outputPath;
}

export function deleteImageVideoJob(id) {
  const job = jobs.get(String(id));
  if (!job) return false;
  jobs.delete(job.id);
  safeUnlink(path.join(config.imageVideoDir, job.id + '.mp4'));
  safeUnlink(path.join(config.overlayDir, job.id + '.png'));
  return true;
}

setInterval(() => {
  const uploadCutoff = now() - UPLOAD_TTL_MS;
  for (const [id, asset] of uploads.entries()) {
    if (asset.createdAt < uploadCutoff) {
      uploads.delete(id);
      safeUnlink(asset.path);
    }
  }
  const jobCutoff = now() - JOB_TTL_MS;
  for (const [id, job] of jobs.entries()) {
    if (job.updatedAt < jobCutoff) {
      jobs.delete(id);
      safeUnlink(path.join(config.imageVideoDir, id + '.mp4'));
      safeUnlink(path.join(config.overlayDir, id + '.png'));
    }
  }
}, 5 * 60 * 1000).unref();
