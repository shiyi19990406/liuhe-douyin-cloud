import fs from 'node:fs';
import { config } from '../../config.js';
import { runCommand } from '../../lib/process.js';

function chooseFormat(info) {
  const formats = Array.isArray(info.formats) ? info.formats : [];
  const direct = formats
    .filter((format) => format && format.url && /^https?:/i.test(format.url))
    .filter((format) => !format.vcodec || format.vcodec !== 'none')
    .map((format) => ({
      ...format,
      height: Number(format.height) || 0,
      width: Number(format.width) || 0,
      tbr: Number(format.tbr) || 0,
      isMp4: /mp4|m4v/i.test(String(format.ext || '')) || /video\/mp4/i.test(String(format.mime_type || '')),
      isHls: /m3u8/i.test(String(format.protocol || '')) || /\.m3u8/i.test(String(format.url || ''))
    }))
    .filter((format) => !format.isHls && format.isMp4)
    .sort((a, b) => b.height - a.height || b.tbr - a.tbr || b.width - a.width);
  if (direct.length) return direct[0];
  if (info.url && /^https?:/i.test(info.url)) {
    return { url: info.url };
  }
  return null;
}

export async function resolveWithYtDlp(url) {
  if (!config.ytdlpEnabled) return null;
  const args = [
    '--dump-single-json',
    '--no-warnings',
    '--no-playlist',
    '--skip-download',
    '--socket-timeout',
    '20',
    '--retries',
    '2'
  ];
  if (config.ytdlpCookiesFile && fs.existsSync(config.ytdlpCookiesFile)) {
    args.push('--cookies', config.ytdlpCookiesFile);
  }
  args.push(url);
  try {
    const { stdout } = await runCommand(config.ytdlpBin, args, { timeoutMs: 90000 });
    const start = stdout.indexOf('{');
    if (start === -1) return null;
    const info = JSON.parse(stdout.slice(start));
    if (!info || info._type === 'playlist' || Array.isArray(info.entries)) return null;
    const format = chooseFormat(info);
    if (!format || !format.url) return null;
    return {
      platform: 'douyin',
      id: String(info.id || ''),
      title: info.title || info.description || '抖音视频',
      author: info.uploader || info.channel || info.creator || '',
      authorId: info.uploader_id || '',
      cover: info.thumbnail || '',
      videoUrl: format.url,
      duration: Number(info.duration) || 0,
      stats: {
        digg_count: Number(info.like_count) || 0,
        comment_count: Number(info.comment_count) || 0,
        share_count: Number(info.repost_count) || 0
      },
      sourceUrl: info.webpage_url || url,
      quality: format.height ? format.height + 'P' : '原片',
      resolver: 'yt-dlp'
    };
  } catch (error) {
    console.warn('[resolver] yt-dlp failed:', error.message);
    return null;
  }
}
