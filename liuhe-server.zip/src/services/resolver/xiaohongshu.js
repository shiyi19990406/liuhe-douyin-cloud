import { fetchPage } from '../../lib/http.js';
import {
  extractBalancedJson,
  deepFind,
  getMetaContent,
  decodeHtml
} from '../../lib/json.js';
import { normalizeMediaUrl } from '../../lib/url.js';
import { resolveError } from '../../lib/errors.js';
import { config } from '../../config.js';

const NOTE_ID_PATTERNS = [
  /\/explore\/([0-9a-f]{16,32})/i,
  /\/discovery\/item\/([0-9a-f]{16,32})/i,
  /\/note\/([0-9a-f]{16,32})/i,
  /[?&](?:noteId|note_id)=([0-9a-f]{16,32})/i
];

function isHttp(url) {
  return /^https?:\/\//i.test(String(url || ''));
}

function isImageUrl(url) {
  const value = String(url || '');
  if (!isHttp(value)) return false;
  if (/\.(mp4|m3u8)(\?|$)/i.test(value)) return false;
  // 排除小红书首页/错误页里的 logo、favicon、头像、图标等装饰图。
  if (/picasso-static|fe-platform|favicon|\/logo|\/icon|\/avatar|sprite/i.test(value)) return false;
  if (/\.(jpe?g|png|webp|heic|avif)(\?|$)/i.test(value)) return true;
  if (/sns-video|xhscdn\.com\/stream|video/i.test(value)) return false;
  return /xhscdn\.com\//i.test(value) || /sns-webpic|sns-img/i.test(value);
}

function isVideoUrl(url) {
  const value = String(url || '');
  if (!isHttp(value) || isImageUrl(value)) return false;
  return /\.mp4|video|sns-video|xhscdn\.com\/stream|masterUrl/i.test(value);
}

function pushStrings(value, bucket) {
  if (!value) return;
  if (typeof value === 'string') {
    if (isHttp(value)) bucket.push(normalizeMediaUrl(value));
    return;
  }
  if (Array.isArray(value)) {
    value.forEach((item) => pushStrings(item, bucket));
    return;
  }
  if (typeof value === 'object') {
    Object.values(value).forEach((item) => pushStrings(item, bucket));
  }
}

function uniqueHttp(values, predicate, limit = 40) {
  const out = [];
  const seen = new Set();
  for (const value of values || []) {
    const url = normalizeMediaUrl(value);
    if (!predicate(url) || seen.has(url)) continue;
    seen.add(url);
    out.push(url);
    if (out.length >= limit) break;
  }
  return out;
}

export function extractXiaohongshuNoteId(input) {
  const value = String(input || '');
  for (const pattern of NOTE_ID_PATTERNS) {
    const match = value.match(pattern);
    if (match) return match[1];
  }
  return '';
}

function parseInitialState(html) {
  const tokens = [
    'window.__INITIAL_STATE__',
    '__INITIAL_STATE__',
    'window.__NUXT__',
    '__NUXT__'
  ];
  for (const token of tokens) {
    const index = html.indexOf(token);
    if (index === -1) continue;
    const raw = extractBalancedJson(html, index + token.length);
    if (!raw) continue;
    for (const candidate of [raw, raw.replace(/\bundefined\b/g, 'null'), decodeHtml(raw).replace(/\bundefined\b/g, 'null')]) {
      try {
        return JSON.parse(candidate);
      } catch (error) {
        // 尝试下一个 token。
      }
    }
  }
  return null;
}

function findNote(root) {
  if (!root) return null;
  return deepFind(root, (node) => {
    if (!node || typeof node !== 'object' || Array.isArray(node)) return false;
    const hasId = node.noteId || node.note_id || node.id;
    const hasImages = Array.isArray(node.imageList) || Array.isArray(node.image_list);
    const hasVideo = node.video && typeof node.video === 'object';
    return !!(hasId && (hasImages || hasVideo) && (node.title !== undefined || node.desc !== undefined || node.user));
  });
}

function imagesFromNote(note) {
  const bucket = [];
  const list = note.imageList || note.image_list || note.images || [];
  if (Array.isArray(list)) {
    for (const item of list) {
      if (typeof item === 'string') bucket.push(item);
      else if (item && typeof item === 'object') {
        pushStrings(item.urlDefault || item.url_default, bucket);
        pushStrings(item.urlPre || item.url_pre, bucket);
        pushStrings(item.url, bucket);
        pushStrings(item.infoList || item.info_list, bucket);
        pushStrings(item, bucket);
      }
    }
  }
  pushStrings(note.image, bucket);
  pushStrings(note.cover, bucket);
  return uniqueHttp(bucket, isImageUrl);
}

function videoFromNote(note) {
  const video = note.video || {};
  const bucket = [];
  const media = video.media || video;
  const stream = media.stream || media.streams || media;
  for (const codec of ['h264', 'h265', 'av1']) {
    const list = stream[codec];
    if (!Array.isArray(list)) continue;
    for (const item of list) {
      if (!item) continue;
      pushStrings(item.masterUrl || item.master_url, bucket);
      pushStrings(item.backupUrls || item.backup_urls, bucket);
      pushStrings(item.url, bucket);
    }
  }
  pushStrings(video.url, bucket);
  pushStrings(video.playUrl || video.play_url, bucket);
  pushStrings(media.video, bucket);
  const key = video.consumer && (video.consumer.originVideoKey || video.consumer.origin_video_key);
  if (key) bucket.push('https://sns-video-bd.xhscdn.com/' + String(key).replace(/^\/+/, ''));
  return uniqueHttp(bucket, isVideoUrl, 8)[0] || '';
}

function parseCount(value) {
  if (typeof value === 'number') return value;
  const text = String(value || '').trim();
  const num = parseFloat(text);
  if (!Number.isFinite(num)) return 0;
  if (/万|w/i.test(text)) return Math.round(num * 10000);
  if (/千|k/i.test(text)) return Math.round(num * 1000);
  return Math.round(num);
}

function buildResultFromNote(note, finalUrl, id) {
  if (!note) return null;
  const images = imagesFromNote(note);
  const videoUrl = videoFromNote(note);
  if (!videoUrl && !images.length) return null;

  const user = note.user || note.author || {};
  const interact = note.interactInfo || note.interact_info || note.stats || {};
  const video = note.video || {};
  const durationRaw = Number((video.capa && video.capa.duration) || video.duration || 0);
  const firstImage = images[0] || '';
  const coverCandidate = normalizeMediaUrl(
    (video.image && (video.image.firstFrame || video.image.first_frame)) ||
      note.cover ||
      firstImage
  );

  return {
    platform: 'xiaohongshu',
    id: String(note.noteId || note.note_id || note.id || id || ''),
    title: decodeHtml(note.title || note.desc || '小红书笔记'),
    author: decodeHtml(user.nickname || user.nickName || user.name || ''),
    authorId: String(user.userId || user.user_id || user.id || ''),
    cover: isImageUrl(coverCandidate) || videoUrl ? coverCandidate : '',
    videoUrl,
    images,
    type: videoUrl ? 'video' : 'images',
    duration: durationRaw > 1000 ? durationRaw / 1000 : durationRaw,
    stats: {
      digg_count: parseCount(interact.likedCount || interact.liked_count || interact.likeCount),
      comment_count: parseCount(interact.commentCount || interact.comment_count),
      share_count: parseCount(interact.shareCount || interact.share_count),
      collect_count: parseCount(interact.collectedCount || interact.collected_count || interact.collectCount)
    },
    sourceUrl: finalUrl,
    quality: '原片',
    resolver: 'xhs-native'
  };
}

function buildFromHtml(html, finalUrl, id) {
  const bucket = [];
  const patterns = [
    /"(?:urlDefault|url_default|urlPre|url_pre|masterUrl|master_url)"\s*:\s*"([^"]+)"/gi,
    /https?:\\?\/\\?\/[^"'\\\s]+?(?:\.jpg|\.jpeg|\.png|\.webp|sns-webpic|sns-img)[^"'\\\s]*/gi
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(html)) && bucket.length < 60) {
      bucket.push(String(match[1] || match[0]).replace(/\\\//g, '/').replace(/\\u002F/gi, '/'));
    }
  }
  const images = uniqueHttp(bucket, isImageUrl);
  const videoUrl = normalizeMediaUrl(getMetaContent(html, 'og:video') || getMetaContent(html, 'og:video:url'));
  const cover = normalizeMediaUrl(getMetaContent(html, 'og:image'));
  if (videoUrl && isHttp(videoUrl)) {
    return {
      platform: 'xiaohongshu',
      id,
      title: decodeHtml(getMetaContent(html, 'og:title') || '小红书视频'),
      author: '',
      cover: isImageUrl(cover) ? cover : '',
      videoUrl,
      images: isImageUrl(cover) ? [cover] : [],
      type: 'video',
      duration: 0,
      stats: {},
      sourceUrl: finalUrl,
      quality: '原片',
      resolver: 'xhs-meta'
    };
  }
  if (images.length) {
    return {
      platform: 'xiaohongshu',
      id,
      title: decodeHtml(getMetaContent(html, 'og:title') || '小红书图片'),
      author: '',
      cover: images[0],
      videoUrl: '',
      images,
      type: 'images',
      duration: 0,
      stats: {},
      sourceUrl: finalUrl,
      quality: '原片',
      resolver: 'xhs-html'
    };
  }
  return null;
}

export function buildXiaohongshuResult(state, finalUrl, id) {
  const note = findNote(state);
  return buildResultFromNote(note, finalUrl, id);
}

export async function resolveXiaohongshu(shareUrl) {
  let page;
  try {
    page = await fetchPage(shareUrl, {
      headers: Object.assign(
        {
          referer: 'https://www.xiaohongshu.com/',
          'accept-language': 'zh-CN,zh;q=0.9'
        },
        config.xhsCookie ? { cookie: config.xhsCookie } : {}
      ),
      timeoutMs: 22000
    });
  } catch (error) {
    throw resolveError('无法打开这条小红书链接', '链接可能已失效，请重新复制小红书 App 里的完整分享内容。');
  }

  const finalUrl = page.finalUrl || shareUrl;
  const id = extractXiaohongshuNoteId(finalUrl) || extractXiaohongshuNoteId(shareUrl);
  const state = parseInitialState(page.html);
  const built = buildXiaohongshuResult(state, finalUrl, id) || buildFromHtml(page.html, finalUrl, id);
  if (built) return built;

  if (/404\/sec_|当前笔记暂时无法浏览|安全验证|请登录|访问过于频繁/i.test(page.html)) {
    throw resolveError(
      '这条小红书笔记需要有效的分享链接',
      '请从小红书 App 复制完整分享内容（包含 xsec_token），不要只复制 /explore/ 编号链接。'
    );
  }

  throw resolveError(
    '暂时没有提取到小红书内容',
    '小红书可能限制了当前网络，或这篇笔记不是公开状态。请换一条公开笔记重试。'
  );
}
