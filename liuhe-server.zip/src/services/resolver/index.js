import { config } from '../../config.js';
import { fetchJson } from '../../lib/http.js';
import { detectPlatform, extractFirstUrl, ensureHttpUrl } from '../../lib/url.js';
import { AppError, resolveError } from '../../lib/errors.js';
import { resolveDemo } from './demo.js';
import { resolveDouyin } from './douyin.js';
import { resolveKuaishou } from './kuaishou.js';
import { resolveBilibili } from './bilibili.js';
import { resolveXiaohongshu } from './xiaohongshu.js';

const RESULT_TTL_MS = 3 * 60 * 1000;
const RESULT_CACHE_MAX = 120;
const resultCache = new Map();
const pendingResolve = new Map();

function cacheKey(url) {
  return String(url || '').trim();
}

function readCache(key) {
  const hit = resultCache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > RESULT_TTL_MS) {
    resultCache.delete(key);
    return null;
  }
  return hit.value;
}

function writeCache(key, value) {
  if (resultCache.size >= RESULT_CACHE_MAX) {
    const oldest = resultCache.keys().next().value;
    if (oldest) resultCache.delete(oldest);
  }
  resultCache.set(key, { value, at: Date.now() });
}

async function resolveWithCustomService(url) {
  if (!config.customResolverUrl) return null;
  try {
    const data = await fetchJson(config.customResolverUrl, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(config.customResolverToken ? { authorization: 'Bearer ' + config.customResolverToken } : {})
      },
      body: JSON.stringify({ url }),
      timeoutMs: 45000
    });
    const payload = data && (data.data || data);
    const images = Array.isArray(payload && payload.images)
      ? payload.images.filter((item) => typeof item === 'string' && /^https?:\/\//i.test(item))
      : [];
    if (payload && (payload.videoUrl || payload.downloadUrl || images.length)) {
      return {
        platform: payload.platform || detectPlatform(url) || 'douyin',
        id: String(payload.id || ''),
        title: payload.title || (images.length ? '图片' : '视频'),
        author: payload.author || '',
        cover: payload.cover || payload.coverUrl || images[0] || '',
        videoUrl: payload.videoUrl || payload.downloadUrl || '',
        images,
        type: payload.type || (payload.videoUrl || payload.downloadUrl ? 'video' : 'images'),
        duration: Number(payload.duration) || 0,
        stats: payload.stats || {},
        sourceUrl: payload.sourceUrl || url,
        quality: payload.quality || '原片',
        resolver: 'custom'
      };
    }
    return null;
  } catch (error) {
    console.warn('[resolver] custom service failed:', error.message);
    return null;
  }
}

export async function resolveVideo(input) {
  const url = extractFirstUrl(input);
  if (!url) {
    throw new AppError(400, 'NO_URL', '没有找到有效链接', '请粘贴完整的小红书、抖音或快手分享内容。');
  }
  ensureHttpUrl(url);
  const platform = detectPlatform(url);
  if (!platform) {
    throw new AppError(400, 'UNSUPPORTED_PLATFORM', '暂时只支持小红书、抖音和快手链接', '请确认分享内容包含 xiaohongshu.com、douyin.com 或 kuaishou.com 链接。');
  }

  if (config.demoMode) return resolveDemo(url);

  const key = cacheKey(url);
  const cached = readCache(key);
  if (cached) return cached;
  if (pendingResolve.has(key)) return pendingResolve.get(key);

  const task = (async () => {
    const custom = await resolveWithCustomService(url);
    if (custom) return custom;

    let result;
    if (platform === 'douyin') result = await resolveDouyin(url);
    else if (platform === 'xiaohongshu') result = await resolveXiaohongshu(url);
    else if (platform === 'bilibili') result = await resolveBilibili(url);
    else result = await resolveKuaishou(url);

    const images = result && Array.isArray(result.images)
      ? result.images.filter((item) => typeof item === 'string' && /^https?:\/\//i.test(item))
      : [];
    if (!result || (!result.videoUrl && !images.length)) {
      throw resolveError('没有提取到视频或图片', '平台可能更新了接口，请稍后重试或换一条公开内容。');
    }
    if (!result.type) result.type = result.videoUrl ? 'video' : 'images';
    if (!result.images) result.images = images;
    return result;
  })();

  pendingResolve.set(key, task);
  try {
    const result = await task;
    writeCache(key, result);
    return result;
  } finally {
    pendingResolve.delete(key);
  }
}
