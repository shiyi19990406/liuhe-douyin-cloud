import { fetchJson, fetchPage } from '../../lib/http.js';
import { normalizeMediaUrl, detectPlatform } from '../../lib/url.js';
import { resolveError } from '../../lib/errors.js';

const DESKTOP_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const QUALITY_LABELS = {
  6: '240P',
  16: '360P',
  32: '480P',
  64: '720P',
  74: '720P60'
};

function headers(referer) {
  return {
    referer: referer || 'https://www.bilibili.com/',
    origin: 'https://www.bilibili.com',
    'user-agent': DESKTOP_UA,
    accept: 'application/json, text/plain, */*',
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8'
  };
}

function extractVideoId(input) {
  const value = String(input || '');
  const bv = value.match(/BV[0-9A-Za-z]{10}/);
  if (bv) return { type: 'bvid', id: bv[0] };
  const av = value.match(/\/video\/av(\d+)/i) || value.match(/[?&]aid=(\d+)/i);
  if (av) return { type: 'aid', id: av[1] };
  return null;
}

function extractPage(input) {
  try {
    const page = Number(new URL(input).searchParams.get('p'));
    return Number.isFinite(page) && page > 0 ? page : 1;
  } catch (error) {
    return 1;
  }
}

export async function resolveBilibili(shareUrl) {
  let target = shareUrl;
  // b23.tv 短链先跟随跳转，拿到真正的视频地址。
  if (/b23\.tv/i.test(target) || /bili2233\.cn/i.test(target)) {
    try {
      const page = await fetchPage(target, {
        headers: headers(),
        timeoutMs: 18000
      });
      target = page.finalUrl || target;
    } catch (error) {
      throw resolveError('无法打开这条 B 站短链', '短链可能已失效，请改用完整视频链接重试。');
    }
  }

  const videoId = extractVideoId(target);
  if (!videoId) {
    throw resolveError('没有找到 B 站视频编号', '请粘贴包含 BV 号或 av 号的完整视频链接。');
  }

  const query = videoId.type === 'bvid' ? 'bvid=' + videoId.id : 'aid=' + videoId.id;
  let view;
  try {
    view = await fetchJson('https://api.bilibili.com/x/web-interface/view?' + query, {
      headers: headers(target),
      timeoutMs: 20000
    });
  } catch (error) {
    throw resolveError('B 站视频信息获取失败', '请稍后重试，或确认视频是公开可访问的。');
  }
  if (!view || view.code !== 0 || !view.data) {
    throw resolveError(
      'B 站返回了错误：' + ((view && view.message) || '未知错误'),
      '视频可能已失效、被设为私密，或需要登录 Cookie。'
    );
  }

  const data = view.data;
  const pages = Array.isArray(data.pages) && data.pages.length ? data.pages : [];
  const pageIndex = Math.min(pages.length || 1, extractPage(target)) - 1;
  const page = pages[pageIndex] || pages[0] || {};
  const cid = page.cid || data.cid;
  const duration = Number(page.duration || data.duration || 0);
  const bvid = data.bvid || (videoId.type === 'bvid' ? videoId.id : '');

  if (!cid) {
    throw resolveError('没有找到 B 站视频分 P 信息', '这条视频可能不是普通投稿，暂不支持。');
  }

  const params = new URLSearchParams({
    ...(bvid ? { bvid } : { avid: String(data.aid) }),
    cid: String(cid),
    qn: '64',
    fnval: '0',
    fnver: '0',
    fourk: '0'
  });

  let play;
  try {
    play = await fetchJson('https://api.bilibili.com/x/player/playurl?' + params.toString(), {
      headers: headers(target),
      timeoutMs: 20000
    });
  } catch (error) {
    throw resolveError('B 站播放地址获取失败', '请稍后重试。部分视频需要登录 Cookie 才能获取清晰度。');
  }

  if (!play || play.code !== 0 || !play.data) {
    throw resolveError(
      'B 站播放地址获取失败：' + ((play && play.message) || '未知错误'),
      '视频可能需要登录，或为付费 / 受限内容。本项目不处理付费内容。'
    );
  }

  const playData = play.data;
  const direct = Array.isArray(playData.durl) ? playData.durl.find((item) => item && item.url) : null;
  if (!direct) {
    throw resolveError(
      '这条 B 站视频没有可直接下载的 MP4 地址',
      '可能是 DASH-only 视频。当前版本优先支持普通投稿的 720P 渐进式 MP4。'
    );
  }

  const stat = data.stat || {};
  const quality = QUALITY_LABELS[playData.quality] || (playData.quality ? playData.quality + 'P' : '原片');
  return {
    platform: 'bilibili',
    id: bvid || String(data.aid || ''),
    title: data.title || 'B 站视频',
    author: (data.owner && data.owner.name) || '',
    authorId: data.owner && data.owner.mid ? String(data.owner.mid) : '',
    cover: normalizeMediaUrl(data.pic || ''),
    videoUrl: normalizeMediaUrl(direct.url),
    duration,
    stats: {
      digg_count: Number(stat.like) || 0,
      comment_count: Number(stat.reply) || 0,
      share_count: Number(stat.share) || 0,
      collect_count: Number(stat.favorite) || 0,
      view_count: Number(stat.view) || 0
    },
    sourceUrl: target,
    quality,
    music: '',
    resolver: 'bilibili-api'
  };
}
