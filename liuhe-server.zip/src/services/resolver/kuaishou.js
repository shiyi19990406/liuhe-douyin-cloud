import { fetchPage } from '../../lib/http.js';
import {
  parseJsonAfterToken,
  parseJsonScriptById,
  deepFind,
  findUrlsByKey,
  getMetaContent,
  decodeHtml
} from '../../lib/json.js';
import { normalizeMediaUrl } from '../../lib/url.js';
import { resolveError } from '../../lib/errors.js';
import { config } from '../../config.js';
import { resolveWithBrowser } from './browser.js';

function extractPhotoId(url) {
  const value = String(url || '');
  const patterns = [
    /\/short-video\/([A-Za-z0-9_-]+)/i,
    /\/photo\/([A-Za-z0-9_-]+)/i,
    /photoId=([A-Za-z0-9_-]+)/i,
    /\/fw\/photo\/([A-Za-z0-9_-]+)/i
  ];
  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (match) return match[1];
  }
  return '';
}

function normalizeCandidate(url) {
  if (!url || typeof url !== 'string') return '';
  return normalizeMediaUrl(url.trim()).replace(/\\u002F/gi, '/');
}

function isVideoUrl(url) {
  if (!url || !/^https?:\/\//i.test(url)) return false;
  if (/\.(jpg|jpeg|png|webp|gif|heic|svg)(\?|$)/i.test(url)) return false;
  if (/\.m3u8(\?|$)/i.test(url)) return false;
  return /\.mp4|video|kwaicdn|kwimgs|kspkg|yximgs|chenzhongtech|kuaishou/i.test(url);
}

function isImageUrl(url) {
  if (!url || !/^https?:\/\//i.test(url)) return false;
  if (/\.(mp4|m3u8)(\?|$)/i.test(url)) return false;
  if (/\.(jpe?g|png|webp|heic|avif)(\?|$)/i.test(url)) return true;
  return /kwimgs|yximgs|kspkg|kwaicdn.*image|photo/i.test(url);
}

function collectImageUrls(node) {
  const bucket = [];
  const preferred = ['photoUrl', 'srcNoMark', 'coverUrl', 'coverUrls', 'imageUrls', 'images', 'atlas', 'image'];
  for (const key of preferred) {
    if (node && node[key]) stringsFrom(node[key], bucket);
  }
  stringsFrom(findUrlsByKey(node, /^(photoUrl|srcNoMark|coverUrl|coverUrls|imageUrls|images|atlas|image|url)$/i), bucket);
  return Array.from(new Set(bucket.map(normalizeCandidate).filter(isImageUrl))).slice(0, 35);
}

function stringsFrom(value, bucket) {
  if (!value) return;
  if (typeof value === 'string') {
    if (/^https?:\/\//i.test(value)) bucket.push(value);
    return;
  }
  if (Array.isArray(value)) {
    value.forEach((item) => stringsFrom(item, bucket));
    return;
  }
  if (typeof value === 'object') {
    Object.values(value).forEach((item) => stringsFrom(item, bucket));
  }
}

function collectMediaUrls(node) {
  if (!node || typeof node !== 'object') return [];
  const urls = [];
  const preferred = ['srcNoMark', 'photoUrl', 'playUrl', 'photoH265Url', 'h265Url', 'mainMvUrls', 'manifest'];
  for (const key of preferred) {
    if (node[key]) stringsFrom(node[key], urls);
  }
  const extra = findUrlsByKey(node, /^(photoUrl|srcNoMark|playUrl|url|representation|adaptationSet|mainMvUrls)$/i);
  return Array.from(new Set(urls.concat(extra).map(normalizeCandidate).filter(isVideoUrl)));
}

function findPhoto(root) {
  return deepFind(root, (node) => {
    if (!node || typeof node !== 'object' || Array.isArray(node)) return false;
    const hasMedia = !!(node.photoUrl || node.srcNoMark || node.playUrl || node.mainMvUrls || node.manifest || node.imageUrls || node.images || node.atlas);
    const hasIdentity = !!(node.caption || node.userName || node.user || node.photoId || node.id);
    return hasMedia && hasIdentity;
  });
}

function extractState(html) {
  const tokens = [
    'window.__APOLLO_STATE__',
    '__APOLLO_STATE__',
    'window.__INITIAL_STATE__',
    '__INITIAL_STATE__',
    'window.__NEXT_DATA__',
    '__NEXT_DATA__',
    'window.__NUXT__',
    '__NUXT__'
  ];
  for (const token of tokens) {
    const parsed = parseJsonAfterToken(html, token);
    if (parsed) {
      const photo = findPhoto(parsed);
      if (photo) return photo;
    }
  }
  for (const id of ['__NEXT_DATA__', '__INITIAL_STATE__', '__APOLLO_STATE__']) {
    const parsed = parseJsonScriptById(html, id);
    if (parsed) {
      const photo = findPhoto(parsed);
      if (photo) return photo;
    }
  }
  return null;
}

function coverFrom(photo) {
  if (!photo) return '';
  const candidates = [];
  stringsFrom(photo.coverUrl, candidates);
  stringsFrom(photo.coverUrls, candidates);
  stringsFrom(photo.poster, candidates);
  stringsFrom(photo.cover, candidates);
  return normalizeCandidate(candidates.find((url) => /\.(jpg|jpeg|png|webp)/i.test(url)) || '');
}

function buildFromPhoto(photo, finalUrl, id) {
  if (!photo) return null;
  const urls = collectMediaUrls(photo);
  const images = collectImageUrls(photo);
  if (!urls.length && !images.length) return null;
  const authorNode = photo.user || photo.author || photo.userProfile || {};
  const durationRaw = Number(photo.duration || photo.videoDuration || photo.photoDuration || 0);
  const statsNode = photo.stats || photo;
  return {
    platform: 'kuaishou',
    id: String(photo.photoId || photo.id || id || ''),
    title: decodeHtml(photo.caption || photo.title || photo.desc || '快手视频'),
    author: decodeHtml(
      photo.userName ||
        photo.authorName ||
        authorNode.name ||
        authorNode.userName ||
        authorNode.nickname ||
        ''
    ),
    authorId: String(authorNode.id || authorNode.userId || ''),
    cover: coverFrom(photo) || images[0] || '',
    videoUrl: urls[0] || '',
    images,
    type: urls.length ? 'video' : 'images',
    duration: durationRaw > 1000 ? durationRaw / 1000 : durationRaw,
    stats: {
      digg_count: Number(statsNode.likeCount || statsNode.digg_count || 0),
      comment_count: Number(statsNode.commentCount || statsNode.comment_count || 0),
      share_count: Number(statsNode.shareCount || statsNode.share_count || 0),
      collect_count: Number(statsNode.collectCount || 0)
    },
    sourceUrl: finalUrl,
    quality: '原片',
    resolver: 'native'
  };
}

function buildFromHtmlPatterns(html, finalUrl, id) {
  const urls = [];
  const images = [];
  const patterns = [
    /"(?:photoUrl|srcNoMark|playUrl|photoH265Url)"\s*:\s*"((?:https?:)?\\?\/\\?\/[^"]+)"/gi,
    /<video[^>]+src=["']([^"']+)["']/gi,
    /"(?:coverUrl|coverUrls|imageUrls|images|atlas)"\s*:\s*("(?:[^"\\]|\\.)*")/gi
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(html)) && urls.length + images.length < 40) {
      const raw = match[1] || '';
      if (raw.startsWith('"')) {
        try {
          const parsed = JSON.parse(raw.replace(/\\"/g, '"'));
          stringsFrom(parsed, images);
        } catch (error) {
          // 忽略无法解析的片段。
        }
        continue;
      }
      const url = normalizeCandidate(raw);
      if (isVideoUrl(url)) urls.push(url);
      else if (isImageUrl(url)) images.push(url);
    }
  }
  if (!urls.length && !images.length) return null;
  const uniqueImages = Array.from(new Set(images));
  return {
    platform: 'kuaishou',
    id,
    title: getMetaContent(html, 'og:title') || (urls.length ? '快手视频' : '快手图片'),
    author: getMetaContent(html, 'og:site_name') || '',
    cover: normalizeMediaUrl(getMetaContent(html, 'og:image')) || uniqueImages[0] || '',
    videoUrl: urls[0] || '',
    images: uniqueImages,
    type: urls.length ? 'video' : 'images',
    duration: 0,
    stats: {},
    sourceUrl: finalUrl,
    quality: '原片',
    resolver: 'generic'
  };
}

function buildFromMeta(html, finalUrl, id) {
  const videoUrl = normalizeMediaUrl(getMetaContent(html, 'og:video') || getMetaContent(html, 'og:video:url'));
  const cover = normalizeMediaUrl(getMetaContent(html, 'og:image'));
  if (!videoUrl) {
    if (!isImageUrl(cover)) return null;
    return {
      platform: 'kuaishou',
      id,
      title: getMetaContent(html, 'og:title') || getMetaContent(html, 'description') || '快手图片',
      author: getMetaContent(html, 'og:site_name') || '',
      cover,
      videoUrl: '',
      images: [cover],
      type: 'images',
      duration: 0,
      stats: {},
      sourceUrl: finalUrl,
      quality: '原片',
      resolver: 'meta'
    };
  }
  return {
    platform: 'kuaishou',
    id,
    title: getMetaContent(html, 'og:title') || getMetaContent(html, 'description') || '快手视频',
    author: getMetaContent(html, 'og:site_name') || '',
    cover,
    videoUrl,
    images: isImageUrl(cover) ? [cover] : [],
    type: 'video',
    duration: 0,
    stats: {},
    sourceUrl: finalUrl,
    quality: '原片',
    resolver: 'meta'
  };
}

export async function resolveKuaishou(shareUrl) {
  let page;
  try {
    page = await fetchPage(shareUrl, {
      headers: { referer: 'https://www.kuaishou.com/' },
      timeoutMs: 22000
    });
  } catch (error) {
    throw resolveError('无法打开这条快手链接', '链接可能已失效，或平台限制了当前网络。请换一条公开作品重试。');
  }

  let finalUrl = page.finalUrl;
  let id = extractPhotoId(finalUrl) || extractPhotoId(shareUrl);
  let html = page.html;
  let photo = extractState(html);
  let built = buildFromPhoto(photo, finalUrl, id);
  if (built) return built;

  const mobileUrl = id ? 'https://v.m.chenzhongtech.com/fw/photo/' + id : '';
  if (mobileUrl && mobileUrl !== finalUrl) {
    try {
      const mobilePage = await fetchPage(mobileUrl, {
        headers: { referer: 'https://www.kuaishou.com/' },
        timeoutMs: 18000
      });
      html = html + '\n' + mobilePage.html;
      finalUrl = mobilePage.finalUrl || finalUrl;
      id = id || extractPhotoId(finalUrl);
      photo = extractState(mobilePage.html);
      built = buildFromPhoto(photo, finalUrl, id);
      if (built) return built;
    } catch (error) {
      // 继续尝试其它策略。
    }
  }

  built = buildFromHtmlPatterns(html, finalUrl, id);
  if (built) return built;

  built = buildFromMeta(html, finalUrl, id);
  if (built) return built;

  if (config.browserResolverEnabled) {
    try {
      const browser = await resolveWithBrowser(finalUrl || shareUrl, 'kuaishou');
      if (browser) return browser;
    } catch (error) {
      if (error instanceof Error && error.code === 'PLATFORM_BLOCKED') throw error;
    }
  }

  throw resolveError(
    '暂时没有提取到快手无水印地址',
    '快手页面可能触发了风控，或作品不是公开状态。可以稍后重试，或配置自建解析服务。'
  );
}
