import { config } from '../../config.js';
import { fetchPage, fetchJson } from '../../lib/http.js';
import {
  parseJsonAfterToken,
  parseJsonScriptById,
  deepFind,
  findUrlsByKey,
  getMetaContent,
  collectStringUrls,
  decodeHtml
} from '../../lib/json.js';
import { normalizeMediaUrl, detectPlatform } from '../../lib/url.js';
import { resolveWithYtDlp } from './ytdlp.js';
import { resolveWithBrowser } from './browser.js';
import { resolveError } from '../../lib/errors.js';

const VIDEO_ID_PATTERNS = [
  /\/video\/(\d{8,})/i,
  /\/note\/(\d{8,})/i,
  /modal_id=(\d{8,})/i,
  /aweme_id=(\d{8,})/i,
  /\/share\/video\/(\d{8,})/i,
  /\/share\/note\/(\d{8,})/i
];

function extractVideoId(url) {
  const value = String(url || '');
  for (const pattern of VIDEO_ID_PATTERNS) {
    const match = value.match(pattern);
    if (match) return match[1];
  }
  return '';
}

function urlListFrom(value) {
  if (!value) return [];
  if (typeof value === 'string') return [value];
  if (Array.isArray(value)) return value.filter((item) => typeof item === 'string');
  if (value.url_list) return value.url_list.filter((item) => typeof item === 'string');
  if (value.urlList) return value.urlList.filter((item) => typeof item === 'string');
  if (value.url) return [value.url];
  return [];
}

function normalizeCandidate(url) {
  if (!url || typeof url !== 'string') return '';
  let value = normalizeMediaUrl(url.trim());
  // playwm 是带水印的旧接口；换成 play 通常可以获得无水印源。
  value = value.replace('/playwm/', '/play/').replace('playwm?', 'play?');
  value = value.replace(/watermark=1/g, 'watermark=0');
  return value;
}

function isUsableVideoUrl(url) {
  if (!url || !/^https?:\/\//i.test(url)) return false;
  if (/\.(jpg|jpeg|png|webp|gif|heic)(\?|$)/i.test(url)) return false;
  if (/\.m3u8(\?|$)/i.test(url)) return false;
  return /\.mp4|video|douyinvod|bytecdn|byteimg|snssdk|iesdouyin|aweme/i.test(url);
}

function isUsableImageUrl(url) {
  if (!url || !/^https?:\/\//i.test(url)) return false;
  if (/\.(mp4|m3u8)(\?|$)/i.test(url)) return false;
  if (/\.(jpe?g|png|webp|heic|avif)(\?|$)/i.test(url)) return true;
  return /douyinpic|byteimg|ibyteimg|imagex|snssdk.*image/i.test(url);
}

function collectImageUrls(value, bucket = []) {
  if (!value) return bucket;
  if (typeof value === 'string') {
    if (isUsableImageUrl(normalizeMediaUrl(value))) bucket.push(normalizeMediaUrl(value));
    return bucket;
  }
  if (Array.isArray(value)) {
    value.forEach((item) => collectImageUrls(item, bucket));
    return bucket;
  }
  if (typeof value === 'object') {
    const preferred = ['url_list', 'urlList', 'download_url_list', 'downloadUrlList', 'url'];
    for (const key of preferred) {
      if (value[key]) collectImageUrls(value[key], bucket);
    }
    for (const [key, item] of Object.entries(value)) {
      if (preferred.includes(key)) continue;
      if (/image|url|display|origin|download/i.test(key)) collectImageUrls(item, bucket);
    }
  }
  return bucket;
}

function imagesFromAweme(aweme) {
  if (!aweme) return [];
  const nodes = [];
  if (Array.isArray(aweme.images)) nodes.push(aweme.images);
  if (aweme.image_post_info) nodes.push(aweme.image_post_info);
  if (aweme.imagePostInfo) nodes.push(aweme.imagePostInfo);
  if (aweme.image_post) nodes.push(aweme.image_post);
  const bucket = [];
  for (const node of nodes) collectImageUrls(node, bucket);
  return Array.from(new Set(bucket)).slice(0, 35);
}

function collectFromVideo(video) {
  if (!video || typeof video !== 'object') return [];
  const urls = [];
  const push = (value) => {
    for (const item of urlListFrom(value)) {
      const normalized = normalizeCandidate(item);
      if (isUsableVideoUrl(normalized)) urls.push(normalized);
    }
  };

  push(video.play_addr_h264);
  push(video.playAddrH264);
  push(video.play_addr);
  push(video.playAddr);
  push(video.play_addr_265);
  push(video.download_addr);
  push(video.downloadAddr);

  const bitRates = []
    .concat(Array.isArray(video.bit_rate) ? video.bit_rate : [])
    .concat(Array.isArray(video.bitRateList) ? video.bitRateList : [])
    .filter(Boolean)
    .sort((a, b) => Number(b.bit_rate || b.bitRate || 0) - Number(a.bit_rate || a.bitRate || 0));
  for (const item of bitRates) {
    push(item.play_addr || item.playAddr);
    push(item.play_addr_264 || item.playAddr264);
  }

  const uri = video.play_addr && (video.play_addr.uri || video.play_addr.url_key);
  if (!urls.length && uri) {
    urls.push('https://www.iesdouyin.com/aweme/v1/play/?video_id=' + encodeURIComponent(uri) + '&ratio=1080p&line=0');
  }
  return urls;
}

function findAweme(root) {
  if (!root) return null;
  const direct = deepFind(root, (node) => {
    if (!node || typeof node !== 'object' || Array.isArray(node)) return false;
    const video = node.video;
    const hasVideo = !!(video && (video.play_addr || video.playAddr || video.play_addr_h264 || video.download_addr));
    const hasImages = !!(node.images || node.image_post_info || node.imagePostInfo);
    return !!((hasVideo || hasImages) &&
      (node.desc !== undefined || node.aweme_id || node.awemeId));
  });
  if (direct) return direct;

  const list = deepFind(root, (node) => {
    return !!(
      node &&
      Array.isArray(node.item_list) &&
      node.item_list.some((item) => item && (item.video || item.images || item.image_post_info))
    );
  });
  if (list && list.item_list && list.item_list.length) return list.item_list[0];

  return deepFind(root, (node) => {
    return !!(
      node &&
      typeof node === 'object' &&
      node.video &&
      (node.video.play_addr || node.video.playAddr)
    );
  });
}

function extractAwemeData(html) {
  const tokens = [
    'window._ROUTER_DATA',
    '_ROUTER_DATA',
    'window.__INITIAL_STATE__',
    '__INITIAL_STATE__',
    'window.__NEXT_DATA__',
    '__NEXT_DATA__'
  ];
  for (const token of tokens) {
    const parsed = parseJsonAfterToken(html, token);
    if (parsed) {
      const aweme = findAweme(parsed);
      if (aweme) return aweme;
    }
  }
  const renderData = parseJsonScriptById(html, 'RENDER_DATA');
  if (renderData) {
    const aweme = findAweme(renderData);
    if (aweme) return aweme;
  }
  return null;
}

function buildFromAweme(aweme, finalUrl, id) {
  const video = aweme.video || {};
  const author = aweme.author || aweme.authorInfo || {};
  const music = aweme.music || {};
  const coverList =
    urlListFrom(video.cover) ||
    [];
  const coverCandidates = []
    .concat(urlListFrom(video.cover))
    .concat(urlListFrom(video.dynamic_cover))
    .concat(urlListFrom(video.origin_cover))
    .concat(urlListFrom(aweme.cover))
    .filter(Boolean);
  const candidates = collectFromVideo(video);
  const fallbackUrls = findUrlsByKey(video, /play_addr|playAddr|play_url|download_addr|downloadAddr/i)
    .map(normalizeCandidate)
    .filter(isUsableVideoUrl);
  const all = Array.from(new Set(candidates.concat(fallbackUrls)));
  const images = imagesFromAweme(aweme);
  if (!all.length && !images.length) return null;

  const durationMs = Number(video.duration || aweme.duration || 0);
  const stats = aweme.statistics || aweme.stats || {};
  return {
    platform: 'douyin',
    id: String(aweme.aweme_id || aweme.awemeId || id || ''),
    title: decodeHtml(aweme.desc || aweme.title || (images.length ? '抖音图片' : '抖音视频')),
    author: decodeHtml(author.nickname || author.name || aweme.authorName || ''),
    authorId: String(author.unique_id || author.sec_uid || ''),
    cover: normalizeMediaUrl(coverCandidates[0] || images[0] || getMetaContent('', 'og:image') || ''),
    videoUrl: all[0] || '',
    images,
    type: all.length ? 'video' : 'images',
    duration: durationMs > 1000 ? durationMs / 1000 : durationMs,
    stats: {
      digg_count: Number(stats.digg_count || stats.diggCount || 0),
      comment_count: Number(stats.comment_count || stats.commentCount || 0),
      share_count: Number(stats.share_count || stats.shareCount || 0),
      collect_count: Number(stats.collect_count || stats.collectCount || 0)
    },
    sourceUrl: finalUrl,
    quality: '原片',
    resolver: 'native',
    music: music.title || ''
  };
}

function buildFromMeta(html, finalUrl, id) {
  const videoUrl = normalizeMediaUrl(getMetaContent(html, 'og:video') || getMetaContent(html, 'og:video:url'));
  const cover = normalizeMediaUrl(getMetaContent(html, 'og:image'));
  if (!videoUrl) {
    if (!isUsableImageUrl(cover)) return null;
    return {
      platform: 'douyin',
      id,
      title: getMetaContent(html, 'og:title') || '抖音图片',
      author: getMetaContent(html, 'og:site_name') || '',
      cover,
      videoUrl: '',
      images: [cover],
      type: 'images',
      duration: 0,
      stats: {},
      sourceUrl: finalUrl,
      quality: '原片',
      resolver: 'meta'
    };
  }
  return {
    platform: 'douyin',
    id,
    title: getMetaContent(html, 'og:title') || '抖音视频',
    author: getMetaContent(html, 'og:site_name') || '',
    cover,
    videoUrl,
    images: isUsableImageUrl(cover) ? [cover] : [],
    type: 'video',
    duration: 0,
    stats: {},
    sourceUrl: finalUrl,
    quality: '原片',
    resolver: 'meta'
  };
}

async function fetchItemInfo(id) {
  if (!id) return null;
  try {
    const data = await fetchJson(
      'https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/?item_ids=' + encodeURIComponent(id),
      {
        headers: {
          referer: 'https://www.iesdouyin.com/',
          accept: 'application/json, text/plain, */*'
        },
        timeoutMs: 15000
      }
    );
    if (data && Array.isArray(data.item_list) && data.item_list[0]) return data.item_list[0];
    if (data && data.aweme_detail) return data.aweme_detail;
    if (data && data.itemInfo && data.itemInfo.item_list && data.itemInfo.item_list[0]) {
      return data.itemInfo.item_list[0];
    }
  } catch (error) {
    console.warn('[douyin] iteminfo fallback failed:', error.message);
  }
  return null;
}

export async function resolveDouyin(shareUrl) {
  let page;
  const earlyId = extractVideoId(shareUrl);
  const earlyItemPromise = earlyId
    ? fetchItemInfo(earlyId).catch(() => null)
    : Promise.resolve(null);
  try {
    page = await fetchPage(shareUrl, {
      headers: { referer: 'https://www.douyin.com/' },
      timeoutMs: 22000
    });
  } catch (error) {
    const ytdlp = await resolveWithYtDlp(shareUrl);
    if (ytdlp) return ytdlp;
    throw resolveError('无法打开这条抖音链接', '链接可能已失效，或当前网络被平台限制。请稍后重试。');
  }

  const finalUrl = page.finalUrl;
  const id = extractVideoId(finalUrl) || extractVideoId(shareUrl);
  let aweme = extractAwemeData(page.html);
  const htmlPages = [page.html];
  let resolvedUrl = finalUrl;

  if (!aweme && id) {
    const sharePageUrl = 'https://www.iesdouyin.com/share/video/' + id + '/';
    if (sharePageUrl !== finalUrl) {
      try {
        const sharePage = await fetchPage(sharePageUrl, {
          headers: { referer: 'https://www.douyin.com/' },
          timeoutMs: 18000
        });
        htmlPages.push(sharePage.html);
        resolvedUrl = sharePage.finalUrl || resolvedUrl;
        aweme = extractAwemeData(sharePage.html);
      } catch (error) {
        // 继续尝试其它方式。
      }
    }
  }

  if (!aweme && id) {
    const item = await earlyItemPromise;
    if (item) aweme = item;
  }

  if (aweme) {
    const built = buildFromAweme(aweme, resolvedUrl, id);
    if (built) return built;
  }

  for (const html of htmlPages) {
    const fromMeta = buildFromMeta(html, resolvedUrl, id);
    if (fromMeta) return fromMeta;
  }

  if (config.browserResolverEnabled) {
    try {
      const browser = await resolveWithBrowser(resolvedUrl || 'https://www.douyin.com/video/' + id, 'douyin');
      if (browser) return browser;
    } catch (error) {
      if (error instanceof Error && error.code === 'PLATFORM_BLOCKED') throw error;
    }
  }

  if (id) {
    const ytdlp = await resolveWithYtDlp(resolvedUrl || 'https://www.douyin.com/video/' + id);
    if (ytdlp) return ytdlp;
  }

  const genericUrls = [];
  for (const html of htmlPages) {
    const matches = html.match(/https?:\\?\/\\?\/[^"'\\\s]+?(?:\.mp4|video\/tos)[^"'\\\s]*/gi) || [];
    matches.forEach((item) => {
      const normalized = normalizeMediaUrl(item.replace(/\\\//g, '/'));
      if (isUsableVideoUrl(normalized)) genericUrls.push(normalized);
    });
  }
  if (genericUrls.length) {
    return {
      platform: 'douyin',
      id,
      title: getMetaContent(htmlPages[0], 'og:title') || '抖音视频',
      author: '',
      cover: normalizeMediaUrl(getMetaContent(htmlPages[0], 'og:image')),
      videoUrl: genericUrls[0],
      images: isUsableImageUrl(getMetaContent(htmlPages[0], 'og:image')) ? [normalizeMediaUrl(getMetaContent(htmlPages[0], 'og:image'))] : [],
      type: 'video',
      duration: 0,
      stats: {},
      sourceUrl: resolvedUrl,
      quality: '原片',
      resolver: 'generic'
    };
  }

  const genericImages = [];
  for (const html of htmlPages) {
    const matches = html.match(/https?:\\?\/\\?\/[^"'\\\s]+?(?:\.jpg|\.jpeg|\.png|\.webp|douyinpic|byteimg)[^"'\\\s]*/gi) || [];
    matches.forEach((item) => {
      const normalized = normalizeMediaUrl(item.replace(/\\\//g, '/'));
      if (isUsableImageUrl(normalized)) genericImages.push(normalized);
    });
  }
  const uniqueImages = Array.from(new Set(genericImages)).slice(0, 35);
  if (uniqueImages.length) {
    return {
      platform: 'douyin',
      id,
      title: getMetaContent(htmlPages[0], 'og:title') || '抖音图片',
      author: '',
      cover: uniqueImages[0],
      videoUrl: '',
      images: uniqueImages,
      type: 'images',
      duration: 0,
      stats: {},
      sourceUrl: resolvedUrl,
      quality: '原片',
      resolver: 'generic'
    };
  }

  throw resolveError(
    '暂时没有提取到无水印地址',
    '抖音可能触发了风控。可以重试、换一条公开视频，或配置 YTDLP_COOKIES_FILE 后重启服务。'
  );
}
