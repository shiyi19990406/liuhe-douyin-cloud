import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { runCommand } from '../../lib/process.js';
import { AppError } from '../../lib/errors.js';
import { decodeHtml, getMetaContent } from '../../lib/json.js';
import { normalizeMediaUrl } from '../../lib/url.js';
import { config } from '../../config.js';

const CHROME_CANDIDATES = [
  config.chromePath,
  process.env.CHROME_PATH,
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/usr/bin/google-chrome-stable',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/snap/bin/chromium'
];

export function findChrome() {
  for (const candidate of CHROME_CANDIDATES) {
    if (candidate && fs.existsSync(candidate)) return candidate;
  }
  return '';
}

function firstMatch(text, patterns) {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return decodeHtml(match[1]).trim();
  }
  return '';
}

function collectSources(dom) {
  const urls = [];
  const sourcePattern = /<(?:source|video)[^>]+src=["']([^"']+)["']/gi;
  let match;
  while ((match = sourcePattern.exec(dom)) && urls.length < 60) {
    const url = normalizeMediaUrl(decodeHtml(match[1]));
    if (/^https?:\/\//i.test(url) && /\.mp4|video\/tos|mime_type=video|douyinvod|kwaicdn|yximgs|kspkg/i.test(url)) {
      urls.push(url);
    }
  }
  return Array.from(new Set(urls));
}

function collectCover(dom) {
  const patterns = [
    /<video[^>]+poster=["']([^"']+)["']/i,
    /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i,
    /<img[^>]+src=["'](https?:\/\/[^"']*(?:pcweb_cover|cover|aweme\/[^"']*|p\d+-pc-sign\.douyinpic)[^"']*)["']/i
  ];
  for (const pattern of patterns) {
    const match = dom.match(pattern);
    if (match) {
      const url = normalizeMediaUrl(decodeHtml(match[1]));
      if (/^https?:\/\//i.test(url)) return url;
    }
  }
  return '';
}

function looksBlocked(dom) {
  return /captcha|verify-center|验证码|安全验证|访问过于频繁|ArgusSecurityPlugin|请登录/i.test(dom) && dom.length < 400000;
}

export async function resolveWithBrowser(url, platform) {
  if (!config.browserResolverEnabled) return null;
  const chrome = findChrome();
  if (!chrome) return null;
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cy-chrome-'));
  const args = [
    '--headless=new',
    '--disable-gpu',
    ...(config.chromeNoSandbox ? ['--no-sandbox'] : []),
    '--disable-dev-shm-usage',
    '--no-first-run',
    '--no-default-browser-check',
    '--mute-audio',
    '--hide-scrollbars',
    '--disable-blink-features=AutomationControlled',
    '--window-size=1280,1600',
    '--virtual-time-budget=14000',
    '--timeout=30000',
    `--user-data-dir=${userDataDir}`,
    '--dump-dom',
    url
  ];
  try {
    const { stdout } = await runCommand(chrome, args, { timeoutMs: 55000 });
    const dom = stdout || '';
    const sources = collectSources(dom);
    if (!sources.length) {
      if (looksBlocked(dom)) {
        throw new AppError(
          422,
          'PLATFORM_BLOCKED',
          '平台要求完成安全验证',
          '请稍后重试，或在 YTDLP_COOKIES_FILE 中配置已登录浏览器的 Cookie。'
        );
      }
      return null;
    }
    const isKuaishou = platform === 'kuaishou';
    const title = (firstMatch(dom, [/<title[^>]*>([\s\S]*?)<\/title>/i, /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i]) || '')
      .replace(/\s*-\s*抖音\s*$/i, '')
      .replace(/\s*-\s*快手\s*$/i, '')
      .trim();
    const description = getMetaContent(dom, 'description') || getMetaContent(dom, 'og:description');
    const authorMatch = description.match(/-\s*([^于]{1,40})于\d{8}发布在抖音/);
    const author = authorMatch ? authorMatch[1].trim() : '';
    const matchedSource = sources[0];
    const durationMatch = dom.match(/"duration"\s*:\s*(\d+(?:\.\d+)?)/);
    return {
      platform: isKuaishou ? 'kuaishou' : 'douyin',
      id: '',
      title: title || (isKuaishou ? '快手视频' : '抖音视频'),
      author,
      cover: collectCover(dom),
      videoUrl: matchedSource,
      duration: durationMatch ? Number(durationMatch[1]) : 0,
      stats: {},
      sourceUrl: url,
      quality: '原片',
      resolver: 'browser'
    };
  } catch (error) {
    if (error instanceof AppError) throw error;
    console.warn('[browser] resolve failed:', error.message);
    return null;
  } finally {
    try {
      fs.rmSync(userDataDir, { recursive: true, force: true });
    } catch (error) {
      // 忽略。
    }
  }
}
