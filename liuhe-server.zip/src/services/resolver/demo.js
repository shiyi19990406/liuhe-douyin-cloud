import fs from 'node:fs';
import path from 'node:path';
import { config } from '../../config.js';
import { detectPlatform } from '../../lib/url.js';

const FALLBACK_SEGMENTS = [
  { start: 0.25, end: 4.68, text: '欢迎来到六和，一个把灵感留得更清楚的地方。' },
  { start: 5.0, end: 10.87, text: '在这里，你可以保存喜欢的视频，也可以让台词跟着你走。' },
  { start: 11.19, end: 16.56, text: '粘贴链接，或者选择本地视频，字幕会自动生成。' },
  { start: 16.88, end: 22.58, text: '所有能力都来自开源技术，没有会员，也没有次数限制。' },
  { start: 22.9, end: 26.98, text: '现在，试着写下一句属于你的开场白吧。' }
];

function loadSegments() {
  const file = path.join(config.publicDir, 'demo', 'segments.json');
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (Array.isArray(parsed) && parsed.length) return parsed;
  } catch (error) {
    // 使用内置文案。
  }
  return FALLBACK_SEGMENTS;
}

const DEMO_SEGMENTS = loadSegments();

export function resolveDemo(shareUrl) {
  const platform = detectPlatform(shareUrl) || 'douyin';
  const duration = DEMO_SEGMENTS.length ? DEMO_SEGMENTS[DEMO_SEGMENTS.length - 1].end + 0.3 : 27.3;
  return {
    platform,
    id: 'demo-2026',
    title: '把灵感留得再清楚一点｜六和演示片',
    author: '六和 Studio',
    authorId: 'liuhe',
    cover: '/demo/cover.jpg',
    videoUrl: '/demo/demo.mp4',
    duration: Math.round(duration * 10) / 10,
    stats: {
      digg_count: 12800,
      comment_count: 326,
      share_count: 912,
      collect_count: 2048
    },
    sourceUrl: String(shareUrl || '').trim(),
    quality: '1080P',
    demo: true,
    resolver: 'demo',
    segments: DEMO_SEGMENTS
  };
}

export { DEMO_SEGMENTS };
