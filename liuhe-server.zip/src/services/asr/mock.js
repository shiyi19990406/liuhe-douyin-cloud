import { DEMO_SEGMENTS } from '../resolver/demo.js';

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function transcribeWithMock(options = {}) {
  if (options.onStage) options.onStage('正在整理演示字幕');
  await delay(900);
  if (options.onProgress) options.onProgress(50);
  await delay(600);
  const duration = Number(options.duration) || 18;
  const segments = DEMO_SEGMENTS.filter((segment) => segment.start < duration).map((segment) => ({
    start: segment.start,
    end: Math.min(segment.end, duration),
    text: segment.text
  }));
  if (!segments.length) {
    segments.push({
      start: 0,
      end: Math.max(1, duration),
      text: '这是一条演示字幕。接入本地 Whisper 后，会显示真实的识别结果。'
    });
  }
  if (options.onProgress) options.onProgress(92);
  return {
    provider: '演示字幕',
    language: 'zh',
    duration,
    segments
  };
}
