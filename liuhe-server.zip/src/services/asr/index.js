import { config } from '../../config.js';
import { AppError } from '../../lib/errors.js';
import { transcribeWithLocal, transcribeWithFollow, shutdownWhisper } from './local.js';
import { transcribeWithMock } from './mock.js';

export async function transcribeAudio(filePath, options = {}) {
  if (config.asrProvider === 'mock') {
    return transcribeWithMock(options);
  }
  if (config.asrProvider === 'local') {
    return transcribeWithLocal(filePath, options);
  }
  throw new AppError(
    500,
    'ASR_PROVIDER_UNKNOWN',
    '未知的识别引擎',
    'ASR_PROVIDER 只支持 local 或 mock。'
  );
}

export { transcribeWithFollow, shutdownWhisper };
