import { spawn } from 'node:child_process';
import path from 'node:path';
import { config } from '../../config.js';
import { AppError } from '../../lib/errors.js';

class WhisperWorker {
  constructor(options = {}) {
    this.modelName = options.modelName || config.whisperModel;
    this.computeType = options.computeType || config.whisperComputeType;
    this.beamSize = options.beamSize || config.whisperBeamSize;
    this.process = null;
    this.ready = false;
    this.starting = null;
    this.pending = new Map();
    this.buffer = '';
    this.seq = 0;
    this.lastError = '';
  }

  start() {
    if (this.process && this.ready) return Promise.resolve();
    if (this.starting) return this.starting;
    this.starting = new Promise((resolve, reject) => {
      const env = {
        ...process.env,
        PYTHONUNBUFFERED: '1',
        WHISPER_MODEL: this.modelName,
        WHISPER_DEVICE: config.whisperDevice,
        WHISPER_COMPUTE_TYPE: this.computeType,
        WHISPER_LANGUAGE: config.whisperLanguage,
        WHISPER_BEAM_SIZE: String(this.beamSize)
      };
      if (config.hfEndpoint) env.HF_ENDPOINT = config.hfEndpoint;
      const child = spawn(config.pythonBin, [config.whisperWorker], {
        cwd: config.serverRoot,
        env,
        stdio: ['pipe', 'pipe', 'pipe']
      });
      this.process = child;
      this.ready = false;
      this.lastError = '';
      let settled = false;

      const readyTimer = setTimeout(() => {
        if (settled) return;
        settled = true;
        this.terminate();
        reject(
          new AppError(
            503,
            'ASR_MODEL_TIMEOUT',
            '本地 Whisper 模型加载超时',
            '首次运行需要下载模型，请检查网络，或提前运行 npm run setup:asr。'
          )
        );
      }, 15 * 60 * 1000);

      const finishStart = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(readyTimer);
        if (error) {
          this.starting = null;
          reject(error);
        } else {
          this.ready = true;
          this.starting = null;
          resolve();
        }
      };

      child.stdout.setEncoding('utf8');
      child.stdout.on('data', (chunk) => {
        this.buffer += chunk;
        let index = this.buffer.indexOf('\n');
        while (index !== -1) {
          const line = this.buffer.slice(0, index).trim();
          this.buffer = this.buffer.slice(index + 1);
          if (line) this.handleLine(line, finishStart);
          index = this.buffer.indexOf('\n');
        }
      });

      child.stderr.setEncoding('utf8');
      child.stderr.on('data', (chunk) => {
        const text = String(chunk).trim();
        if (text) {
          this.lastError = text.slice(-1500);
          if (/Downloading|%\|/.test(text)) {
            console.log('[whisper]', text.slice(0, 300));
          }
        }
      });

      child.on('error', (error) => {
        const wrapped =
          error.code === 'ENOENT'
            ? new AppError(
                503,
                'ASR_PYTHON_MISSING',
                '找不到 Python 环境',
                '请先运行 npm run setup:asr 安装本地 Whisper。'
              )
            : new AppError(503, 'ASR_START_FAILED', '本地 Whisper 启动失败', error.message);
        this.failAll(wrapped);
        finishStart(wrapped);
      });

      child.on('close', (code) => {
        const error = new AppError(
          503,
          'ASR_WORKER_EXITED',
          '本地 Whisper 进程已退出',
          this.lastError || '请检查服务器内存与模型文件，或重新启动服务。'
        );
        this.failAll(error);
        if (!settled) finishStart(error);
        this.process = null;
        this.ready = false;
      });
    });
    return this.starting;
  }

  handleLine(line, finishStart) {
    let message;
    try {
      message = JSON.parse(line);
    } catch (error) {
      return;
    }
    if (message.type === 'ready') {
      if (finishStart) finishStart();
      return;
    }
    if (message.type === 'fatal') {
      const error = new AppError(
        503,
        'ASR_MODEL_FAILED',
        '本地 Whisper 模型加载失败',
        message.message || '请运行 npm run setup:asr 检查模型。'
      );
      this.lastError = message.message || '';
      if (finishStart) finishStart(error);
      this.failAll(error);
      return;
    }
    if (message.type === 'stage') {
      const entry = this.pending.get(message.id);
      if (entry && typeof entry.onStage === 'function') entry.onStage(message.stage);
      return;
    }
    if (message.type === 'progress') {
      const entry = this.pending.get(message.id);
      if (entry && typeof entry.onProgress === 'function') entry.onProgress(Number(message.progress) || 0);
      return;
    }
    if (message.id && this.pending.has(message.id)) {
      const entry = this.pending.get(message.id);
      this.pending.delete(message.id);
      clearTimeout(entry.timer);
      if (message.ok) entry.resolve(message);
      else {
        entry.reject(
          new AppError(500, 'ASR_FAILED', '本地识别没有完成', message.message || this.lastError)
        );
      }
    }
  }

  failAll(error) {
    for (const [id, entry] of this.pending.entries()) {
      clearTimeout(entry.timer);
      entry.reject(error);
      this.pending.delete(id);
    }
  }

  terminate() {
    if (this.process) {
      try {
        this.process.kill('SIGTERM');
      } catch (error) {
        // 忽略。
      }
    }
    this.process = null;
    this.ready = false;
    this.starting = null;
  }

  async transcribe(filePath, options = {}) {
    await this.start();
    if (!this.process || !this.process.stdin.writable) {
      throw new AppError(503, 'ASR_UNAVAILABLE', '本地 Whisper 未就绪');
    }
    const id = String(++this.seq);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new AppError(504, 'ASR_TIMEOUT', '本地识别超时', '请尝试更短的视频或更小的模型。'));
      }, 30 * 60 * 1000);
      this.pending.set(id, {
        resolve,
        reject,
        onStage: options.onStage,
        onProgress: options.onProgress,
        timer: timeout
      });
      const payload = JSON.stringify({
        id,
        cmd: 'transcribe',
        file: path.resolve(filePath),
        language: options.language || config.whisperLanguage,
        initial_prompt: options.initialPrompt !== false,
        model: this.modelName
      });
      this.process.stdin.write(payload + '\n', (error) => {
        if (error) {
          clearTimeout(timeout);
          this.pending.delete(id);
          reject(new AppError(503, 'ASR_IO_ERROR', '无法写入本地识别进程'));
        }
      });
    });
  }
}

const worker = new WhisperWorker();
const followWorker = new WhisperWorker({
  modelName: config.followModel,
  computeType: config.whisperComputeType,
  beamSize: config.followBeamSize
});

export async function transcribeWithLocal(filePath, options = {}) {
  if (options.onStage) options.onStage('加载本地 Whisper 模型');
  const response = await worker.transcribe(filePath, {
    language: options.language || config.whisperLanguage,
    onStage: (stage) => {
      if (options.onStage) options.onStage(stage);
    },
    onProgress: (progress) => {
      if (options.onProgress) options.onProgress(progress);
    }
  });
  return {
    provider: '本地 Whisper',
    language: response.language || options.language || 'zh',
    duration: Number(response.duration) || 0,
    segments: (response.segments || []).map((segment) => ({
      start: Number(segment.start) || 0,
      end: Number(segment.end) || 0,
      text: String(segment.text || '').trim()
    }))
  };
}

export async function transcribeWithFollow(filePath, options = {}) {
  if (options.onStage) options.onStage('加载实时语音模型');
  const response = await followWorker.transcribe(filePath, {
    language: options.language || config.whisperLanguage,
    initialPrompt: false,
    onStage: (stage) => {
      if (options.onStage) options.onStage(stage);
    },
    onProgress: (progress) => {
      if (options.onProgress) options.onProgress(progress);
    }
  });
  return {
    provider: '本地 Whisper 实时',
    language: response.language || options.language || 'zh',
    duration: Number(response.duration) || 0,
    segments: (response.segments || []).map((segment) => ({
      start: Number(segment.start) || 0,
      end: Number(segment.end) || 0,
      text: String(segment.text || '').trim()
    }))
  };
}

export function shutdownWhisper() {
  worker.terminate();
  followWorker.terminate();
}
