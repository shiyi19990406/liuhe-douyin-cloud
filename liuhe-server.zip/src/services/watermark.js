import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../lib/errors.js';
import { runCommand, probeVideo, extractFrame, safeUnlink } from '../lib/process.js';

const assets = new Map();
const jobs = new Map();

function now() {
  return Date.now();
}

function clamp(value, low, high) {
  return Math.max(low, Math.min(high, value));
}

function publicJob(job) {
  if (!job) return null;
  return {
    id: job.id,
    status: job.status,
    stage: job.stage,
    progress: job.progress,
    mode: job.mode,
    effect: job.effect,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    result: job.result,
    error: job.error
  };
}

function setJob(job, patch) {
  Object.assign(job, patch, { updatedAt: now() });
}

export async function createPreview(file, originalName) {
  const meta = await probeVideo(file.path);
  if (!meta.width || !meta.height) {
    safeUnlink(file.path);
    throw new AppError(422, 'NO_VIDEO_STREAM', '没有读取到视频画面', '请选择常见的 MP4 / MOV 视频。');
  }
  if (meta.duration > config.maxWatermarkSeconds) {
    safeUnlink(file.path);
    throw new AppError(
      413,
      'VIDEO_TOO_LONG',
      '去水印视频不能超过 ' + Math.round(config.maxWatermarkSeconds / 60) + ' 分钟',
      '移动水印需要逐帧处理，请先裁剪视频或在 .env 中调整 MAX_WATERMARK_SECONDS。'
    );
  }

  const assetId = crypto.randomUUID();
  const extension = path.extname(originalName || file.originalname || '').toLowerCase().slice(0, 8) || '.mp4';
  const inputPath = path.join(config.watermarkDir, assetId + extension);
  await fs.promises.rename(file.path, inputPath);

  const duration = meta.duration || 1;
  const times = [duration * 0.1, duration * 0.45, duration * 0.8];
  const frames = [];
  for (let i = 0; i < times.length; i += 1) {
    const framePath = path.join(config.watermarkDir, assetId + '-frame-' + i + '.jpg');
    try {
      await extractFrame(inputPath, framePath, times[i]);
      frames.push(framePath);
    } catch (error) {
      // 某些短视频在 80% 位置没有关键帧，回退到首帧。
      try {
        await extractFrame(inputPath, framePath, 0);
        frames.push(framePath);
      } catch (nestedError) {
        // 保留其它帧。
      }
    }
  }
  if (!frames.length) {
    safeUnlink(inputPath);
    throw new AppError(422, 'FRAME_EXTRACT_FAILED', '无法从视频中截取预览帧');
  }

  const asset = {
    id: assetId,
    inputPath,
    frames,
    width: meta.width,
    height: meta.height,
    duration: meta.duration,
    createdAt: now()
  };
  assets.set(assetId, asset);

  return {
    assetId,
    width: meta.width,
    height: meta.height,
    duration: Math.round(meta.duration * 100) / 100,
    frames: frames.map((frame, index) => ({
      index,
      url: '/api/watermark/frame/' + assetId + '/' + index + '.jpg'
    })),
    maxSeconds: config.maxWatermarkSeconds
  };
}

function getAsset(assetId) {
  const asset = assets.get(assetId);
  if (!asset) throw new AppError(404, 'ASSET_NOT_FOUND', '视频预览已过期，请重新选择视频');
  return asset;
}

export function getAssetFrame(assetId, index) {
  const asset = getAsset(assetId);
  const frame = asset.frames[Number(index)];
  if (!frame) throw new AppError(404, 'FRAME_NOT_FOUND', '预览帧不存在');
  return frame;
}

export function createWatermarkJob(input) {
  const asset = getAsset(input.assetId);
  const effect = ['watermark', 'enhance'].includes(input.effect) ? input.effect : 'watermark';
  const mode = effect === 'enhance' ? 'enhance' : input.mode === 'moving' ? 'moving' : 'fixed';
  const preset = input.preset === 'detail' ? 'detail' : 'balanced';
  const rect = input.rect || {};
  let nx = 0;
  let ny = 0;
  let nw = 1;
  let nh = 1;
  if (effect !== 'enhance') {
    nx = clamp(Number(rect.x) || 0, 0, 0.98);
    ny = clamp(Number(rect.y) || 0, 0, 0.98);
    nw = clamp(Number(rect.w) || 0, 0.01, 1 - nx);
    nh = clamp(Number(rect.h) || 0, 0.01, 1 - ny);
    if (nw * asset.width < 8 || nh * asset.height < 8) {
      throw new AppError(400, 'RECT_TOO_SMALL', '框选区域太小', '请重新框选完整的水印范围。');
    }
  }
  const frameIndex = clamp(Number(input.frameIndex) || 0, 0, asset.frames.length - 1);

  const job = {
    id: crypto.randomUUID(),
    status: 'queued',
    stage: '排队中',
    progress: 0,
    mode,
    effect,
    preset,
    assetId: asset.id,
    rect: { x: nx, y: ny, w: nw, h: nh },
    frameIndex,
    createdAt: now(),
    updatedAt: now(),
    outputPath: '',
    result: null,
    error: null
  };
  jobs.set(job.id, job);
  setImmediate(() => runJob(job, asset));
  return publicJob(job);
}

async function runJob(job, asset) {
  const outputPath = path.join(config.watermarkDir, job.id + '-output.mp4');
  const movingPath = path.join(config.watermarkDir, job.id + '-processed.mp4');
  let rectPx = null;
  if (job.effect !== 'enhance') {
    rectPx = {
      x: clamp(Math.round(job.rect.x * asset.width), 1, Math.max(1, asset.width - 8)),
      y: clamp(Math.round(job.rect.y * asset.height), 1, Math.max(1, asset.height - 8)),
      w: clamp(Math.round(job.rect.w * asset.width), 8, asset.width - 2),
      h: clamp(Math.round(job.rect.h * asset.height), 8, asset.height - 2)
    };
    rectPx.w = Math.min(rectPx.w, asset.width - rectPx.x - 2);
    rectPx.h = Math.min(rectPx.h, asset.height - rectPx.y - 2);
    if (rectPx.w < 8 || rectPx.h < 8) {
      setJob(job, {
        status: 'failed',
        stage: '处理失败',
        error: { code: 'RECT_INVALID', message: '框选区域超出画面，请重新框选' }
      });
      return;
    }
  }

  try {
    setJob(job, { status: 'processing', stage: '正在分析画面', progress: 4 });
    if (job.effect === 'enhance') {
      setJob(job, { stage: '正在增强画质', progress: 8 });
      await runCommand(
        config.ffmpegPath,
        [
          '-y',
          '-i',
          asset.inputPath,
          '-vf',
          job.preset === 'detail'
            ? 'hqdn3d=1.2:1.2:4:4,unsharp=7:7:1.35:7:7:0.0,eq=contrast=1.06:saturation=1.05:brightness=0.01,scale=trunc(iw*2/2)*2:trunc(ih*2/2)*2:flags=lanczos'
            : 'hqdn3d=1.8:1.8:6:6,unsharp=5:5:1.15:5:5:0.0,eq=contrast=1.05:saturation=1.04:brightness=0.01,scale=trunc(iw*1.5/2)*2:trunc(ih*1.5/2)*2:flags=lanczos',
          '-map',
          '0:v:0',
          '-map',
          '0:a?',
          '-c:v',
          'libx264',
          '-preset',
          'veryfast',
          '-crf',
          '18',
          '-pix_fmt',
          'yuv420p',
          '-c:a',
          'copy',
          '-movflags',
          '+faststart',
          '-progress',
          'pipe:1',
          '-nostats',
          outputPath
        ],
        {
          timeoutMs: 30 * 60 * 1000,
          onStdout: (text) => {
            for (const line of text.split('\n')) {
              const match = line.match(/^out_time_ms=(\d+)/);
              if (!match) continue;
              const seconds = Number(match[1]) / 1e6;
              const ratio = asset.duration ? seconds / asset.duration : 0;
              const progress = Math.min(92, Math.max(8, 8 + ratio * 80));
              setJob(job, { stage: '正在增强画质', progress: Math.round(progress) });
            }
          }
        }
      );
    } else if (job.mode === 'moving' || job.mode === 'fixed') {
      // 固定水印用 FFmpeg delogo，移动水印用逐帧跟踪与修复。
      if (job.effect === 'watermark' && job.mode === 'fixed') {
      const filter = `delogo=x=${rectPx.x}:y=${rectPx.y}:w=${rectPx.w}:h=${rectPx.h}:show=0`;
      await runCommand(
        config.ffmpegPath,
        [
          '-y',
          '-i',
          asset.inputPath,
          '-vf',
          filter,
          '-map',
          '0:v:0',
          '-map',
          '0:a?',
          '-c:v',
          'libx264',
          '-preset',
          'veryfast',
          '-crf',
          '20',
          '-pix_fmt',
          'yuv420p',
          '-c:a',
          'copy',
          '-movflags',
          '+faststart',
          '-progress',
          'pipe:1',
          '-nostats',
          outputPath
        ],
        {
          timeoutMs: 30 * 60 * 1000,
          onStdout: (text) => {
            for (const line of text.split('\n')) {
              const match = line.match(/^out_time_ms=(\d+)/);
              if (!match) continue;
              const seconds = Number(match[1]) / 1e6;
              const ratio = asset.duration ? seconds / asset.duration : 0;
              const progress = Math.min(92, Math.max(5, 5 + ratio * 82));
              setJob(job, { stage: '正在移除固定水印', progress: Math.round(progress) });
            }
          }
        }
      );
    } else {
      setJob(job, { stage: '正在跟踪移动水印', progress: 6 });
      const templatePath = asset.frames[job.frameIndex] || asset.frames[0];
      await runCommand(
        config.pythonBin,
        [
          config.watermarkWorker,
          '--input',
          asset.inputPath,
          '--output',
          movingPath,
          '--template',
          templatePath,
          '--x',
          String(rectPx.x),
          '--y',
          String(rectPx.y),
          '--w',
          String(rectPx.w),
          '--h',
          String(rectPx.h),
          
        ],
        {
          timeoutMs: 45 * 60 * 1000,
          onStdout: (text) => {
            for (const line of text.split('\n')) {
              if (!line.trim()) continue;
              try {
                const message = JSON.parse(line);
                if (message.type === 'progress') {
                  setJob(job, {
                    stage: '正在跟踪并修复移动水印',
                    progress: Math.min(80, 6 + Math.round((Number(message.value) || 0) * 0.74))
                  });
                }
              } catch (error) {
                // Python 可能输出 OpenCV 日志，忽略。
              }
            }
          }
        }
      );
      setJob(job, { stage: '正在合并原视频音轨', progress: 84 });
      await runCommand(
        config.ffmpegPath,
        [
          '-y',
          '-i',
          movingPath,
          '-i',
          asset.inputPath,
          '-map',
          '0:v:0',
          '-map',
          '1:a?',
          '-c:v',
          'libx264',
          '-preset',
          'veryfast',
          '-crf',
          '20',
          '-pix_fmt',
          'yuv420p',
          '-c:a',
          'copy',
          '-shortest',
          '-movflags',
          '+faststart',
          outputPath
        ],
        { timeoutMs: 30 * 60 * 1000 }
      );
      safeUnlink(movingPath);
    }
    }

    if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size === 0) {
      throw new AppError(500, 'OUTPUT_EMPTY', '处理后的视频为空');
    }
    setJob(job, { status: 'done', stage: '处理完成', progress: 100 });
    job.outputPath = outputPath;
    const title = job.effect === 'enhance'
      ? '画质已增强 · 六和'
      : (job.mode === 'fixed' ? '固定水印已移除' : '移动水印已跟踪修复') + ' · 六和';
    job.result = {
      effect: job.effect,
      mode: job.mode,
      width: job.effect === 'enhance' ? Math.round(asset.width * (job.preset === 'detail' ? 2 : 1.5)) : asset.width,
      height: job.effect === 'enhance' ? Math.round(asset.height * (job.preset === 'detail' ? 2 : 1.5)) : asset.height,
      duration: asset.duration,
      videoUrl: '/api/watermark/result/' + job.id + '/video.mp4',
      title,
      rect: job.effect === 'enhance' ? null : job.rect
    };
  } catch (error) {
    safeUnlink(movingPath);
    safeUnlink(outputPath);
    setJob(job, {
      status: 'failed',
      stage: '处理失败',
      error: {
        code: error.code || 'WATERMARK_FAILED',
        message: error.message || '去水印处理失败',
        hint: error.hint || '可以换一个更准确的水印框，或缩短视频后重试。'
      }
    });
    console.error('[watermark]', error.message, error.detail || '');
  }
}

export function getWatermarkJob(jobId) {
  const job = jobs.get(jobId);
  if (!job) throw new AppError(404, 'JOB_NOT_FOUND', '去水印任务不存在或已过期');
  return job;
}

export function publicWatermarkJob(jobId) {
  return publicJob(getWatermarkJob(jobId));
}

export function getWatermarkOutput(jobId) {
  const job = getWatermarkJob(jobId);
  if (job.status !== 'done' || !job.outputPath || !fs.existsSync(job.outputPath)) {
    throw new AppError(409, 'JOB_NOT_READY', '去水印视频还没有生成');
  }
  return job.outputPath;
}

export function deleteWatermarkJob(jobId) {
  const job = jobs.get(jobId);
  if (!job) return false;
  safeUnlink(job.outputPath);
  jobs.delete(jobId);
  return true;
}

setInterval(() => {
  const cutoff = Date.now() - 2 * 60 * 60 * 1000;
  for (const [id, asset] of assets.entries()) {
    if (asset.createdAt < cutoff) {
      safeUnlink(asset.inputPath);
      for (const frame of asset.frames) safeUnlink(frame);
      assets.delete(id);
    }
  }
  for (const [id, job] of jobs.entries()) {
    if (job.updatedAt < cutoff) {
      safeUnlink(job.outputPath);
      jobs.delete(id);
    }
  }
}, 30 * 60 * 1000).unref();
