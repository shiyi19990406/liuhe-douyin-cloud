import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import app from './app.js';
import { config } from './config.js';
import { shutdownWhisper } from './services/asr/index.js';
import { safeUnlink } from './lib/process.js';

const server = http.createServer(app);

const tempDirs = [
  config.uploadDir,
  config.workDir,
  config.watermarkDir,
  config.photoDir,
  config.voiceDir,
  config.overlayDir,
  config.imageVideoDir
];

function cleanupOldTempFiles() {
  const cutoff = Date.now() - 2 * 60 * 60 * 1000;
  for (const dir of tempDirs) {
    fs.readdir(dir, (error, files) => {
      if (error || !files) return;
      for (const file of files) {
        const full = path.join(dir, file);
        fs.stat(full, (statError, stat) => {
          if (!statError && stat.isFile() && stat.mtimeMs < cutoff) safeUnlink(full);
        });
      }
    });
  }
}

// 服务重启后，上一进程遗留的任务文件也必须回收；否则长期运行会逐渐耗尽磁盘。
cleanupOldTempFiles();
setInterval(cleanupOldTempFiles, 30 * 60 * 1000).unref();

server.listen(config.port, config.host, () => {
  const banner = [
    '',
    '  六和 API  ·  完全免费的自建服务',
    `  http://127.0.0.1:${config.port}`,
    `  mode: ${config.demoMode ? 'DEMO' : 'LIVE'}  asr: ${config.asrProvider}  model: ${config.whisperModel}`,
    config.demoMode
      ? '  演示模式已开启：任意抖音/快手链接都会返回内置素材。'
      : '  真实解析已开启：抖音/快手链接将尝试提取无水印源。',
    ''
  ];
  console.log(banner.join('\n'));
  if (!fs.existsSync(config.demoVideoPath)) {
    console.warn('[warning] 演示视频不存在，请运行: npm run demo:media');
  }
});

function shutdown(signal) {
  console.log(`\n[server] ${signal} received, shutting down...`);
  shutdownWhisper();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (error) => {
  console.error('[unhandledRejection]', error);
});
